package com.hikvision.hae.foundation.actionlog.biz.impl;

import com.hikvision.hae.HaeFoundationBaseTest;
import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;


/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 14:45 2018/1/4
 * @Description :  菜单资源测试类
 */
public class SysResourceBizImplTest extends HaeFoundationBaseTest {

    @Autowired
    private SysResourceBiz sysResourceBiz;

    @Test
    public void listResourceByIds(){
        Integer[] ids={10,11,12};
        List<SysResourceDTO>  sysResourceDTOList = sysResourceBiz.listResourceByIds(Arrays.asList(ids));
        sysResourceDTOList.forEach((e)->{
            System.out.println(e.getName());
        });
    }

    @Test
    public void getResourceTree(){
        SysResourceDTO sysResourceDTO = sysResourceBiz.getResourceTree(SysResourceLayout.LEFT_LV1);
        System.out.println(sysResourceDTO.getName());
    }

    @Test
    public void listResourceByParentCode(){
        List<SysResourceDTO> sysResourceDTOList = sysResourceBiz.listResourceByParentCode(SysResourceCode.ROOT_LV2);
        sysResourceDTOList.forEach((e)->{
            System.out.println(e.getName());
        });
    }

    @Test
    public void getResourceByCode(){
        SysResourceDTO sysResourceDTO = sysResourceBiz.getResourceByCode(SysResourceCode.ROOT_LV1);
        System.out.println(sysResourceDTO.getName());
    }

    @Test
    public void updateResourceDeletedFlag(){
        sysResourceBiz.updateResourceDeletedFlag(SysResourceCode.LOG,Boolean.FALSE);
    }
}

