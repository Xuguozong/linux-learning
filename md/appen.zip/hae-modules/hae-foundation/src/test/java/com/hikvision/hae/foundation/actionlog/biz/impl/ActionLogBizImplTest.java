package com.hikvision.hae.foundation.actionlog.biz.impl;

import com.hikvision.hae.HaeFoundationBaseTest;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.foundation.actionlog.biz.ActionLogBiz;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogDTO;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import jef.common.wrapper.Page;
import org.joda.time.DateTime;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 14:59 2018/1/4
 * @Description :  操作日志测试类
 */

public class ActionLogBizImplTest extends HaeFoundationBaseTest{

    @Autowired
    private ActionLogBiz actionLogBiz;

    @Test
    public void testList(){
        System.out.println("aaaaa");
    }

    @Test
    public void findAndPage(){
        ActionLogQuery actionLogQuery = new ActionLogQuery();
        Date start = UTCDateUtil.parseUTCTimeToStandardDate("2016-01-01T00:00:00.000Z");
        actionLogQuery.setStartTime(start);
        actionLogQuery.setEndTime(new Date());
        PageParam pageParam = new PageParam(1,10);
        Page<ActionLogDTO> page = actionLogBiz.findAndPage(actionLogQuery,pageParam);
        page.getList().forEach((e)->{
            System.out.println(e.getContent());
        });
    }


}
