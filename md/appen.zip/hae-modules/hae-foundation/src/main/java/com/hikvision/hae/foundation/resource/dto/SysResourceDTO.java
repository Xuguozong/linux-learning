package com.hikvision.hae.foundation.resource.dto;

import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.resource.model.SysResource;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;

import java.io.Serializable;
import java.util.List;

/**
 *页面中的每个系统资源项，系统资源还可以包含子系统资源。
 *
 * Created by zhouziwei on 2017/11/3.
 */
public class SysResourceDTO implements Serializable {

    private static final long serialVersionUID = -6580414613687303830L;

    /**
     * 系统资源ID
     */
    private int id;

    /**
     * 父系统资源ID，顶级系统资源的父ID为0
     */
    private int parentId;

    /**
     * 系统资源名称。系统资源有分组时，系统资源名称作为分组中子系统资源的分组标题
     */
    private String name;

    /**
     * 系统资源的唯一性编号
     */
    private SysResourceCode code;

    /**
     * 系统资源位置
     */
    private SysResourceLayout position;

    /**
     * 系统资源图标的URL
     */
    private String iconUrl;

    /**
     * 系统资源的URL
     */
    private String url;

    /**
     * 一个父系统资源有多个子系统资源时，子系统资源的展示顺序
     */
    private int sequence;

    /**
     * 分组标记：true时表示当前系统资源是分组的标题
     */
    private boolean group;

    /**
     * 是否隐藏分组名称（即name属性值），隐藏后分组还存在，但是页面中不会显示name值
     */
    private boolean hideGroupTitle;

    /**
     * 子系统资源。仅当查询请求要求返回子系统资源时才有效
     */
    private List<SysResourceDTO> children;

    /**
     * 角色对系统资源的访问权限。从左至右，分别代表系统管理员权限、云分区管理权限、组织管理员权限、组织成员权限，有权限为1，无权限为0。
     */
    private String rolePrivilege;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SysResourceCode getCode() {
        return code;
    }

    public void setCode(SysResourceCode code) {
        this.code = code;
    }

    public SysResourceLayout getPosition() {
        return position;
    }

    public void setPosition(SysResourceLayout position) {
        this.position = position;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public boolean isGroup() {
        return group;
    }

    public void setGroup(boolean group) {
        this.group = group;
    }

    public boolean isHideGroupTitle() {
        return hideGroupTitle;
    }

    public void setHideGroupTitle(boolean hideGroupTitle) {
        this.hideGroupTitle = hideGroupTitle;
    }

    public String getRolePrivilege() {
        return rolePrivilege;
    }

    public void setRolePrivilege(String rolePrivilege) {
        this.rolePrivilege = rolePrivilege;
    }

    public List<SysResourceDTO> getChildren() {
        return children;
    }

    public void setChildren(List<SysResourceDTO> children) {
        this.children = children;
    }

    public static SysResourceDTO readFromModel(SysResource model) {
        SysResourceDTO dto = new SysResourceDTO();
        dto.setId(model.getId());
        dto.setParentId(model.getParentId());
        dto.setName(model.getName());
        dto.setCode(SysResourceCode.parse(model.getCode()));
        dto.setPosition(model.getPosition());
        dto.setIconUrl(model.getIconUrl());
        dto.setUrl(model.getUrl());
        dto.setSequence(model.getSequence());
        dto.setGroup(model.isGroup());
        dto.setHideGroupTitle(model.isHideGroupTitle());
        return dto;
    }

    @Override
    public String toString() {
        return "[" + this.getCode() + "]" + this.getName();
    }
}
