package com.hikvision.hae.foundation.resource.biz.impl;

import com.google.common.collect.Lists;
import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResource;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;
import com.hikvision.hae.foundation.resource.repo.ResourceRepo;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

/**
 * 系统资源领域业务
 *
 * Created by zhouziwei on 2017/11/3.
 */
@Component
public class SysResourceBizImpl implements SysResourceBiz{

    private final int ROOT_LV1_ID = 1;

    private final int ROOT_LV2_ID = 100;

    @Resource
    private ResourceRepo resourceRepo;

    @Override
    public List<SysResourceDTO> listResourceByIds(List<Integer> sysResourceIds) {
        List<SysResource> sysResourceList = resourceRepo.listResourceByIds(sysResourceIds);
        return sysResourceList.stream().map(SysResourceDTO::readFromModel).collect(Collectors.toList());
    }

    @Override
    public SysResourceDTO getResourceTree(SysResourceLayout layout) {
        // 1. 查询出所有的系统资源
        List<SysResource> sysResourceList = resourceRepo.listResource();

        // 2. 按系统资源父ID分组：除了顶层的ROOT外，先筛选出指定layout的系统资源，再按系统资源的父ID分组
        Map<Integer, List<SysResource>> groupResource = sysResourceList.stream() // 构建resource流
                .filter(m -> m.getId() != layout.getId()) // 排除root Resource
                .filter(m -> m.getPosition() == layout) //指定position
                .collect(groupingBy(SysResource::getParentId)); // 按系统资源的父ID分组

        SysResource rootSysResource = sysResourceList.stream() // 构建Resource流
                .filter(m -> m.getId() == layout.getId()) // 筛选root Resource
                .findFirst().get();

        // 3. 对不同position分组中的所有系统资源，计算层次结构
        SysResourceDTO rootSysResourceDTO = SysResourceDTO.readFromModel(rootSysResource);
        Set<Integer> matched = new HashSet<>(); // 已经匹配了子系统资源的系统资源ID
        while (!groupResource.isEmpty()) {
            // 递归遍历rootSysResourceDTO及其子系统资源集合，并把groupResource中key与系统资源树结点ID相等的entry的value作为该系统资源树结点的子系统资源集合
            SysResourceDTO unmatchResource = findFirstUnMatchRes(rootSysResourceDTO, matched);
            if (unmatchResource == null) {
                break;
            }
            matched.add(unmatchResource.getId()); // 当前的叶子结点已经被遍历过
            if (!groupResource.containsKey(unmatchResource.getId())) {
                continue; //是叶子结点
            }
            List<SysResourceDTO> children = groupResource.get(unmatchResource.getId()).stream() // 构建子系统资源流
                    .map(SysResourceDTO::readFromModel) // SysResource转换成SysResourceDTO
                    .sorted(Comparator.comparing(SysResourceDTO::getSequence)) // 按序号排序
                    .collect(toList()); // 归并到List
            unmatchResource.setChildren(children);
            groupResource.remove(unmatchResource.getId());
        }

        return rootSysResourceDTO;
    }

    /**
     * 从已经构建好的系统资源树中找出第一个还未遍历过的叶子
     *
     * @param sysResourceDTO 系统资源树
     * @param matched        已遍历节点ID
     * @return 第一个未遍历过的叶子
     */
    private SysResourceDTO findFirstUnMatchRes(SysResourceDTO sysResourceDTO, Set<Integer> matched) {
        if (!matched.contains(sysResourceDTO.getId())) {
            return sysResourceDTO;
        }

        return Optional.ofNullable(sysResourceDTO.getChildren())
                .flatMap(children -> children.stream().map(child -> findFirstUnMatchRes(child, matched)) // 递归，使用flatMap把嵌套型Optional扁平化
                        .filter(Objects::nonNull) // 不等于null说明找到了
                        .findFirst()) // 每次返回一个匹配的值就OK
                .orElse(null); // map返回的是Optional<SysResourceDTO>，此处获取实际封装的对象
    }

    @Override
    public List<SysResourceDTO> listResourceByParentCode(SysResourceCode parentSysResourceCode) {
        List<SysResource> sysResourceList = resourceRepo.listResourceByParentCode(parentSysResourceCode);
        return Optional.ofNullable(sysResourceList)
                .map(resList -> resList.stream()
                        .map(SysResourceDTO::readFromModel) //model -> dto
                        .collect(Collectors.toList())) //归并到List
                .orElse(Lists.newArrayList());
    }

    @Override
    public SysResourceDTO getResourceByCode(SysResourceCode sysResourceCode) {
        SysResource sysResource = resourceRepo.getResource(sysResourceCode);
        Assert.notNull(sysResource, "系统资源数据未正确初始化：未找到编码为" + sysResourceCode.name() + "的资源");
        return SysResourceDTO.readFromModel(sysResource);
    }

    @Override
    public void updateResourceDeletedFlag(SysResourceCode sysResourceCode, boolean deleted) {
        SysResource sysResource = resourceRepo.getResource(sysResourceCode, true);
        Assert.notNull(sysResource, "系统资源数据未正确初始化：未找到编码为" + sysResourceCode.name() + "的资源");
        sysResource.setDeleted(deleted);
        resourceRepo.updateSysResource(sysResource);
    }

}
