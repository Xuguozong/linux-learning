package com.hikvision.hae.foundation.resource.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;

import javax.persistence.*;

/**
 * 系统资源，包括页面顶部导航、左侧菜单树，以及正文内容中的其它资源
 * <p>
 * Created by zhouziwei on 2017/11/3.
 */
@Entity
@Table(name = "sys_resource")
@Comment("系统资源表")
public class SysResource extends DataObject {

	private static final long serialVersionUID = -154456924720173310L;

	/**
	 * 系统资源ID
	 */
	@Id
	@GeneratedValue
	private int id;

	/**
	 * 父系统资源ID，顶级系统资源的父ID为0
	 */
	@Column(name = "parent_id")
	private int parentId;

	/**
	 * 系统资源名称。系统资源有分组时，系统资源名称作为分组中子系统资源的分组标题
	 */
	@Column(name = "name", nullable = false, length = 64)
	private String name;

	/**
	 * 系统资源的唯一性编号
	 */
	@Column(name = "code", nullable = false, unique = true, length = 128)
	private String code;

	/**
	 * 系统资源位置
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "position", nullable = false, length = 16)
	private SysResourceLayout position;

	/**
	 * 系统资源图标的URL
	 */
	@Column(name = "icon_url", length = 1024)
	private String iconUrl;

	/**
	 * 系统资源的URL
	 */
	@Column(name = "url", length = 1024)
	private String url;

	/**
	 * 一个父系统资源有多个子系统资源时，子系统资源的展示顺序
	 */
	@Column(name = "sequence")
	private int sequence;

	/**
	 * 分组标记：true时表示当前系统资源是分组的标题
	 */
	@Column(name = "is_group")
	private boolean group;

	/**
	 * 是否隐藏分组名称（即name属性值），隐藏后分组还存在，但是页面中不会显示name值
	 */
	@Column(name = "hide_group_title")
	private boolean hideGroupTitle;

	/**
	 * 删除标记
	 */
	@Column(name = "is_deleted")
	private boolean deleted;

	/**
	 * 语言
	 */
	@Column(name = "language", nullable = false, length = 8)
	private String language;

	public enum Field implements jef.database.Field {
		id, parentId, name, code, position, iconUrl, url, sequence, group, hideGroupTitle, deleted, language;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public SysResourceLayout getPosition() {
		return position;
	}

	public void setPosition(SysResourceLayout position) {
		this.position = position;
	}

	public String getIconUrl() {
		return iconUrl;
	}

	public void setIconUrl(String iconUrl) {
		this.iconUrl = iconUrl;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public boolean isGroup() {
		return group;
	}

	public void setGroup(boolean group) {
		this.group = group;
	}

	public boolean isHideGroupTitle() {
		return hideGroupTitle;
	}

	public void setHideGroupTitle(boolean hideGroupTitle) {
		this.hideGroupTitle = hideGroupTitle;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}


	@Override
	public String toString() {
		return "[" + this.getCode() + "]" + this.getName();
	}

}
