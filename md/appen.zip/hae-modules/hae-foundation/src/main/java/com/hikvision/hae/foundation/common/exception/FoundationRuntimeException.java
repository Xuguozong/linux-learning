package com.hikvision.hae.foundation.common.exception;

import com.hikvision.hae.common.exception.HAERuntimeException;

/**
 * Created by zhouziwei on 2017/11/8.
 */
public class FoundationRuntimeException extends HAERuntimeException {

    private static final long serialVersionUID = 2976066718473067340L;

    public FoundationRuntimeException() {
        super();
    }

    public FoundationRuntimeException(int resultCode) {
        super(resultCode);
    }

    public FoundationRuntimeException(int resultCode, Throwable cause) {
        super(resultCode, cause);
    }

    public FoundationRuntimeException(int resultCode, Object[] messageParam) {
        super(resultCode, messageParam);
    }

    public FoundationRuntimeException(int resultCode, Object[] messageParam, Throwable cause) {
        super(resultCode, messageParam, cause);
    }
}
