package com.hikvision.hae.foundation.common.exception;

import javax.security.auth.login.LoginException;

/**
 * 验证码错误
 *
 * @author zhanjiejun
 */
public class WrongCaptchaException extends LoginException {

	private static final long serialVersionUID = 1L;

	private Integer failedTimes;

	public WrongCaptchaException() {
	}

	public WrongCaptchaException(Integer failedTimes) {
		this.failedTimes = failedTimes;
	}

	public Integer getFailedTimes() {
		return failedTimes;
	}

}
