package com.hikvision.hae.foundation.user.repo;

import com.github.geequery.springdata.annotation.IgnoreIf;
import com.github.geequery.springdata.annotation.Modifying;
import com.github.geequery.springdata.annotation.ParamIs;
import com.github.geequery.springdata.annotation.Query;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.foundation.user.model.User;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public interface UserRepo extends GqRepository<User, String> {

	User findByUsernameAndStatusNot(String username, Integer status);

	@Modifying
	@Query("update user set password=?2, pwd_strength=?3, is_force_modify_pwd=?4 where username=?1")
	void updateUserPwd(String username, String pwd, int pwdStrength, boolean forceModifyPwd);

}
