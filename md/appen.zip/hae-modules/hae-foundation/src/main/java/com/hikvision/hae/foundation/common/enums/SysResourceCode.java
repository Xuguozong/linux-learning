package com.hikvision.hae.foundation.common.enums;

import org.springframework.util.Assert;

import java.util.stream.Stream;

/**
 * 系统资源编码
 * <p>
 * Created by zhouziwei on 2017/11/3.
 */
public enum SysResourceCode {
	//以下为可视化的导航栏/菜单类别的系统资源
	ROOT_LV1("root_lv1", "一级菜单资源根"),
	ROOT_LV2("root_lv2", "一级菜单资源根"),
	SUMMARY("summary", "首页"),
	NODE_MANAGE("nodeManage", "节点管理"),
	IMAGE_MANAGE("imageManage", "镜像管理"),
	RESOURCE_MANAGE("resourceManage", "资源管理"),
	LOG("log", "应用日志"),
	NAMESPACE_MANAGE("namespaceManage", "命名空间管理"),
	NAMESPACE("namespace", "命名空间"),
	STORAGE_MANAGE("storageManage", "存储"),
	PERSIST_VOLUME("persistVolume", "持久化存储卷"),
	STORAGE_CLASS("storageClass", "存储类"),
	WORKLOADS("workloads", "工作负载"),
	DEPLOYMENT("deployment", "工作负载/部署"),
	REPLICA_SET("replicaSet", "工作负载/副本集"),
	REPLICATION_CONTROLLER("replicationController", "工作负载/副本控制器"),
	DAEMON_SET("daemonSet", "工作负载/守护进程集"),
	STATEFUL_SET("statefulSet", "工作负载/有状态副本集"),
	JOB("job", "工作负载/任务"),
	PODS("pods", "工作负载/容器组"),
	SERVICE_DISCOVERY("serviceDiscovery", "服务发现和负载均衡"),
	SERVICE("service", "服务发现和负载均衡/服务"),
	INGRESS("ingress", "服务发现和负载均衡/访问权"),
	CONFIGURATION_STORAGE("configurationStorage", "配置和存储"),
	SECRET("secret", "配置和存储/保密字典"),
	CONFIG_MAP("configMap", "配置和存储/配置集"),
	VOLUME_CLAIM("volumeClaim", "配置和存储/持久化存储卷声明");

	//资源别名
	private String alias;
	//资源说明
	private String description;

	SysResourceCode(String alias, String description) {
		this.alias = alias;
		this.description = description;
	}

	public String getAlias() {
		return alias;
	}

	public static SysResourceCode parse(String name) {
		SysResourceCode sysResourceCode = Stream.of(SysResourceCode.values()).filter(c -> c.name().equals(name)).findFirst().orElse(null);
		Assert.notNull(sysResourceCode, "系统资源数据未正确初始化：不存在的系统资源编码：" + name);
		return sysResourceCode;
	}
}
