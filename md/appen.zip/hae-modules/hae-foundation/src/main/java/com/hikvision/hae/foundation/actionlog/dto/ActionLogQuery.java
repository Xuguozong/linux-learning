package com.hikvision.hae.foundation.actionlog.dto;

import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;

import java.io.Serializable;
import java.util.Date;

/**
 * 操作（行为、动作）日志查询参数封装
 *
 * Created by zhouziwei on 2017/11/1.
 */
public class ActionLogQuery implements Serializable{

    private static final long serialVersionUID = 8085243093532058040L;
    /**
     * 操作的对象标识，比如ID
     */
    private String principalIndexCode;

    /**
     * 操作的对象类别：VM、VDC、用户等
     */
    private PrincipalCategory principalCategory;

    /**
     * 操作类别,新增/修改/删除/登录等
     */
    private PrincipalActionType actionType;

    /**
     * 起始时间
     */
    private Date startTime;

    /**
     * 终止时间
     */
    private Date endTime;


    /**
     * 模糊查询条件
     */
    private String fq;


    public String getPrincipalIndexCode() {
        return principalIndexCode;
    }

    public void setPrincipalIndexCode(String principalIndexCode) {
        this.principalIndexCode = principalIndexCode;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getFq() {
        return fq;
    }

    public void setFq(String fq) {
        this.fq = fq;
    }

    public PrincipalActionType getActionType() {
        return actionType;
    }

    public void setActionType(PrincipalActionType actionType) {
        this.actionType = actionType;
    }

    public PrincipalCategory getPrincipalCategory() {
        return principalCategory;
    }

    public void setPrincipalCategory(PrincipalCategory principalCategory) {
        this.principalCategory = principalCategory;
    }
}
