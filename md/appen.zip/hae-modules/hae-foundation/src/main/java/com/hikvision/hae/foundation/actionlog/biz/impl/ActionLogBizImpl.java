package com.hikvision.hae.foundation.actionlog.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.foundation.actionlog.biz.ActionLogBiz;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogDTO;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import com.hikvision.hae.foundation.actionlog.model.ActionLog;
import com.hikvision.hae.foundation.actionlog.repo.ActionLogRepo;
import jef.common.wrapper.Page;
import org.easyframe.enterprise.spring.CommonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 操作（行为、动作）日志 领域业务操作接口实现
 * <p>
 * Created by zhouziwei on 2017/11/1.
 */
@Component
public class ActionLogBizImpl implements ActionLogBiz {

    @Autowired
    private ActionLogRepo actionLogRepo;

    @Resource
    private CommonDao dao;

    @Override
    public Page<ActionLogDTO> findAndPage(ActionLogQuery actionLogQuery, PageParam pageParam) {
        Page<ActionLog> model = actionLogRepo.findAndPage(actionLogQuery, pageParam);
        Page<ActionLogDTO> dtoPage = new Page<>(model.getTotalCount(), model.getPageSize());
        List<ActionLogDTO> dtoList = Optional.ofNullable(model.getList())
                .map(rows -> rows.stream() //构建流
                        .map(ActionLogDTO::readFromModel) //model -> dto
                        .collect(Collectors.toList())) // 归集到集合
                .orElse(Collections.emptyList()); //原集合为null怎返回空list
        dtoPage.setList(dtoList);
        return dtoPage;
    }

}
