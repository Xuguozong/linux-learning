package com.hikvision.hae.foundation.resource.repo.impl;

import com.hikvision.hae.foundation.common.constant.FoundationResultCode;
import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.common.exception.FoundationRuntimeException;
import com.hikvision.hae.foundation.resource.model.SysResource;
import com.hikvision.hae.foundation.resource.repo.ResourceRepo;
import jef.database.Condition;
import jef.database.QB;
import jef.database.meta.JoinKey;
import jef.database.query.Join;
import jef.database.query.Query;
import jef.database.query.Selects;
import org.easyframe.enterprise.spring.CommonDao;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by zhouziwei on 2017/11/8.
 */
@Component
public class ResourceRepoImpl implements ResourceRepo {
	private final static String DEFAULT_LANG = "zh_CN";

	@Resource
	private CommonDao dao;

	/* ************************* SysResource 开始************** */
	@Override
	public List<SysResource> listResourceByIds(List<Integer> sysResourceIds) {
		SysResource sysResource = new SysResource();
		if (sysResourceIds.size() == 1) {
			sysResource.getQuery().addCondition(SysResource.Field.id, sysResourceIds.get(0));
			return dao.find(sysResource);
		} else {
			sysResource.getQuery().addCondition(SysResource.Field.id, Condition.Operator.IN, sysResourceIds);
			return dao.find(sysResource);
		}
	}

	@Cacheable(value = "resource.sysRes")
	@Override
	public List<SysResource> listResource() {
		SysResource sysResource = new SysResource();
		sysResource.setLanguage(DEFAULT_LANG);
		sysResource.setDeleted(false);
		return dao.find(sysResource);
	}

	@Override
	public List<SysResource> listResourceByParentCode(SysResourceCode parentSysResourceCode) {
		Query<SysResource> parent = QB.create(SysResource.class);
		parent.addCondition(SysResource.Field.code, parentSysResourceCode.name());
		parent.addCondition(SysResource.Field.deleted, false);
		parent.addCondition(SysResource.Field.language, DEFAULT_LANG);
		Query<SysResource> child = QB.create(SysResource.class);
		Join join = QB.innerJoin(parent, child, new JoinKey(SysResource.Field.id, SysResource.Field.parentId));
		//忽略parent的字段，只保留child的字段
		Selects selects = QB.selectFrom(join);
		selects.noColums(parent);
		join.setSelectItems(selects);
		try {
			return dao.getSession().selectAs(join, SysResource.class);
		} catch (SQLException e) {
			throw new FoundationRuntimeException(FoundationResultCode.ACCESS_SYS_RESOURCE_DATA_ERROR, e);
		}
	}

	@Override
	public SysResource getResource(SysResourceCode sysResourceCode) {
		return getResource(sysResourceCode, false);
	}

	@Override
	public SysResource getResource(SysResourceCode sysResourceCode, boolean ignoreDeleted) {
		SysResource sysResource = new SysResource();
		sysResource.setCode(sysResourceCode.name());
		sysResource.setLanguage(DEFAULT_LANG);
		if (!ignoreDeleted) {
			sysResource.setDeleted(false);
		}
		return dao.load(sysResource, false);
	}

	@CacheEvict(value = "resource.sysRes")
	@Override
	public int updateSysResource(SysResource sysResource) {
		return dao.update(sysResource);
	}

}
