package com.hikvision.hae.foundation.actionlog.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogDTO;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogQuery;
import jef.common.wrapper.Page;

/**
 * 操作（行为、动作）日志 领域业务操作接口
 *
 *Created by zhouziwei on 2017/11/1.
 */
public interface ActionLogBiz {
	/**
	 * 分页查询操作日志
	 * 
	 * @param actionLogQuery  查询条件
	 * @param pageParam 分页参数
	 * @return
	 */
	Page<ActionLogDTO> findAndPage(ActionLogQuery actionLogQuery, PageParam pageParam);
}
