package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.resource.service.RbacService;
import org.springframework.stereotype.Service;

/**
 * FIXME: 写此类是为了以Restful API方式验证RBAC的Biz层实现（懒得写单元测试）
 * FIXME: 因为Restful和Service是和视图逻辑紧密相关的，目前无相关视图逻辑，所以就先全部注释掉
 * FIXME: 假如增加了视图逻辑，不允许直接返回k8s对象，必须转成对应的VO对象
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
@Service
public class RbacServiceImpl implements RbacService {

    /*@Resource
    private RoleBiz roleBiz;

    @Resource
    private ClusterRoleBiz clusterRoleBiz;

    @Resource
    private RoleBindingBiz roleBindingBiz;

    @Resource
    private ClusterRoleBindingBiz clusterRoleBindingBiz;

    @Override
    public Pagination<Role> findAndPageRole(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        return roleBiz.findAndPage(filterQuery, pageParam);
    }

    @Override
    public Role getRoleByName(String namespace, String name) {
        return roleBiz.getByName(namespace, name);
    }

    @Override
    public void deleteRole(String namespace, String name) {
        roleBiz.delete(namespace, name);
    }

    @Override
    public Pagination<ClusterRole> findAndPageClusterRole(String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(null, name, null);
        return clusterRoleBiz.findAndPage(filterQuery, pageParam);
    }

    @Override
    public ClusterRole getClusterRoleByName(String name) {
        return clusterRoleBiz.getByName(name);
    }

    @Override
    public void deleteClusterRole(String name) {
        clusterRoleBiz.delete(name);
    }

    @Override
    public Pagination<RoleBinding> findAndPageRoleBinding(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        return roleBindingBiz.findAndPage(filterQuery, pageParam);
    }

    @Override
    public RoleBinding getRoleBindingByName(String namespace, String name) {
        return roleBindingBiz.getByName(namespace, name);
    }

    @Override
    public void deleteRoleBinding(String namespace, String name) {
        roleBindingBiz.delete(namespace, name);
    }

    @Override
    public Pagination<ClusterRoleBinding> findAndPageClusterRoleBinding(String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(null, name, null);
        return clusterRoleBindingBiz.findAndPage(filterQuery, pageParam);
    }

    @Override
    public ClusterRoleBinding getClusterRoleBindingByName(String name) {
        return clusterRoleBindingBiz.getByName(name);
    }

    @Override
    public void deleteClusterRoleBinding(String name) {
        clusterRoleBindingBiz.delete(name);
    }*/
}
