package com.hikvision.hae.resource.vo;

import java.io.Serializable;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
public class PodInfoVO implements Serializable {
    private static final long serialVersionUID = -1885548732088735082L;

    // Number of pods that are created.
    private Integer current;

    // Number of pods that are desired.
    private Integer desired;

    // Number of pods that are currently running.
    private Integer running;

    // Number of pods that are currently waiting.
    private Integer pending;

    // Number of pods that are failed.
    private Integer failed;

    // Number of pods that are succeeded.
    private Integer succeeded;

    public PodInfoVO() {
    }

    public PodInfoVO(Integer current, Integer desired) {
        this.current = current;
        this.desired = desired;
    }

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getDesired() {
        return desired;
    }

    public void setDesired(Integer desired) {
        this.desired = desired;
    }

    public Integer getRunning() {
        return running;
    }

    public void setRunning(Integer running) {
        this.running = running;
    }

    public Integer getPending() {
        return pending;
    }

    public void setPending(Integer pending) {
        this.pending = pending;
    }

    public Integer getFailed() {
        return failed;
    }

    public void setFailed(Integer failed) {
        this.failed = failed;
    }

    public Integer getSucceeded() {
        return succeeded;
    }

    public void setSucceeded(Integer succeeded) {
        this.succeeded = succeeded;
    }
}
