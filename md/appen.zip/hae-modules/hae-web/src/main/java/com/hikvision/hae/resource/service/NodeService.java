package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.vo.TableParam;
import com.hikvision.hae.resource.vo.*;

/**
 * 节点管理Service层
 * Created by zhanjiejun on 2017/11/15.
 */
public interface NodeService {

	void addNode(NodeWriteVO nodeWriteVO);

	void hardDeleteNode(int id);

	void softDeleteNode(int id);

	Pagination<NodeBaseVO> findAndPageNodes(TableParam tableParam);

	boolean isNameExist(String name, int id);

	boolean isIpExist(String ip);

	void mergeNodeLabel(int id, LabelVO label);

	void deleteNodeLabel(int id, String key);

	boolean isLabelKeyExist(int id, String key);

	NodeBaseVO getNodeBaseDetail(int id);

	void maintainNode(int id);

	void exitMaintainNode(int id);

	void updateNode(int id, NodeWriteVO nodeWriteVO);

	NodeReadVO getNodeDetail(int id);

	boolean isNodeLabelKeyAvailable(int id, String key);

	void syncNodeList();

	Pagination<PodItemVO> getPodsInNode(int id, PageParam pageParam);

}
