package com.hikvision.hae.foundation.web.assist;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Component
public class InvalidLoginTimesRegistry {

	private final static String invalidLoginTimesCacheName = "invalidLoginTimesCache";
	private final static String frozenCacheName = "frozenCache";

	private Map<String, Map<String, String>> cache = new ConcurrentHashMap<>();

	@PostConstruct
	public void init() {
		cache.put(invalidLoginTimesCacheName, new ConcurrentHashMap<>());
		cache.put(frozenCacheName, new ConcurrentHashMap<>());
	}

	public Integer getFailedTimes(String key) {
		Map<String, String> timesCache = cache.get(invalidLoginTimesCacheName);
		if (CollectionUtils.isEmpty(timesCache)) {
			return 0;
		}
		String times = timesCache.get(key);
		return null == times ? 0 : Integer.valueOf(times);
	}

	public void plusFailedTimes(String key) {
		Integer times = getFailedTimes(key);
		if (times == null) {
			times = 0;
		}
		cache.get(invalidLoginTimesCacheName).put(key, String.valueOf(times + 1));
		if (times == 4) {
			plusFrozen(key);
		}
	}

	public void delFailedTimes(String key) {
		cache.get(invalidLoginTimesCacheName).remove(key);
	}

	public void plusFrozen(String key) {
		cache.get(frozenCacheName).put(key, String.valueOf(System.currentTimeMillis()));
	}

	public void delFrozen(String key) {
		cache.get(frozenCacheName).remove(key);
	}

	public Long getFrozenDate(String key) {
		return Long.parseLong(cache.get(frozenCacheName).get(key));
	}

	public Set<String> getFrozenReadyToClean(long nowMillis) {
		Map<String, String> allFrozen = cache.get(frozenCacheName);
		return allFrozen.keySet().stream().filter(s -> Long.parseLong(allFrozen.get(s)) < nowMillis).collect(Collectors.toSet());
	}

}
