package com.hikvision.hae.resource.vo;

import io.fabric8.kubernetes.api.model.KubernetesResource;

import java.io.Serializable;

/**
 * PersistentVolumeSourceVO
 *
 * @author jianghaiyang5 on 2017/11/27.
 */
public class PersistentVolumeSourceVO implements Serializable {

    private static final long serialVersionUID = -265198329898582064L;

    private String type;

    private KubernetesResource source;

    public PersistentVolumeSourceVO() {
    }

    public PersistentVolumeSourceVO(String type, KubernetesResource source) {
        this.type = type;
        this.source = source;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public KubernetesResource getSource() {
        return source;
    }

    public void setSource(KubernetesResource source) {
        this.source = source;
    }
}
