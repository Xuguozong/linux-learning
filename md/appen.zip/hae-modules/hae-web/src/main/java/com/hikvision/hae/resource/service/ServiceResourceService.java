package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ServiceDetailVO;
import com.hikvision.hae.resource.vo.ServiceItemVO;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public interface ServiceResourceService {

    /**
     * 分页查询Service
     *
     * @param namespace 命名空间
     * @param name      Service名称
     * @param pageParam 分页参数
     * @param ownerKind Service关联方的类型
     * @param ownerName Service关联方名称
     * @return 列表记录
     */
    Pagination<ServiceItemVO> findAndPage(String namespace, String name, String ownerKind, String ownerName, PageParam pageParam);

    /**
     * 查看Service详情
     *
     * @param namespace 命名空间
     * @param name      Service名称
     * @return Service详情
     */
    ServiceDetailVO getDetail(String namespace, String name);

    /**
     * 删除Deployment
     *
     * @param namespace 命名空间
     * @param name      Service名称
     */
    void delete(String namespace, String name);
}
