package com.hikvision.hae.image.job;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.StatusEvent;
import com.hikvision.hae.image.listener.StatusListener;
import com.hikvision.hae.img.biz.ImageBiz;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.biz.dto.DeleteImageDTO;
import com.spotify.docker.client.messages.Image;

/**
 * 清理Docker server中的镜像
 * 
 * @author qiuzhihao
 *
 */
@Configuration
@ConditionalOnProperty(prefix = "image", name = "enabled", havingValue = "true", matchIfMissing = true)
public class CleanPushedImageJob implements StatusListener {

	private static final Logger logger = LoggerFactory.getLogger(CleanPushedImageJob.class);

	private ConcurrentMap<String, String> taskTrace = new ConcurrentHashMap<>();

	@Resource
	private ImageBiz imageBiz;

	@Resource
	private ImageRepositoryConfigBiz accessConfigBiz;

	/**
	 * 根据事件追踪任务执行 UPLOADING是任务入口 UPLOAD_BREAK UPLOAD_ERROR PUSH_ERROR PUSHED是各种情形的出口
	 */
	@Override
	public void process(StatusEvent event) {
		UploadStatus status = event.getStatus();
		if (UploadStatus.UPLOADING == status) {
			taskTrace.putIfAbsent(event.getFileId(), event.getFileId());
		} else if (UploadStatus.UPLOAD_BREAK == status || UploadStatus.UPLOAD_ERROR == status
				|| UploadStatus.PUSH_ERROR == status || UploadStatus.PUSHED == status) {
			taskTrace.remove(event.getFileId());
		}
	}

	@Scheduled(cron = "${job.config.cleanPushImageCron:0 0 * * * *}")
	public void clean() {
		if (taskTrace.size() != 0) {
			logger.debug("当前正在有文件上传任务在执行，不执行Docker server镜像清理");
		} else {
			logger.debug("开始清理Docker server中的镜像文件");
			List<Image> images = imageBiz.imageList(accessConfigBiz.accessInfo());
			if (images != null) {
				images.forEach(image -> {
					try {
						DeleteImageDTO deleteDTO = new DeleteImageDTO(image.id(), accessConfigBiz.accessInfo());
						imageBiz.removeImage(deleteDTO);
						logger.info("删除Docker server镜像：id：{}，tag：{}", image.id(), image.repoTags());
					} catch (Exception e) {
						logger.warn("清理Docker server中的镜像异常", e);
					}
				});
			}
		}
	}

}
