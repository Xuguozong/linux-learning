package com.hikvision.hae.resource.web.restful;

import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.service.DeploymentService;
import com.hikvision.hae.resource.vo.DeploymentDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author jianghaiyang5 on 2017/11/8.
 */
@Api(description = "工作负载/部署")
@RestController
@RequestMapping("/api/deployments/v1")
public class DeploymentRestful {

    @Resource
    private DeploymentService deploymentService;

    /**
     * 分页查询Deployment
     *
     * @param namespace 命名空间
     * @param name      Deployment名称，模糊匹配
     * @param labels    Deployment标签，格式：key1;key2:val2
     * @param pageSize  每页记录数
     * @param pageNo    页码，从1开始
     * @return Deployment分页数据
     */
    @ApiOperation(value = "分页查询部署", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "pageSize", dataType = "int", required = true, value = "页大小"),
            @ApiImplicitParam(paramType = "path", name = "pageNo", dataType = "int", required = true, value = "页码"),
            @ApiImplicitParam(paramType = "query", name = "name", dataType = "String", value = "名称"),
            @ApiImplicitParam(paramType = "query", name = "labels", dataType = "String",
                    value = "标签：冒号分割key-value，多个标签用分号连接", example = "key1;key2:val2")
    })
    @GetMapping("/namespace/{namespace}/pagination/{pageSize}/{pageNo}")
    public AjaxResult<Pagination<PodControllerItemVO>> findAndPage(@PathVariable String namespace,
                                                                   @PathVariable int pageSize,
                                                                   @PathVariable int pageNo,
                                                                   @RequestParam(required = false) String name,
                                                                   @RequestParam(required = false) String labels) {
        PageParam pageParam = new PageParam(pageNo, pageSize);
        AjaxResult<Pagination<PodControllerItemVO>> result = AjaxResult.buildSuccess();
        result.setData(deploymentService.findAndPage(namespace, name, labels, pageParam));
        return result;
    }

    /**
     * 查看Deployment详情
     *
     * @param namespace 命名空间
     * @param name      Deployment名称
     * @return Deployment详情
     */
    @ApiOperation(value = "查询部署详情", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
    })
    @GetMapping("/namespace/{namespace}/{name}")
    public AjaxResult<DeploymentDetailVO> getDetail(@PathVariable String namespace,
                                                    @PathVariable String name) {
        AjaxResult<DeploymentDetailVO> result = AjaxResult.buildSuccess();
        result.setData(deploymentService.getDetail(namespace, name));
        return result;
    }

    /**
     * 伸缩Deployment
     *
     * @param namespace   命名空间
     * @param name        Deployment名称
     * @param newReplicas 新Pod数量
     */
    @ApiOperation(value = "伸缩部署", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称"),
            @ApiImplicitParam(paramType = "query", name = "replicas", dataType = "int", required = true, value = "新副本数")
    })
    @PutMapping("/namespace/{namespace}/{name}/scale")
    public AjaxResult<Void> scale(@PathVariable String namespace, @PathVariable String name, @RequestParam("replicas") int newReplicas) {
        deploymentService.scale(namespace, name, newReplicas);
        return AjaxResult.buildSuccess();
    }

    /**
     * 删除Deployment
     *
     * @param namespace 命名空间
     * @param name      Deployment名称
     */
    @ApiOperation(value = "删除部署", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
    })
    @DeleteMapping("/namespace/{namespace}/{name}")
    public AjaxResult<Void> delete(@PathVariable String namespace, @PathVariable String name) {
        deploymentService.delete(namespace, name);
        return AjaxResult.buildSuccess();
    }
}
