package com.hikvision.hae.metrics.service;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.vo.ClusterInfoVO;

/**
 * Created by zhanjiejun on 2017/11/21.
 */
public interface OverviewService {

	ClusterInfoVO getClusterInfo();

	MetricsTrendVO metricsClusterTrend(MetricsType metricsType);

}
