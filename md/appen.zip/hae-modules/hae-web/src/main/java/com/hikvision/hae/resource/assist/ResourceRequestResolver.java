package com.hikvision.hae.resource.assist;

import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import org.springframework.util.StringUtils;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public class ResourceRequestResolver {

    public static FilterQuery parseTableRequestParam(String namespace, String name, String labels) {
        FilterQuery filterQuery = FilterQuery.build().namespace(namespace);
        if (StringUtils.hasText(name)) {
            filterQuery.name(name);
        }
        if (StringUtils.hasText(labels)) {
            String[] kvs = labels.split(";");
            for (String kv : kvs) {
                if (!StringUtils.hasText(kv)) {
                    continue;
                }
                if (kv.contains(":")) {
                    String[] kvItem = kv.split(":");
                    filterQuery.label(StringUtils.trimWhitespace(kvItem[0]), StringUtils.trimWhitespace(kvItem[1]));
                } else {
                    filterQuery.lableKey(StringUtils.trimWhitespace(kv));
                }
            }
        }
        return filterQuery;
    }
}
