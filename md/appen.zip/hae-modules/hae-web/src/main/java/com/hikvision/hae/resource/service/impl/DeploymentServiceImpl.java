package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.deployment.biz.DeploymentBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.replicaset.biz.ReplicaSetBiz;
import com.hikvision.hae.resource.service.DeploymentService;
import com.hikvision.hae.resource.vo.DeploymentDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import io.fabric8.kubernetes.api.model.extensions.RollingUpdateDeployment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
@Service
public class DeploymentServiceImpl implements DeploymentService {
    private static final Logger logger = LoggerFactory.getLogger(DeploymentServiceImpl.class);

    @Resource
    private DeploymentBiz deploymentBiz;

    @Resource
    private ReplicaSetBiz replicaSetBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, labels);
        Pagination<Deployment> deploymentPage = deploymentBiz.findAndPage(filterQuery, pageParam);
        if (deploymentPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<Deployment, PodInfo> podInfoFunc =
                (Deployment deployment) -> {
                    ReplicaSet newRs = replicaSetBiz.getNewReplicaSet(deployment);
                    return podBiz.getPodInfo(newRs.getSpec().getSelector(), namespace,
                            deployment.getStatus().getReplicas(), deployment.getSpec().getReplicas(), newRs.getMetadata().getUid());
                };
        Function<Collection<Deployment>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<Deployment> dtoList) -> dtoList.stream()
                        .map(dep -> ResourceVOBuilder.buildPodControllerItemVO(dep, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(deploymentPage, rowsConverter);
    }

    @Override
    public DeploymentDetailVO getDetail(String namespace, String name) {
        Deployment deployment = deploymentBiz.getByName(namespace, name);
        if (deployment == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Deployment[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.DEPLOYMENT_NOT_EXIST);
        }
        DeploymentDetailVO detailVO = new DeploymentDetailVO();
        //Deployment基础属性
        detailVO.setNamespace(namespace);
        detailVO.setName(name);
        detailVO.setLabels(deployment.getMetadata().getLabels());
        detailVO.setAnnotations(deployment.getMetadata().getAnnotations());
        detailVO.setSelectors(deployment.getSpec().getSelector().getMatchLabels());
        detailVO.setStrategy(deployment.getSpec().getStrategy().getType());
        detailVO.setMinReadySeconds(deployment.getSpec().getMinReadySeconds());
        detailVO.setRevisionHistoryLimit(deployment.getSpec().getRevisionHistoryLimit());
        RollingUpdateDeployment rollingUpdateDeployment = deployment.getSpec().getStrategy().getRollingUpdate();
        if (rollingUpdateDeployment != null) {
            detailVO.setRollingUpdateStrategy(ResourceVOBuilder.buildRollingUpdateStrategyVO(rollingUpdateDeployment));
        }
        detailVO.setStatusInfo(ResourceVOBuilder.buildDeploymentStatusInfoVO(deployment));
        return detailVO;
    }

    @Override
    public void scale(String namespace, String name, int newReplicas) {
        deploymentBiz.scale(namespace, name, newReplicas);
        kubeEventHelper.publishScaleEvent(ActionLogModules.DEPLOYMENT, PrincipalCategory.DEPLOYMENT, namespace, name, "伸缩部署（Deployment）");
    }

    @Override
    public void delete(String namespace, String name) {
        deploymentBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.DEPLOYMENT, PrincipalCategory.DEPLOYMENT, namespace, name, "删除部署（Deployment）");
    }
}
