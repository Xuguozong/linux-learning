package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/21.
 */
public class StatefulSetDetailVO implements Serializable {
    private static final long serialVersionUID = 1765591200059436784L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private Date createTime;

    private List<String> images;

    private PodInfoVO podInfo;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public PodInfoVO getPodInfo() {
        return podInfo;
    }

    public void setPodInfo(PodInfoVO podInfo) {
        this.podInfo = podInfo;
    }
}
