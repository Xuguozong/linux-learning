package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public class ServiceDetailVO implements Serializable {
    private static final long serialVersionUID = 2680753113655422407L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private Date createTime;

    private Map<String, String> selectors;

    private String type;

    private String clusterIP;

    private ServiceItemVO.EndpointVO internalEndpoint;

    private List<ServiceItemVO.EndpointVO> externalEndpoints;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Map<String, String> getSelectors() {
        return selectors;
    }

    public void setSelectors(Map<String, String> selectors) {
        this.selectors = selectors;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getClusterIP() {
        return clusterIP;
    }

    public void setClusterIP(String clusterIP) {
        this.clusterIP = clusterIP;
    }

    public ServiceItemVO.EndpointVO getInternalEndpoint() {
        return internalEndpoint;
    }

    public void setInternalEndpoint(ServiceItemVO.EndpointVO internalEndpoint) {
        this.internalEndpoint = internalEndpoint;
    }

    public List<ServiceItemVO.EndpointVO> getExternalEndpoints() {
        return externalEndpoints;
    }

    public void setExternalEndpoints(List<ServiceItemVO.EndpointVO> externalEndpoints) {
        this.externalEndpoints = externalEndpoints;
    }
}
