package com.hikvision.hae.image.web.restful;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.image.service.UploadRecordService;
import com.hikvision.hae.image.service.UploadService;
import com.hikvision.hae.image.vo.UploadFileItemVO;
import com.hikvision.hae.image.vo.UploadFileVO;
import com.hikvision.hae.img.common.constant.ImageResultCode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/api/file/v1")
@Api(description = "镜像文件上传")
public class UploadRestful {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UploadService uploadService;

	@Resource
	private UploadRecordService uploadRecordService;

	@ApiOperation(value = "上传文件记录列表")
	@GetMapping("/uploads")
	public AjaxResult<List<UploadFileItemVO>> fileList() {
		AjaxResult<List<UploadFileItemVO>> result = AjaxResult.buildSuccess();
		result.setData(uploadRecordService.getUploadRecordList());
		return result;
	}

	/**
	 * 删除、清空上传记录
	 *
	 * @param uploadIds
	 * @return
	 */
	@ApiOperation(value = "删除上传文件记录")
	@DeleteMapping("/upload")
	public AjaxResult<Void> deleteUploadHistoryById(@RequestBody String[] uploadIds) {
		AjaxResult<Void> result = AjaxResult.buildSuccess();
		if (uploadIds != null) {
			for (String fileId : uploadIds) {
				uploadRecordService.deleteUploadRecord(fileId);
			}
		}
		return result;
	}

	/**
	 * 上传文件
	 *
	 * @param uploadFile
	 * @param uploadVO
	 * @return
	 */
	@ApiOperation(value = "上传文件")
	@PostMapping("/upload")
	public AjaxResult<Void> upload(MultipartFile uploadFile, UploadFileVO uploadVO) {
		logger.info("开始文件上传:{}", uploadVO.toString());
		AjaxResult<Void> result = AjaxResult.buildSuccess();
		if (uploadFile == null) {
			throw new HAERuntimeException(ImageResultCode.UPLOADFILE_DONOT_EXIST);
		}
		uploadService.preUpload(uploadFile, uploadVO);
		uploadService.upload(uploadFile, uploadVO);
		uploadService.postUpload(uploadFile, uploadVO);
		return result;
	}

	@ApiOperation(value = "中断上传")
	@PutMapping("/upload/{fileId}/interrupt")
	public AjaxResult<Void> interruptUpload(@PathVariable String fileId) {
		uploadService.interruptUpload(fileId);
		return AjaxResult.buildSuccess();
	}

}
