package com.hikvision.hae.image.job;

import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.image.service.UploadRecordService;
import com.hikvision.hae.image.service.UploadStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * 定义修改上传中断的上传记录
 * @author qiuzhihao
 *
 */
@Configuration
@ConditionalOnProperty(prefix = "image", name = "enabled", havingValue = "true", matchIfMissing = true)
public class UploadFileJob {
	
	private static final Logger logger = LoggerFactory.getLogger(UploadFileJob.class);
	
	/**
	 * 上传文件超时时间，每段文件上传都会更新修改时间
	 */
	private static final int UPLOAD_TIMEOUT = 30 * 1000;
	
	@Resource
	private UploadRecordService uploadRecordSvc;
	
	@Resource
	private UploadFileBiz uploadFileBiz;
	
	@Resource
	private UploadStatusService statusSvc;
	
	@Scheduled(fixedDelayString = "${job.config.changeUploadBreakInterval:10000}")
	public void changeUploadBreakTaskStatus() {
		try {
			List<UploadFile> uploadingList = uploadRecordSvc.uploadFileMiddleStatusList();
			if(uploadingList != null) {
				uploadingList.forEach(file -> {
					Date modifyTime = file.getModifed();
					if(System.currentTimeMillis() - modifyTime.getTime() >= UPLOAD_TIMEOUT) {
						statusSvc.updateToUploadBreak(file.getFileId());
						logger.info("更新文件id：{}，name：{}状态到中断状态", file.getFileId(), file.getFileName());
					}
				});
			}
		} catch (Exception e) {
			logger.warn("修改上传中断记录状态Job出现异常", e);
		}
	}
}
