package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.persistentvolume.biz.PersistentVolumeBiz;
import com.hikvision.hae.resource.service.PersistentVolumeService;
import com.hikvision.hae.resource.vo.PersistentVolumeDetailVO;
import com.hikvision.hae.resource.vo.PersistentVolumeItemVO;
import io.fabric8.kubernetes.api.model.PersistentVolume;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
@Service
public class PersistentVolumeServiceImpl implements PersistentVolumeService {
    private static final Logger logger = LoggerFactory.getLogger(PersistentVolumeServiceImpl.class);

    @Resource
    private PersistentVolumeBiz persistentVolumeBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PersistentVolumeItemVO> findAndPage(String name, PageParam pageParam) {
        FilterQuery filterQuery = FilterQuery.build().name(name);
        Pagination<PersistentVolume> persistentVolumePage = persistentVolumeBiz.findAndPage(filterQuery, pageParam);
        if (persistentVolumePage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<Collection<PersistentVolume>, Collection<PersistentVolumeItemVO>> rowsConverter =
                (Collection<PersistentVolume> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildPersistentVolumeItemVO).collect(Collectors.toList());
        return new Pagination<>(persistentVolumePage, rowsConverter);
    }

    @Override
    public PersistentVolumeDetailVO getDetail(String name) {
        PersistentVolume persistentVolume = persistentVolumeBiz.getByName(null, name);
        if (persistentVolume == null) {
            DelayedLogger.error(logger, () -> "不存在PersistentVolume[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.PERSISTENTVOLUME_NOT_EXIST);
        }

        return ResourceVOBuilder.buildPersistentVolumeDetailVO(persistentVolume);
    }

    @Override
    public void delete(String name) {
        persistentVolumeBiz.delete(null, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.PERSISTENT_VOLUME, PrincipalCategory.PERSISTENT_VOLUME,
                null, name, "删除持久化存储卷（PersistentVolume）");
    }
}
