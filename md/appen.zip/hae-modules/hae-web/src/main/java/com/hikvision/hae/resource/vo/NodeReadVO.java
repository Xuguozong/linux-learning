package com.hikvision.hae.resource.vo;

/**
 * Created by zhanjiejun on 2017/11/18.
 */
public class NodeReadVO {

	private NodeBaseVO baseInfo;

	private NodeResourceVO resourceInfo;

	public NodeBaseVO getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(NodeBaseVO baseInfo) {
		this.baseInfo = baseInfo;
	}

	public NodeResourceVO getResourceInfo() {
		return resourceInfo;
	}

	public void setResourceInfo(NodeResourceVO resourceInfo) {
		this.resourceInfo = resourceInfo;
	}
}
