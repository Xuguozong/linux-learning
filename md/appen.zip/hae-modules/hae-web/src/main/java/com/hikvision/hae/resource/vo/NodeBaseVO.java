package com.hikvision.hae.resource.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/16.
 */
public class NodeBaseVO {

	private int id;

	private String name;

	private String statusName;

	private String status;

	private String ip;

	private Date createTime;

	/**
	 * cpu cores
	 * memory Gi Bytes
	 * gpu 张
	 */
	private Map<String, String> capacity;

	private Map<String, String> allocatable;

	private List<LabelVO> labels;

	/**
	 * 是否master节点
	 */
	private boolean master;

	/**
	 * 是否ansibel节点
	 */
	private boolean ansible;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Map<String, String> getCapacity() {
		return capacity;
	}

	public void setCapacity(Map<String, String> capacity) {
		this.capacity = capacity;
	}

	public Map<String, String> getAllocatable() {
		return allocatable;
	}

	public void setAllocatable(Map<String, String> allocatable) {
		this.allocatable = allocatable;
	}

	public List<LabelVO> getLabels() {
		return labels;
	}

	public void setLabels(List<LabelVO> labels) {
		this.labels = labels;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public boolean isMaster() {
		return master;
	}

	public void setMaster(boolean master) {
		this.master = master;
	}

	public boolean isAnsible() {
		return ansible;
	}

	public void setAnsible(boolean ansible) {
		this.ansible = ansible;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
