package com.hikvision.hae.foundation.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.foundation.vo.LogTableVO;
import com.hikvision.hae.foundation.vo.LogVO;
import com.hikvision.hae.log.dto.LogQuery;

import java.util.List;

/**
 * 接口功能描述：日志查询类
 *
 * Created by zhouziwei on 2017/11/9.
 */
public interface LogService {

    /**
     * 批量保存日志
     *
     * @param logs
     */
    public void batchAdd(List<LogVO> logs);


    /**
     * 分页查询日志
     *
     * @param logQuery
     */
    public Pagination<LogTableVO> findAndPage(LogQuery logQuery, PageParam pageParam);


    /**
     * 下载最近7天日志
     *
     * @param logQuery
     */
    List<LogTableVO> download(LogQuery logQuery);

    /**
     * 根据命名空间查询Pod列表
     * @param namespace
     * @return
     */
    List<Select2VO> getPodsByNamespace(String namespace);


    /**
     * 根据命名空间和pod查询container列表
     * @param namespace
     * @param podName
     * @return
     */
    List<Select2VO> getContainersByNamespaceAndPod(String namespace, String podName);

}
