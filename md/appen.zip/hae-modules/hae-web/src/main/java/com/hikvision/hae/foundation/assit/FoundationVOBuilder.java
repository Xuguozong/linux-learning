package com.hikvision.hae.foundation.assit;

import com.hikvision.hae.foundation.user.dto.UserDTO;
import com.hikvision.hae.foundation.vo.UserReadVO;

public class FoundationVOBuilder {

	public static UserReadVO buildUserReadVO(UserDTO userDTO) {
		UserReadVO userReadVO = new UserReadVO();
		userReadVO.setId(userDTO.getId());
		userReadVO.setUserName(userDTO.getUsername());
		userReadVO.setRealName(userDTO.getRealName());
		userReadVO.setEmail(userDTO.getEmail());
		userReadVO.setPhone(userDTO.getPhoneNumber());
		userReadVO.setPwdStrength(userDTO.getPwdStrength());
		return userReadVO;
	}

}
