package com.hikvision.hae.resource.vo;

/**
 * Created by zhanjiejun on 2017/11/15.
 */
public class NodeWriteVO {

	private String name;

	private String ip;

	/**
	 * 需要RSA解密
	 */
	private String sshPwd;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getSshPwd() {
		return sshPwd;
	}

	public void setSshPwd(String sshPwd) {
		this.sshPwd = sshPwd;
	}
}
