package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/24.
 */
public class StorageClassVO implements Serializable {
    private static final long serialVersionUID = -902735729008906947L;

    private String name;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private String provisioner;

    private Map<String, String> parameters;

    private Date createTime;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public String getProvisioner() {
        return provisioner;
    }

    public void setProvisioner(String provisioner) {
        this.provisioner = provisioner;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
