package com.hikvision.hae.image.vo;

public class RepositoryConfigVO {

	private String baseHost;

	public String getBaseHost() {
		return baseHost;
	}

	public void setBaseHost(String baseHost) {
		this.baseHost = baseHost;
	}
}
