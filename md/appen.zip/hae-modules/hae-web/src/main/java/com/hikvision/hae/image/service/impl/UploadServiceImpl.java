package com.hikvision.hae.image.service.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.eventcenter.enums.ImageActionType;
import com.hikvision.hae.file.biz.UploadConfigBiz;
import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.biz.dto.CreateUploadFileDTO;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.listener.PushFileEvent;
import com.hikvision.hae.image.listener.PushListener;
import com.hikvision.hae.image.service.UploadService;
import com.hikvision.hae.image.service.UploadStatusService;
import com.hikvision.hae.image.vo.UploadFileVO;
import com.hikvision.hae.img.common.constant.ImageResultCode;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class UploadServiceImpl extends BaseImageService implements UploadService {

	private static final Logger logger = LoggerFactory.getLogger(UploadServiceImpl.class);

	@Resource
	private UploadFileBiz uploadBiz;

	@Resource
	private UploadConfigBiz configService;

	@Resource
	private UploadStatusService statusService;

	@Resource
	private PushListener pushListener;

	private List<UploadStatus> legalState;

	private AtomicLong index = new AtomicLong(1);

	@PostConstruct
	public void init() {
		legalState = new ArrayList<>(2);
		legalState.add(UploadStatus.UPLOADING);
		legalState.add(UploadStatus.UPLOAD_BREAK);
	}

	@Override
	public void preUpload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		String fileId = uploadInfo.getId();
		String originalFileName = uploadInfo.getFileName();
		UploadFile file = uploadBiz.getById(fileId, true);
		if (file == null) {
			String configPath = configService.uploadLocation();
			File saveParentPath = new File(new File(configPath), originalFileName + index.getAndIncrement());

			CreateUploadFileDTO createDTO = new CreateUploadFileDTO();
			createDTO.setFileId(uploadInfo.getId());
			createDTO.setNativePath(uploadInfo.getNativePath());
			createDTO.setFileName(originalFileName);
			createDTO.setCurrentTrunk(1);
			createDTO.setTotalChunks(uploadInfo.getTrunks());
			createDTO.setTmpSavePath(saveParentPath.getAbsolutePath());
			createDTO.setTotalSize(uploadInfo.getTotalSize());
			file = uploadBiz.create(createDTO);
			// fire event
			statusService.updateToUploading(fileId);
			publishActionLog(ImageActionType.UPLOAD, file.getFileName(), "上传镜像文件");
			logger.info("新建文件上传记录：{}", file);
		} else {
			if (!legalState.contains(file.getStatus())) {
				logger.warn("当前状态不允许上传文件片段{}", file.toString());
				throw new HAERuntimeException(ImageResultCode.ILLEGAL_UPLOAD_STATUS_ERROR);
			}
			if (UploadStatus.UPLOAD_BREAK == file.getStatus()) {
				if (uploadInfo.getTrunk() == file.getCurrentTrunk() && uploadInfo.getTrunks() == file.getTotalChunks()) {
					logger.info("恢复文件{}断点上传", file.getFileName());
					// TODO 检查原有片段是否完整
					statusService.updateToUploading(uploadInfo.getId());
					publishActionLog(ImageActionType.BREAKPOINT_UPLOAD, file.getFileName(), "继续断点上传镜像文件");
				} else {
					logger.error("恢复断点上传信息不正确，上传记录信息：{}，当前请求信息：{}", file.toString(), uploadInfo.toString());
					throw new HAERuntimeException(ImageResultCode.ILLEGAL_UPLOADBREAK_ERROR);
				}
			}
		}
	}

	@Override
	public void upload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		UploadFile file = uploadBiz.getById(uploadInfo.getId(), false);
		// save upload part
		File saveParentPath = new File(file.getFilePath());
		if (!saveParentPath.exists()) {
			saveParentPath.mkdirs();
		}
		File currentFile = new File(saveParentPath, String.valueOf(uploadInfo.getTrunk()));
		try {
			uploadFile.transferTo(currentFile);
		} catch (IllegalStateException | IOException e) {
			throw new HAERuntimeException(ImageResultCode.SAVE_UPLOADFILE_TRUNK_ERROR, e);
		}
		// check MD5
		try (FileInputStream md5Stream = new FileInputStream(currentFile)) {
			String currentPartMD5 = DigestUtils.md5Hex(md5Stream);
			if (!uploadInfo.getMd5Checksum().equalsIgnoreCase(currentPartMD5)) {
				logger.info("当前上传块MD5：{}，客户端MD5：{}", currentPartMD5, uploadInfo.getMd5Checksum());
				throw new HAERuntimeException(ImageResultCode.BAD_UPLOADFILE_CHECKSUM);
			}
		} catch (IOException e) {
			throw new HAERuntimeException(ImageResultCode.BAD_UPLOADFILE_CHECKSUM, e);
		}
		uploadBiz.updateCurrentTrunk(uploadInfo.getId(), uploadInfo.getTrunk());
	}

	@Override
	public void postUpload(MultipartFile uploadFile, UploadFileVO uploadInfo) {
		if (uploadInfo.getTrunk() == uploadInfo.getTrunks()) {
			UploadFile file = uploadBiz.getById(uploadInfo.getId(), false);
			String fileId = file.getFileId();
			String fileName = file.getFileName();
			logger.info("文件{}各段上传完毕，开始合并文件", file);
			File uploadDir = new File(file.getFilePath());
			File[] uploadParts = uploadDir.listFiles();
			if (uploadParts.length != file.getTotalChunks()) {
				logger.error("上传临时文件夹中的分片数量与实际记录的分片数量不一致");
				statusService.updateToUploadError(fileId, "临时文件夹中保存的文件不完整");
			} else {
				Arrays.sort(uploadParts, new Comparator<File>() {
					@Override
					public int compare(File f1, File f2) {
						String f1Name = f1.getName();
						String f2Name = f2.getName();
						return Integer.parseInt(f1Name) - Integer.parseInt(f2Name);
					}
				});
				File outFile = new File(file.getFilePath(), fileName);
				boolean mergeSuccess = true;
				try (FileOutputStream fout = new FileOutputStream(outFile)) {
					FileChannel outChannel = fout.getChannel();
					long copyCount = 0;
					for (File f : uploadParts) {
						try (FileChannel inChannel = new FileInputStream(f).getChannel()) {
							inChannel.transferTo(0, inChannel.size(), outChannel);
							copyCount += inChannel.size();
						}
						if (!f.delete()) {
							logger.warn("删除文件分片失败{}", f.getAbsolutePath());
						}
					}
					if (copyCount != file.getTotalSize()) {
						statusService.updateToUploadError(fileId, "镜像文件上传不完整");
						logger.error("合并文件id:{} name:{}失败，合成后文件大小：{}和上传文件大小：{}不相等", fileId, fileName, copyCount, file.getTotalSize());
						mergeSuccess = false;
					} else {
						statusService.updateToUploaded(fileId);
						logger.info("合并上传文件id:{} name:{}成功", fileId, fileName);
					}
				} catch (IOException e) {
					statusService.updateToUploadError(fileId, StringUtils.isEmpty(e.getMessage()) ? "合并镜像文件失败" : e.getMessage());
					mergeSuccess = false;
				}

				if (mergeSuccess) {
					PushFileEvent pushEvent = new PushFileEvent(file, outFile);
					pushListener.process(pushEvent);
				}
			}
		}
	}

	@Override
	public void interruptUpload(String fileId) {
		UploadFile file = uploadBiz.getById(fileId, true);
		if (file == null) {
			throw new HAERuntimeException(ImageResultCode.UPLOADFILE_DONOT_EXIST);
		}
		if (UploadStatus.UPLOADING != file.getStatus()) {
			throw new HAERuntimeException(ImageResultCode.INTERRUPT_UPLOADING_FILE_ONLY);
		}
		statusService.updateToUploadBreak(fileId);
	}

}
