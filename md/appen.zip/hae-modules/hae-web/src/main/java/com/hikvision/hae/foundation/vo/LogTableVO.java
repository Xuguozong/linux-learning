package com.hikvision.hae.foundation.vo;

import com.hikvision.hae.log.model.Log;

import java.io.Serializable;
import java.util.Date;

/**
 * 日志需要显示在前端的数据
 *
 * Created by zhouziwei on 2017/11/9.
 */
public class LogTableVO implements Serializable{

    private static final long serialVersionUID = 9178528318235493289L;

    private Long id;

    private Date time;

    private String logMessage;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getLogMessage() {
        return logMessage;
    }

    public void setLogMessage(String logMessage) {
        this.logMessage = logMessage;
    }

    public static LogTableVO readFromModel(Log model) {
        LogTableVO vo = new LogTableVO();
        vo.setTime(model.getTime());
        vo.setLogMessage(model.getLog());
        return vo;
    }
}
