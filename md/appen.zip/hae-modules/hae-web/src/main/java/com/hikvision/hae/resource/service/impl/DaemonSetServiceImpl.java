package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.daemonset.DaemonSetBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.service.DaemonSetService;
import com.hikvision.hae.resource.vo.DaemonSetDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.fabric8.kubernetes.api.model.extensions.DaemonSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
@org.springframework.stereotype.Service
public class DaemonSetServiceImpl implements DaemonSetService {
    private static final Logger logger = LoggerFactory.getLogger(DaemonSetServiceImpl.class);

    @Resource
    private DaemonSetBiz daemonSetBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<DaemonSet> daemonSetPage = daemonSetBiz.findAndPage(filterQuery, pageParam);
        if (daemonSetPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        Function<DaemonSet, PodInfo> podInfoFunc = (DaemonSet daemonSet) ->
                podBiz.getPodInfo(daemonSet.getSpec().getSelector(), namespace, daemonSet.getStatus().getCurrentNumberScheduled(),
                        daemonSet.getStatus().getDesiredNumberScheduled(), daemonSet.getMetadata().getUid());
        Function<Collection<DaemonSet>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<DaemonSet> dtoList) -> dtoList.stream()
                        .map(daemon -> ResourceVOBuilder.buildPodControllerItemVO(daemon, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(daemonSetPage, rowsConverter);
    }

    @Override
    public DaemonSetDetailVO getDetail(String namespace, String name) {
        //DaemonSet基础属性
        DaemonSet daemonSet = daemonSetBiz.getByName(namespace, name);
        if (daemonSet == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在DaemonSet[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.DAEMONSET_NOT_EXIST);
        }
        DaemonSetDetailVO vo = new DaemonSetDetailVO();
        vo.setNamespace(daemonSet.getMetadata().getNamespace());
        vo.setName(daemonSet.getMetadata().getName());
        vo.setLabels(daemonSet.getMetadata().getLabels());
        vo.setAnnotations(daemonSet.getMetadata().getAnnotations());
        vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(daemonSet.getMetadata().getCreationTimestamp().getTime()));
        vo.setImages(ResourceVOBuilder.getContainerImages(daemonSet.getSpec().getTemplate()));
        PodInfo podInfo = podBiz.getPodInfo(daemonSet.getSpec().getSelector(), namespace, daemonSet.getStatus().getCurrentNumberScheduled(),
                daemonSet.getStatus().getDesiredNumberScheduled(), daemonSet.getMetadata().getUid());
        vo.setPodInfo(ResourceVOBuilder.buildPodInfoVO(podInfo));
        return vo;
    }

    @Override
    public void delete(String namespace, String name) {
        daemonSetBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.DAEMON_SET, PrincipalCategory.DAEMON_SET, namespace, name, "删除守护进程集（DaemonSet）");
    }
}
