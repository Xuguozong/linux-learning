package com.hikvision.hae.common.vo;

import java.util.ArrayList;
import java.util.List;

public class BatchOperResultVO {

	private List<OperResult> successList;

	private List<OperResult> failList;

	public BatchOperResultVO() {
		successList = new ArrayList<>();
		failList = new ArrayList<>();
	}

	public List<OperResult> getSuccessList() {
		return successList;
	}

	public void setSuccessList(List<OperResult> successList) {
		this.successList = successList;
	}

	public void addSuccessResult(OperResult success) {
		successList.add(success);
	}

	public List<OperResult> getFailList() {
		return failList;
	}

	public void setFailList(List<OperResult> failList) {
		this.failList = failList;
	}

	public void addFailResult(OperResult fail) {
		this.failList.add(fail);
	}

	public static class OperResult {
		private int code;

		private String message;

		private String resId;

		private String resNamespace;

		private String resName;

        public OperResult() {
        }

        public static OperResult build(){
            return new OperResult();
        }

        // ------ Fluent methods
        public OperResult code(int code){
            this.code = code;
            return this;
        }

        public OperResult message(String message){
            this.message = message;
            return this;
        }

        public OperResult resId(String resId){
            this.resId = resId;
            return this;
        }

        public OperResult resNamespace(String resNamespace){
            this.resNamespace = resNamespace;
            return this;
        }

        public OperResult resName(String resName){
            this.resName = resName;
            return this;
        }

        // ------ getters and setters

        public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getResId() {
			return resId;
		}

		public void setResId(String resId) {
			this.resId = resId;
		}

		public String getResName() {
			return resName;
		}

		public void setResName(String resName) {
			this.resName = resName;
		}
	}
}
