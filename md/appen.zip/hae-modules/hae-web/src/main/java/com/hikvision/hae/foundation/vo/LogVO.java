package com.hikvision.hae.foundation.vo;

import com.hikvision.hae.log.model.Log;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhouziwei on 2017/11/10.
 */
public class LogVO implements Serializable {

    private static final long serialVersionUID = -9035893585320019858L;

    private Long id;

    private String time;

    private String podName;

    private String containerName;

    private String namespaceName;

    private String log;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPodName() {
        return podName;
    }

    public void setPodName(String podName) {
        this.podName = podName;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public String getNamespaceName() {
        return namespaceName;
    }

    public void setNamespaceName(String namespaceName) {
        this.namespaceName = namespaceName;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public static Log readToModel(LogVO vo) {
        Log log = new Log();
        log.setLog(vo.getLog());
        log.setTime(new Date(Long.parseLong(vo.getTime())));
        log.setContainerName(vo.getContainerName());
        log.setPodName(vo.getPodName());
        log.setNamespaceName(vo.getNamespaceName());
        return log;
    }
}
