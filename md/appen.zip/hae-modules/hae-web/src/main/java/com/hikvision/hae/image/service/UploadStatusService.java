package com.hikvision.hae.image.service;

public interface UploadStatusService {
	
	void updateToUploading(String fileId);
	
	void updateToUploadBreak(String fileId);
	
	void updateToUploaded(String fileId);
	
	void updateToUploadError(String fileId, String reason);
	
	void updateToPushing(String fileId);
	
	void updateToPushError(String fileId, String reason);
	
	void updateToPushed(String fileId);
}
