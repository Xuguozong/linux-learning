package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.replicationcontroller.biz.ReplicationControllerBiz;
import com.hikvision.hae.resource.service.ReplicationControllerService;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.ReplicationControllerDetailVO;
import io.fabric8.kubernetes.api.model.ReplicationController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
@org.springframework.stereotype.Service
public class ReplicationControllerServiceImpl implements ReplicationControllerService {
    private static final Logger logger = LoggerFactory.getLogger(ReplicationControllerServiceImpl.class);

    @Resource
    private ReplicationControllerBiz replicationControllerBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;


    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, labels);
        Pagination<ReplicationController> replicationControllerPage = replicationControllerBiz.findAndPage(filterQuery, pageParam);
        if (replicationControllerPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        Function<ReplicationController, PodInfo> podInfoFunc = (ReplicationController rc) ->
                podBiz.getPodInfo(rc.getSpec().getSelector(), namespace, rc.getStatus().getReplicas(),
                        rc.getSpec().getReplicas(), rc.getMetadata().getUid());
        Function<Collection<ReplicationController>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<ReplicationController> dtoList) ->
                        dtoList.stream()
                                .map(rc -> ResourceVOBuilder.buildPodControllerItemVO(rc, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(replicationControllerPage, rowsConverter);
    }

    @Override
    public ReplicationControllerDetailVO getDetail(String namespace, String name) {
        //ReplicationController基础属性
        ReplicationController replicationController = replicationControllerBiz.getByName(namespace, name);
        if (replicationController == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在ReplicationController[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.REPLICATION_CONTROLLER_NOT_EXIST);
        }
        ReplicationControllerDetailVO vo = new ReplicationControllerDetailVO();
        vo.setNamespace(replicationController.getMetadata().getNamespace());
        vo.setName(replicationController.getMetadata().getName());
        vo.setLabels(replicationController.getMetadata().getLabels());
        vo.setAnnotations(replicationController.getMetadata().getAnnotations());
        vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(replicationController.getMetadata().getCreationTimestamp().getTime()));
        vo.setSelectors(replicationController.getSpec().getSelector());
        vo.setImages(ResourceVOBuilder.getContainerImages(replicationController.getSpec().getTemplate()));
        PodInfo podInfo = podBiz.getPodInfo(replicationController.getSpec().getSelector(), namespace, replicationController.getStatus().getReplicas(),
                replicationController.getSpec().getReplicas(), replicationController.getMetadata().getUid());
        vo.setPodInfo(ResourceVOBuilder.buildPodInfoVO(podInfo));
        return vo;
    }

    @Override
    public void scale(String namespace, String name, int newReplicas) {
        replicationControllerBiz.scale(namespace, name, newReplicas);
        kubeEventHelper.publishScaleEvent(ActionLogModules.REPLICATION_CONTROLLER, PrincipalCategory.REPLICATION_CONTROLLER,
                namespace, name, "伸缩副本控制器（ReplicationController）");
    }

    @Override
    public void delete(String namespace, String name) {
        replicationControllerBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.REPLICATION_CONTROLLER, PrincipalCategory.REPLICATION_CONTROLLER,
                namespace, name, "删除副本控制器（ReplicationController）");
    }
}
