package com.hikvision.hae.image.listener.impl;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.image.listener.PushFileEvent;
import com.hikvision.hae.image.listener.PushListener;
import com.hikvision.hae.image.service.UploadStatusService;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.biz.ImageUploadBiz;
import com.hikvision.hae.img.biz.dto.UploadImageDTO;
import org.springframework.util.StringUtils;

@Service
public class DefaultPushListener implements PushListener {
	
	private static Logger logger = LoggerFactory.getLogger(DefaultPushListener.class);

	@Resource
	private ImageRepositoryConfigBiz configService;
	
	@Resource
	private UploadStatusService statusService;
	
	@Resource
	private ImageUploadBiz uploadImgBiz;
	
	@Resource
	private UploadFileBiz uploadFileBiz;
	
	/**
	 * 异步推送镜像文件
	 */
	@Async("getDockerPushPool")
	@Override
	public void process(PushFileEvent event) {
		UploadImageDTO uploadDTO = new UploadImageDTO(configService.accessInfo());
		
		uploadDTO.setFileId(event.getUploadRecord().getFileId());
		try(InputStream fin = new BufferedInputStream(new FileInputStream(event.getPushFile()), 1024 * 32)){
			uploadDTO.setImageStream(fin);
			logger.info("开始镜像{}推送", event.getUploadRecord().getFileName());
			statusService.updateToPushing(event.getUploadRecord().getFileId());
			uploadImgBiz.uploadImage(uploadDTO);
			statusService.updateToPushed(event.getUploadRecord().getFileId());
			logger.info("结束镜像{}推送", event.getUploadRecord().getFileName());
		} catch (Exception e) {
			statusService.updateToPushError(event.getUploadRecord().getFileId(),
					StringUtils.isEmpty(e.getMessage()) ? "向harbor推送镜像失败" : e.getMessage());
			logger.error("推送镜像{}", event.getUploadRecord(), e);
		}
	}

}
