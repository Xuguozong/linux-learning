package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.foundation.service.LogService;
import com.hikvision.hae.foundation.vo.LogTableVO;
import com.hikvision.hae.foundation.vo.LogVO;
import com.hikvision.hae.log.common.constant.LogResultCode;
import com.hikvision.hae.log.dto.LogQuery;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 日志Ajax请求处理器
 * <p>
 * Created by zhouziwei on 2017/11/10.
 */
@Api(description = "应用日志")
@RestController
@RequestMapping(value = "/api/log/v1")
public class LogRestful {

    private static final Logger logger = LoggerFactory.getLogger(LogRestful.class);

    @Resource
    private LogService logService;


    @PostMapping("/logs")
    public AjaxResult<Void> batchInsert(@RequestBody LogVO[] logs) {
        if (logs == null) {
            return new AjaxResult<>(LogResultCode.LOG_EMPTY);
        }
        try {
            logService.batchAdd(Arrays.asList(logs));
        } catch (Exception e) {
            DelayedLogger.error(logger, () -> "批量插入容器日志失败", e);
            return new AjaxResult<>(LogResultCode.LOG_INSERT_FAIL);
        }
        return new AjaxResult<>(CommonResultCode.SUCCESS);
    }

    @GetMapping("/logs/{pageSize}/{pageNo}")
    public AjaxResult<Pagination<LogTableVO>> findAndPage(@PathVariable int pageSize,
                                                          @PathVariable int pageNo,
                                                          @RequestParam Long startTime,
                                                          @RequestParam Long endTime,
                                                          @RequestParam String namespace,
                                                          @RequestParam String pod,
                                                          @RequestParam String container) {
        PageParam pageParam = new PageParam();
        pageParam.setPageNo(pageNo);
        pageParam.setPageSize(pageSize);
        LogQuery logQuery = new LogQuery();
        logQuery.setNamespaceName(namespace);
        logQuery.setPodName(pod);
        logQuery.setContainerName(container);
        logQuery.setStartTime(new Date(startTime));
        logQuery.setEndTime(new Date(endTime));

        Pagination<LogTableVO> pagination = logService.findAndPage(logQuery, pageParam);
        return new AjaxResult<>(CommonResultCode.SUCCESS, pagination);
    }

    @GetMapping("/namespaces/{namespace}/pods")
    public AjaxResult<List<Select2VO>> getPodsByNamespace(@PathVariable String namespace) {
        AjaxResult<List<Select2VO>> result = AjaxResult.buildSuccess();
        List<Select2VO> podList = logService.getPodsByNamespace(namespace);
        result.setData(podList);
        return result;
    }

    @GetMapping("/namespaces/{namespace}/pods/{pod}/containers")
    public AjaxResult<List<Select2VO>> getContainerByNamespaceAndPod(@PathVariable String namespace,
                                                                     @PathVariable String pod) {
        AjaxResult<List<Select2VO>> result = AjaxResult.buildSuccess();
        List<Select2VO> containerList = logService.getContainersByNamespaceAndPod(namespace, pod);
        result.setData(containerList);
        return result;
    }

}
