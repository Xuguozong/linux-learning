package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Pod的controller：ReplicationController、ReplicaSet
 *
 * @author jianghaiyang5 on 2017/11/13.
 */
public class PodControllerItemVO implements Serializable {
    private static final long serialVersionUID = 8072075736373450417L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private Integer runningPods;

    private Integer desiredPods;

    private List<String> images;

    private Date createTime;

    private String type;
    
    // 警告信息
    private List<String> warningMessages;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Integer getRunningPods() {
        return runningPods;
    }

    public void setRunningPods(Integer runningPods) {
        this.runningPods = runningPods;
    }

    public Integer getDesiredPods() {
        return desiredPods;
    }

    public void setDesiredPods(Integer desiredPods) {
        this.desiredPods = desiredPods;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	public List<String> getWarningMessages() {
		return warningMessages;
	}

	public void setWarningMessages(List<String> warningMessages) {
		this.warningMessages = warningMessages;
	}
    
    
}
