/**
 * 
 */
package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ServiceAccountDetailVO;
import com.hikvision.hae.resource.vo.ServiceAccountListVO;

/**
 * @author qihongfei
 *
 */
public interface ServiceAccountService {

	/**
     * 分页查询ServiceAccount
     *
     * @param namespace 命名空间
     * @param name      ServiceAccount名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<ServiceAccountListVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看ServiceAccount详情
     *
     * @param namespace 命名空间
     * @param name      ServiceAccount名称
     * @return ServiceAccount详情
     */
    ServiceAccountDetailVO getDetail(String namespace, String name);

    /**
     * 删除ServiceAccount
     *
     * @param namespace 命名空间
     * @param name      ServiceAccount名称
     */
    void delete(String namespace, String name);
}
