package com.hikvision.hae.resource.vo;

/**
 * Created by zhanjiejun on 2017/11/10.
 */
public class NamespaceWriteVO {

	private String name;

	/**
	 * 单位（cores）
	 */
	private float cpuQuota;

	/**
	 * 单位（Gi）
	 * 1Gi bytes = 1024Mi bytes= 1024*1024 Ki bytes
	 */
	private float memoryQuota;

	/**
	 * 单位（张）
	 */
	private int gpuQuota;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getCpuQuota() {
		return cpuQuota;
	}

	public void setCpuQuota(float cpuQuota) {
		this.cpuQuota = cpuQuota;
	}

	public float getMemoryQuota() {
		return memoryQuota;
	}

	public void setMemoryQuota(float memoryQuota) {
		this.memoryQuota = memoryQuota;
	}

	public int getGpuQuota() {
		return gpuQuota;
	}

	public void setGpuQuota(int gpuQuota) {
		this.gpuQuota = gpuQuota;
	}
}
