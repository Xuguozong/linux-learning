/**
 * 
 */
package com.hikvision.hae.resource.vo;

import java.util.Date;
import java.util.Map;

/**
 * @author qihongfei
 *
 */
public class ServiceAccountDetailVO {

	private String name;

	private String namespace;

	private Date createTime;
	
	private Boolean automountServiceAccountToken;
	
	private Map<String, String> imagePullSecrets;

	private Map<String, String> secrets;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Boolean isAutomountServiceAccountToken() {
		return automountServiceAccountToken;
	}

	public void setAutomountServiceAccountToken(Boolean automountServiceAccountToken) {
		this.automountServiceAccountToken = automountServiceAccountToken;
	}

	public Map<String, String> getImagePullSecrets() {
		return imagePullSecrets;
	}

	public void setImagePullSecrets(Map<String, String> imagePullSecrets) {
		this.imagePullSecrets = imagePullSecrets;
	}

	public Map<String, String> getSecrets() {
		return secrets;
	}

	public void setSecrets(Map<String, String> secrets) {
		this.secrets = secrets;
	}
}
