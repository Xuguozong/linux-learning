package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public class DeploymentDetailVO implements Serializable {
    private static final long serialVersionUID = 8564902117590740988L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private Map<String, String> selectors;

    private String strategy;

    private Integer minReadySeconds;

    private Integer revisionHistoryLimit;

    private RollingUpdateStrategy rollingUpdateStrategy;

    private DeploymentStatusInfoVO statusInfo;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public Map<String, String> getSelectors() {
        return selectors;
    }

    public void setSelectors(Map<String, String> selectors) {
        this.selectors = selectors;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public Integer getMinReadySeconds() {
        return minReadySeconds;
    }

    public void setMinReadySeconds(Integer minReadySeconds) {
        this.minReadySeconds = minReadySeconds;
    }

    public Integer getRevisionHistoryLimit() {
        return revisionHistoryLimit;
    }

    public void setRevisionHistoryLimit(Integer revisionHistoryLimit) {
        this.revisionHistoryLimit = revisionHistoryLimit;
    }

    public RollingUpdateStrategy getRollingUpdateStrategy() {
        return rollingUpdateStrategy;
    }

    public void setRollingUpdateStrategy(RollingUpdateStrategy rollingUpdateStrategy) {
        this.rollingUpdateStrategy = rollingUpdateStrategy;
    }

    public DeploymentStatusInfoVO getStatusInfo() {
        return statusInfo;
    }

    public void setStatusInfo(DeploymentStatusInfoVO statusInfo) {
        this.statusInfo = statusInfo;
    }

    public static class RollingUpdateStrategy implements Serializable {
        private static final long serialVersionUID = 5432121006451545150L;

        private String maxSurge;
        private String maxUnavailable;

        public RollingUpdateStrategy() {
        }

        public RollingUpdateStrategy(String maxSurge, String maxUnavailable) {
            this.maxSurge = maxSurge;
            this.maxUnavailable = maxUnavailable;
        }

        public String getMaxSurge() {
            return maxSurge;
        }

        public void setMaxSurge(String maxSurge) {
            this.maxSurge = maxSurge;
        }

        public String getMaxUnavailable() {
            return maxUnavailable;
        }

        public void setMaxUnavailable(String maxUnavailable) {
            this.maxUnavailable = maxUnavailable;
        }
    }
}
