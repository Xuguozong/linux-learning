package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.PersistentVolumeClaimVO;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
public interface PersistentVolumeClaimService {

    /**
     * 分页查询PersistentVolumeClaim
     *
     * @param namespace 命名空间
     * @param name      PersistentVolumeClaim名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PersistentVolumeClaimVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看PersistentVolumeClaim详情
     *
     * @param namespace 命名空间
     * @param name      PersistentVolumeClaim名称
     * @return PersistentVolumeClaim详情
     */
    PersistentVolumeClaimVO getDetail(String namespace, String name);

    /**
     * 删除PersistentVolumeClaim
     *
     * @param namespace 命名空间
     * @param name      PersistentVolumeClaim名称
     */
    void delete(String namespace, String name);

}
