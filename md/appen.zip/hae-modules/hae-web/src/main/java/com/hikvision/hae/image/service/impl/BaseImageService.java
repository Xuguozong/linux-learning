package com.hikvision.hae.image.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.ImageActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;

public abstract class BaseImageService {

	@Autowired
	private EventPublisher eventPublisher;
	
	protected void publishActionLog(ImageActionType actionType, String resourceName, String actionDesc) {
		LoginUser loginUser = LoginUtils.getLoginUser();
		UserOperationEvent operEvent = UserOperationEvent.builder().source(ActionLogModules.IMAGE_MANAGE)
				.principalCategory(PrincipalCategory.IMAGE).actionType(actionType).actorIp(loginUser.getClientIP())
				.actorId(loginUser.getId()).principalName(resourceName).principalIndexCode("").remark(actionDesc)
				.build();
		eventPublisher.publish(operEvent);
	}
}
