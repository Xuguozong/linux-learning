package com.hikvision.hae.image.service;

import org.springframework.web.multipart.MultipartFile;

import com.hikvision.hae.image.vo.UploadFileVO;

/**
 * 文件上传
 * @author qiuzhihao
 *
 */
public interface UploadService {
	
	void preUpload(MultipartFile uploadFile, UploadFileVO uploadInfo);
	
	void upload(MultipartFile uploadFile, UploadFileVO uploadInfo);
	
	void postUpload(MultipartFile uploadFile, UploadFileVO uploadInfo);

	void interruptUpload(String fileId);

}
