package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.foundation.service.LogService;
import com.hikvision.hae.foundation.vo.LogTableVO;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import com.hikvision.hae.log.dto.LogQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.List;

/**
 * Ajax请求日志下载
 * Created by zhouziwei on 2017/11/23.
 */
@Controller
@RequestMapping(value = "/log")
public class LogDownloadRestful {

    private static final Logger logger = LoggerFactory.getLogger(LogDownloadRestful.class);

    @Resource
    private LogService logService;

    @GetMapping("/download")
    public void downloadLogs(@RequestParam Long startTime,
                             @RequestParam Long endTime,
                             @RequestParam String namespace,
                             @RequestParam String pod,
                             @RequestParam String container,
                             HttpServletResponse response) {
        LogQuery queryParam = new LogQuery();

        queryParam.setStartTime(new Date(startTime));
        queryParam.setEndTime(new Date(endTime));
        queryParam.setNamespaceName(namespace);
        queryParam.setPodName(pod);
        queryParam.setContainerName(container);

        LoginUser loginUser = LoginUtils.getLoginUser();
        List<LogTableVO> data = logService.download(queryParam);
        response.setCharacterEncoding("utf-8");
        response.setContentType("charset=utf-8; text/plain");
        String fileName = namespace + "_" + pod + "_" + container + ".log";
        response.setHeader("Content-Disposition", "attachment;fileName=" + fileName);

        try (BufferedWriter osw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream()))) {
            for (LogTableVO log : data) {
                osw.write(log.getLogMessage());
                osw.newLine();
            }
        } catch (IOException e) {
            logger.error("文件下载失败", e);
        }
    }
}
