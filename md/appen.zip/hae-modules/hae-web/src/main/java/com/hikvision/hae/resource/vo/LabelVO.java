package com.hikvision.hae.resource.vo;

import com.hikvision.hae.common.vo.KeyValue;

/**
 * Created by zhanjiejun on 2017/11/16.
 */
public class LabelVO extends KeyValue {

	/**
	 * 是否系统标签
	 */
	private boolean isSystem;

	public LabelVO() {
	}

	public LabelVO(String key, String value) {
		super(key, value);
	}

	public LabelVO(String key, String value, boolean isSystem) {
		super(key, value);
		this.isSystem = isSystem;
	}

	public boolean isSystem() {
		return isSystem;
	}

	public void setSystem(boolean system) {
		isSystem = system;
	}

}
