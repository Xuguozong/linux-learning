package com.hikvision.hae.image.web.restful;

import java.io.InputStream;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.image.service.ImageService;
import com.hikvision.hae.image.vo.RepositoryConfigVO;
import com.hikvision.hae.image.vo.RepositoryQueryVO;
import com.hikvision.hae.img.entity.ImageProjectEntity;
import com.hikvision.hae.img.entity.ImageRepositoryEntity;
import com.hikvision.hae.img.entity.ImageRepositoryTagEntity;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


/**
 * 镜像相关接口
 * *列表
 * *下载镜像
 * *删除镜像
 * *项目
 * 
 * @author qiuzhihao
 *
 */
@RestController
@RequestMapping("/api/img/v1")
@Api(description = "镜像")
public class ImageRestful {
	
	private static final Logger logger = LoggerFactory.getLogger(ImageRestful.class);

	@Resource
	private ImageService imgService;
	
	@ApiOperation(value = "分页查询项目")
	@GetMapping("/projects/pagination/{pageSize}/{pageNo}")
	public AjaxResult<Pagination<ImageProjectEntity>> projectList(@PathVariable int pageSize, @PathVariable int pageNo) {
		AjaxResult<Pagination<ImageProjectEntity>> result = AjaxResult.buildSuccess();
		PageParam pageInfo = new PageParam(pageNo, pageSize);
		result.setData(imgService.project(pageInfo));
		return result;
	}
	
	@ApiOperation(value = "创建项目")
	@PostMapping("/project")
	public AjaxResult<Void> createProject(@RequestParam String projectName) {
		imgService.createProject(projectName);
		return AjaxResult.buildSuccess();
	}
	
	@ApiOperation(value = "查询项目名称是否存在")
	@GetMapping("/project/{projectName}")
	public AjaxResult<Boolean> checkProjectName(@PathVariable String projectName) {
		AjaxResult<Boolean> result = AjaxResult.buildSuccess();
		result.setData(imgService.isProjectExist(projectName));
		return result;
	}
	
	@ApiOperation(value = "删除项目")
	@DeleteMapping("/project/{projectId}")
	public AjaxResult<Void> deleteProject(@PathVariable long projectId) {
		imgService.deleteProject(projectId);
		return AjaxResult.buildSuccess();
	}
	
	@ApiOperation(value = "分页查询项目下的仓库")
	@GetMapping("/project/{projectId}/repositorys/pagination/{pageSize}/{pageNo}")
	public AjaxResult<Pagination<ImageRepositoryEntity>> repositoryList(@PathVariable int projectId, @PathVariable int pageSize, @PathVariable int pageNo) {
		AjaxResult<Pagination<ImageRepositoryEntity>> result = AjaxResult.buildSuccess();
		RepositoryQueryVO query = new RepositoryQueryVO();
		PageParam pageParam = new PageParam(pageNo, pageSize);
		query.setPageParam(pageParam);
		query.setProjectId(projectId);
		result.setData(imgService.repository(query));
		return result;
	}
	
	@ApiOperation(value = "查询仓库下的tag列表")
	@GetMapping("/repository/tags")
	public AjaxResult<List<ImageRepositoryTagEntity>> repositoryTagList(String repoName) {
		AjaxResult<List<ImageRepositoryTagEntity>> result = AjaxResult.buildSuccess();
		result.setData(imgService.repositoryTagList(repoName));
		return result;
	}
	
	@ApiOperation(value = "删除镜像Tag")
	@DeleteMapping("/image/repository/tag")
	public AjaxResult<Void> deleteImageTag(@RequestParam String repoName, @RequestParam String tag) {
		imgService.deleteRepositoryTag(repoName, tag);
		return AjaxResult.buildSuccess();
	}
	
	@ApiOperation(value = "镜像仓库配置信息")
	@GetMapping("/config")
	public AjaxResult<RepositoryConfigVO> getRepositoryConfig() {
		AjaxResult<RepositoryConfigVO> result = AjaxResult.buildSuccess();
		result.setData(imgService.getImageRepositoryConfigData());
		return result;
	}
	
}
