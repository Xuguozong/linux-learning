package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.JobDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
public interface JobService {

    /**
     * 分页查询Job
     *
     * @param namespace 命名空间
     * @param name      Job名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam);

    /**
     * 查看Job详情
     *
     * @param namespace 命名空间
     * @param name      Job名称
     * @return Job详情
     */
    JobDetailVO getDetail(String namespace, String name);

    /**
     * 删除Job
     *
     * @param namespace 命名空间
     * @param name      Job名称
     */
    void delete(String namespace, String name);
}
