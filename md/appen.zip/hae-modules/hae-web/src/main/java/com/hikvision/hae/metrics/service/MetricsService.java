package com.hikvision.hae.metrics.service;

import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.MetricsTrendVO;

import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public interface MetricsService {

	/**
	 * 获取节点资源使用率趋势图
	 *
	 * @param nodeId      节点ID
	 * @param metricsType 指标类型
	 * @return
	 */
	MetricsTrendVO getNodeMetricsTrend(int nodeId, MetricsType metricsType);

	/**
	 * 获取节点GPU使用率
	 *
	 * @param nodeId 节点ID
	 * @return key -> GPU卡序号 value -> 使用率百分比
	 */
	Map<String, String> getNodeGpuUsage(int nodeId);

	/**
	 * 获取节点GPU趋势图
	 *
	 * @param nodeId      节点ID
	 * @param gpuIndex    GPU卡序号
	 * @param metricsType 指标类型
	 * @return
	 */
	MetricsTrendVO getNodeGpuMetricsTrend(int nodeId, String gpuIndex, MetricsType metricsType);

	/**
	 * 获取节点GPU基本信息
	 *
	 * @param nodeId   节点ID
	 * @param gpuIndex GPU卡序号
	 * @return
	 */
	GpuBaseInfo getNodeGpuBaseInfo(int nodeId, String gpuIndex);

}
