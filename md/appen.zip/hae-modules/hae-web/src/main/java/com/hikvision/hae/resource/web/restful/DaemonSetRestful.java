package com.hikvision.hae.resource.web.restful;

import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.service.DaemonSetService;
import com.hikvision.hae.resource.vo.DaemonSetDetailVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
@Api(description = "工作负载/守护进程集")
@RestController
@RequestMapping("/api/daemonSets/v1")
public class DaemonSetRestful {

    @Resource
    private DaemonSetService daemonSetService;

    /**
     * 分页查询DaemonSet
     *
     * @param namespace 命名空间
     * @param pageSize  每页记录数
     * @param pageNo    页码，从1开始
     * @param name      DaemonSet名称，模糊匹配
     * @return DaemonSet分页数据
     */
    @ApiOperation(value = "分页查询守护进程集", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "pageSize", dataType = "int", required = true, value = "页大小"),
            @ApiImplicitParam(paramType = "path", name = "pageNo", dataType = "int", required = true, value = "页码"),
            @ApiImplicitParam(paramType = "query", name = "name", dataType = "String", value = "名称")
    })
    @GetMapping("/namespace/{namespace}/pagination/{pageSize}/{pageNo}")
    public AjaxResult<Pagination<PodControllerItemVO>> findAndPage(@PathVariable String namespace,
                                                                   @PathVariable int pageSize,
                                                                   @PathVariable int pageNo,
                                                                   @RequestParam(required = false) String name) {
        PageParam pageParam = new PageParam(pageNo, pageSize);
        AjaxResult<Pagination<PodControllerItemVO>> result = AjaxResult.buildSuccess();
        result.setData(daemonSetService.findAndPage(namespace, name, pageParam));
        return result;
    }

    /**
     * 查看DaemonSet详情
     *
     * @param namespace 命名空间
     * @param name      DaemonSet名称
     * @return DaemonSet详情
     */
    @ApiOperation(value = "查询守护进程集详情", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
    })
    @GetMapping("/namespace/{namespace}/{name}")
    public AjaxResult<DaemonSetDetailVO> getDetail(@PathVariable String namespace,
                                             @PathVariable String name) {
        AjaxResult<DaemonSetDetailVO> result = AjaxResult.buildSuccess();
        result.setData(daemonSetService.getDetail(namespace, name));
        return result;
    }

    /**
     * 删除DaemonSet
     *
     * @param namespace 命名空间
     * @param name      DaemonSet名称
     */
    @ApiOperation(value = "删除守护进程集", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
            @ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
    })
    @DeleteMapping("/namespace/{namespace}/{name}")
    public AjaxResult<Void> delete(@PathVariable String namespace,
                                   @PathVariable String name) {
        daemonSetService.delete(namespace, name);
        return AjaxResult.buildSuccess();
    }
}
