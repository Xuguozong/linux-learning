package com.hikvision.hae.foundation.vo;

import com.hikvision.hae.common.i18n.Localeable;
import com.hikvision.hae.foundation.actionlog.dto.ActionLogDTO;

import java.io.Serializable;
import java.util.Date;
import java.util.function.Function;

/**
 * Created by zhouziwei on 2017/11/2.
 */
public class ActionLogVO implements Serializable{

    private static final long serialVersionUID = -3901697137629765445L;

    private int id;

    private String principalCategory;

    private String principalName;


    /**
     * 操作类别，新增/修改/删除/登录等
     */
    private String actionType;

    /**
     * 日志内容,操作描述
     */
    private String content;

    /**
     * 操作人（行为者）IP
     */
    private String actorIp;

    /**
     * 操作（动作行为）发生的时间
     */
    private Date occurTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPrincipalCategory() {
        return principalCategory;
    }

    public void setPrincipalCategory(String principalCategory) {
        this.principalCategory = principalCategory;
    }

    public String getPrincipalName() {
        return principalName;
    }

    public void setPrincipalName(String principalName) {
        this.principalName = principalName;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getActorIp() {
        return actorIp;
    }

    public void setActorIp(String actorIp) {
        this.actorIp = actorIp;
    }

    public Date getOccurTime() {
        return occurTime;
    }

    public void setOccurTime(Date occurTime) {
        this.occurTime = occurTime;
    }

    public static ActionLogVO readFromDTO(ActionLogDTO dto, Function<Localeable, String> i18nConverter) {
        ActionLogVO vo = new ActionLogVO();
        vo.setId(dto.getId());
        vo.setPrincipalCategory(i18nConverter.apply(dto.getPrincipalCategory()));
        vo.setPrincipalName(dto.getPrincipalName());
        vo.setActionType(i18nConverter.apply(dto.getActionType()));
        vo.setContent(dto.getContent());
        vo.setOccurTime(dto.getOccurTime());
        vo.setActorIp(dto.getActorIp());
        return vo;
    }
}
