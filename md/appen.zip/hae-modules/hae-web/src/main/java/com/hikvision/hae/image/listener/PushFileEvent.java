package com.hikvision.hae.image.listener;

import java.io.File;

import com.hikvision.hae.file.model.UploadFile;

public class PushFileEvent extends UploadEvent {

	private File pushFile;
	
	public PushFileEvent(UploadFile uploadRecord, File file) {
		super(uploadRecord);
		this.pushFile = file;
	}

	public File getPushFile() {
		return pushFile;
	}
}
