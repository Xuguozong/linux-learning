package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.ResourceFileActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.common.vo.BatchOperResultVO;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceDefineResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.rawresource.ResourceVerber;
import com.hikvision.hae.resource.file.biz.ResourceFileBiz;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import com.hikvision.hae.resource.file.dto.ResourceFileGroupDTO;
import com.hikvision.hae.resource.service.ResourceFileService;
import com.hikvision.hae.resource.vo.ResourceFileGroupVO;
import com.hikvision.hae.resource.vo.ResourceFileVO;
import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.client.KubernetesClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
@Service
public class ResourceFileServiceImpl implements ResourceFileService {
	private Logger logger = LoggerFactory.getLogger(ResourceFileServiceImpl.class);

	@Resource
	private KubernetesClient client;

	@Resource
	private ResourceFileBiz resourceFileBiz;

	@Resource
	private ResourceVerber resourceVerber;

	@Resource
	private KubeEventHelper kubeEventHelper;

	@Resource
	private EventPublisher eventPublisher;

	@Override
	public BatchOperResultVO deployFromFile(int fileId) {
		Map<ResourceDefineResolver.ResourceMetaInfo, String> resources = getResDefinitionFromFile(fileId);
		return deploy(resources);
	}

	private BatchOperResultVO deploy(Map<ResourceDefineResolver.ResourceMetaInfo, String> resources) {
		BatchOperResultVO batchResult = new BatchOperResultVO();
		resources.forEach((metaInfo, resourceJson) -> {
			ResourceKind kind = ResourceKind.parse(metaInfo.getKind());
			KubeOperation kubeOperation = getKubeOperation(kind);
			String namespace = adjustNamespace(kind, metaInfo.getMetadata().getNamespace());
			String name = metaInfo.getMetadata().getName();

			BatchOperResultVO.OperResult operResult = BatchOperResultVO.OperResult.build().resNamespace(namespace).resName(name);
			//检查资源是否已经存在
			String resourceId = getResourceIdentity(namespace, kind, name);
			HasMetadata kubeRes = kubeOperation.getByName(namespace, name);
			if (kubeRes != null) {
				String message = "资源[" + resourceId + "]部署失败：存在同类型同名资源";
				DelayedLogger.warn(logger, () -> message);
				operResult.message(message);
				batchResult.addFailResult(operResult);
				return;
			}

			try {
				resourceVerber.create(kind, namespace, resourceJson);
				operResult.message("资源[" + resourceId + "]部署成功");
				batchResult.addSuccessResult(operResult);
				kubeEventHelper.publishAddEvent(ActionLogModules.RESOURCE_FILE_MGMT, PrincipalCategory.parse(kind.getCode()), namespace, name, "部署资源");
			} catch (Exception e) {
				DelayedLogger.error(logger, () -> "部署资源[" + resourceId + "]异常：", e);
				operResult.message("资源[" + resourceId + "]部署失败");
				batchResult.addFailResult(operResult);
			}
		});
		return batchResult;
	}

	/**
	 * 根据资源类型调整命名空间
	 *
	 * @param kind
	 * @param namespace
	 * @return
	 */
	private String adjustNamespace(ResourceKind kind, String namespace) {
		String resultNamespace = null;
		switch (kind) {
			case PersistentVolume:
			case StorageClass:
			case ClusterRole:
			case ClusterRoleBinding:
			case ThirdPartyResource:
				// 对于以上资源，没有命名空间概念，不置空会导致部署失败
				break;
			default:
				// 对于其它必须定义命名空间的资源，不在文档里定义则默认部署到default命名空间下
				if (StringUtils.isEmpty(namespace)) {
					resultNamespace = ResourceConstants.DEFAULT_NAMESPACE;
				} else {
					resultNamespace = namespace;
				}
				break;
		}
		return resultNamespace;
	}

	@Override
	public BatchOperResultVO deployFromGroup(int groupId) {
		List<ResourceFileDTO> files = resourceFileBiz.findFilesByGroup(groupId);
		BatchOperResultVO batchResult = new BatchOperResultVO();
		if (CollectionUtils.isEmpty(files)) {
			return batchResult;
		}

		files.forEach(file -> {
			Map<ResourceDefineResolver.ResourceMetaInfo, String> resources = getResDefinitionFromFile(file);
			BatchOperResultVO tmpResult = deploy(resources);
			batchResult.getSuccessList().addAll(tmpResult.getSuccessList());
			batchResult.getFailList().addAll(tmpResult.getFailList());
		});
		return batchResult;
	}

	@Override
	public BatchOperResultVO deleteFromFile(int fileId) {
		Map<ResourceDefineResolver.ResourceMetaInfo, String> resources = getResDefinitionFromFile(fileId);
		BatchOperResultVO batchResult = new BatchOperResultVO();
		resources.forEach((metaInfo, resourceJson) -> {
			ResourceKind kind = ResourceKind.parse(metaInfo.getKind());
			KubeOperation kubeOperation = getKubeOperation(kind);
			String namespace = adjustNamespace(kind, metaInfo.getMetadata().getNamespace());
			String name = metaInfo.getMetadata().getName();
			BatchOperResultVO.OperResult operResult = BatchOperResultVO.OperResult.build().resNamespace(namespace).resName(name);
			//检查资源是否存在
			String resourceId = getResourceIdentity(namespace, kind, name);
			HasMetadata kubeRes = kubeOperation.getByName(namespace, name);
			if (kubeRes == null) {
				//资源不存在，所以就不用调用删除操作了
				operResult.message("资源[" + resourceId + "]不存在");
				batchResult.addFailResult(operResult);
				return;
			}
			try {
				KubeOperationFactory.getOperation(kind).delete(namespace, name); // 级联删除
				operResult.message("资源[" + resourceId + "]删除成功");
				batchResult.addSuccessResult(operResult);

				kubeEventHelper.publishDeleteEvent(ActionLogModules.RESOURCE_FILE_MGMT, PrincipalCategory.parse(kind.getCode()), namespace, name, "按文件删除资源");
			} catch (Exception e) {
				DelayedLogger.error(logger, () -> "删除资源[" + resourceId + "]异常：", e);
				operResult.message("资源[" + resourceId + "]删除异常");
				batchResult.addFailResult(operResult);
			}
		});
		return batchResult;
	}

	@Override
	public Pagination<ResourceFileGroupVO> findAndPageFileGroup(String groupName, PageParam pageParam) {
		Pagination<ResourceFileGroupDTO> groupDTOPage = resourceFileBiz.findAndPageGroup(groupName, pageParam);
		if (groupDTOPage.getTotal() == 0) {//无满足条件的数据
			return Pagination.build(pageParam);
		}
		Collection<ResourceFileGroupDTO> groupDTOList = groupDTOPage.getRows();
		//查询group内的资源文件
		List<ResourceFileGroupVO> groupVOList = groupDTOList.parallelStream().map(groupDTO -> {
			List<ResourceFileDTO> filesDTO = resourceFileBiz.findFilesByGroup(groupDTO.getId());
			List<ResourceFileVO> fileVOList = filesDTO.stream().map(ResourceVOBuilder::buildResourceFileVO)
					.sorted(Comparator.comparing(ResourceFileVO::getFileName)).collect(Collectors.toList());
			return ResourceVOBuilder.buildResourceFileGroupVO(groupDTO, fileVOList);
		}).sorted(Comparator.comparing(ResourceFileGroupVO::getGroupName)).collect(Collectors.toList());

		Pagination<ResourceFileGroupVO> groupVOPage = Pagination.build(pageParam);
		groupVOPage.setLastPage(groupDTOPage.getLastPage());
		groupVOPage.setTotal(groupDTOPage.getTotal());
		groupVOPage.setRows(groupVOList);
		return groupVOPage;
	}

	@Override
	@Transactional
	public BatchOperResultVO uploadResourceFiles(int groupId, String groupName, boolean exec, List<KeyValue> fileList) {
		if (!fileList.isEmpty()) {
			Optional<String> optional = fileList.stream().map(KeyValue::getKey).filter(fileName -> {
				fileName = fileName.toLowerCase();
				return !fileName.endsWith(".json") && !fileName.endsWith(".yaml") && !fileName.endsWith(".yml");
			}).findAny();
			if (optional.isPresent()) {
				DelayedLogger.error(logger, () -> "文件格式错误：" + optional.get());
				throw new HAERuntimeException(ResourceResultCode.RESOURCE_FILE_FORMAT_ILLEGAL);
			}
		}
		BatchOperResultVO batchResult = new BatchOperResultVO();
		List<ResourceFileDTO> createdFiles = new ArrayList<>(); //已保存的文件
		try {
			ResourceFileGroupDTO groupDTO;
			boolean isNewGroup = false;
			if (groupId > 0) {
				groupDTO = resourceFileBiz.loadGroup(groupId);
			} else {
				groupDTO = resourceFileBiz.createGroup(new ResourceFileGroupDTO(groupName));
				isNewGroup = true;
			}
			if (groupDTO == null) {
				throw new HAERuntimeException(ResourceResultCode.RESOURCE_FILE_UPLOAD_FAIL, "文件分组不存在或创建失败");
			}
			List<ResourceFileDTO> toCreateFiles = new ArrayList<>(); //待保存的文件
			if (!fileList.isEmpty()) {
				for (KeyValue oneFile : fileList) {
					toCreateFiles.add(new ResourceFileDTO(groupDTO.getId(), oneFile.getKey(), oneFile.getValue()));
				}
				List<ResourceFileDTO> tmpCreatedFiles = resourceFileBiz.createFiles(toCreateFiles);
				createdFiles.addAll(tmpCreatedFiles);
			}
			String message = "";
			if (isNewGroup) {
				publishEvent(ResourceFileActionType.CREATE_GROUP, groupDTO.getId(), groupName, "新建分组");
				message = "分组创建成功";
			}
			if (!createdFiles.isEmpty()) {
				String remark = "所在分组：" + groupDTO.getGroupName() + "（" + groupDTO.getId() + "）";
				createdFiles.forEach(resFile ->
						publishEvent(ResourceFileActionType.UPLOAD_FILE, resFile.getId(), resFile.getFileName(), remark));
				message = "资源文件上传成功";
			}
			batchResult.addSuccessResult(BatchOperResultVO.OperResult.build().message(message));
		} catch (Exception e) {
			DelayedLogger.error(logger, () -> "分组或文件上传保存失败", e);
			batchResult.addFailResult(BatchOperResultVO.OperResult.build().message("分组创建失败或文件上传失败"));
			return batchResult;
		}

		if (exec) {
			createdFiles.forEach(file -> {
				Map<ResourceDefineResolver.ResourceMetaInfo, String> resources = getResDefinitionFromFile(file);
				BatchOperResultVO tmp = deploy(resources);
				batchResult.getFailList().addAll(tmp.getFailList());
				batchResult.getSuccessList().addAll(tmp.getSuccessList());
			});
		}
		return batchResult;
	}

	@Override
	public void deleteFile(int fileId) {
		ResourceFileDTO dto = resourceFileBiz.loadFile(fileId);
		if (dto == null) {
			return;
		}
		resourceFileBiz.deleteFile(fileId);
		publishEvent(ResourceFileActionType.DELETE_FILE, fileId, dto.getFileName(), "删除资源文件");
	}

	@Override
	public void deleteGroup(int groupId) {
		ResourceFileGroupDTO groupDTO = resourceFileBiz.loadGroup(groupId);
		if (groupDTO == null) {
			return;
		}
		List<ResourceFileDTO> files = resourceFileBiz.findFilesByGroup(groupId);
		if (!CollectionUtils.isEmpty(files)) {
			files.forEach(file -> deleteFile(file.getId()));
		}
		resourceFileBiz.deleteGroup(groupId);
		publishEvent(ResourceFileActionType.DELETE_GROUP, groupId, groupDTO.getGroupName(), "删除分组");
	}

	@Override
	public void updateGroupName(int groupID, String groupName) {
		ResourceFileGroupDTO resourceFileGroupDTO = resourceFileBiz.findGroupByName(groupName);
		if (null != resourceFileGroupDTO && groupID != resourceFileGroupDTO.getId()) {
			throw new HAERuntimeException(ResourceResultCode.RESOURCE_FILE_GROUP_NAME_ALREADY_EXIST);
		}
		resourceFileBiz.updateGroup(groupID, groupName);
		publishEvent(ResourceFileActionType.UPDATE_GROUP, groupID, groupName, "修改分组名称");
	}

	@Override
	public ResourceFileGroupVO findGroup(String groupName) {
		ResourceFileGroupDTO resourceFileGroupDTO = resourceFileBiz.findGroupByName(groupName);
		ResourceFileGroupVO resourceFileGroupVO;
		if (null == resourceFileGroupDTO) {
			return null;
		}
		resourceFileGroupVO = new ResourceFileGroupVO();
		resourceFileGroupVO.setCreateTime(resourceFileGroupDTO.getCreateTime());
		resourceFileGroupVO.setGroupName(resourceFileGroupDTO.getGroupName());
		resourceFileGroupVO.setId(resourceFileGroupDTO.getId());
		return resourceFileGroupVO;
	}

	@Override
	public ResourceFileVO loadFile(int fileId) {
		ResourceFileDTO dto = resourceFileBiz.loadFile(fileId);
		return ResourceVOBuilder.buildResourceFileVO(dto);
	}

	private Map<ResourceDefineResolver.ResourceMetaInfo, String> getResDefinitionFromFile(int fileId) {
		ResourceFileDTO resourceFile = resourceFileBiz.loadFile(fileId);
		if (resourceFile == null) {
			throw new HAERuntimeException(ResourceResultCode.RESOURCE_FILE_NOT_EXIST);
		}
		return getResDefinitionFromFile(resourceFile);
	}

	private Map<ResourceDefineResolver.ResourceMetaInfo, String> getResDefinitionFromFile(ResourceFileDTO resourceFile) {
		return ResourceDefineResolver.resolve(resourceFile);
	}

	private KubeOperation<? extends HasMetadata> getKubeOperation(ResourceKind kind) {
		KubeOperation<? extends HasMetadata> kubeOperation = KubeOperationFactory.getOperation(kind);
		Assert.notNull(kubeOperation, "未注册资源【" + kind + "】的操作对象");
		return kubeOperation;
	}

	private void publishEvent(ResourceFileActionType actionType, int id, String name, String remark) {
		UserOperationEvent event = UserOperationEvent.builder().source(ActionLogModules.RESOURCE_FILE_MGMT)
				.principalCategory(PrincipalCategory.RESOURCE_FILE).actionType(actionType)
				.principalName(name).principalIndexCode(String.valueOf(id))
				.actorIp(LoginUtils.getLoginUser().getClientIP())
				.actorId(LoginUtils.getLoginUser().getId()).remark(remark).build();
		eventPublisher.publish(event);
	}

	private String getResourceIdentity(String namespace, ResourceKind kind, String name) {
		StringBuilder resourceIdBuf = new StringBuilder(); //资源ID：namespace+kind+name
		if (namespace != null) {
			resourceIdBuf.append(namespace).append("@");
		}
		resourceIdBuf.append(kind).append("@").append(name);
		return resourceIdBuf.toString();
	}

	/**
	 * 编辑文件
	 */
	@Override
	public void editFile(int fileId, String fileContent) {
		ResourceFileDTO fileDto = resourceFileBiz.loadFile(fileId);
		if (fileDto == null) {
			throw new HAERuntimeException(ResourceResultCode.RESOURCE_FILE_NOT_EXIST);
		}
		fileDto.setContent(fileContent);
		// 校验文件内容
		ResourceDefineResolver.resolve(fileDto);
		fileDto.setCreateTime(new Date());
		resourceFileBiz.editFile(fileDto);
		publishEvent(ResourceFileActionType.EDIT_FILE, fileDto.getId(), fileDto.getFileName(), "编辑资源文件");
	}

}
