package com.hikvision.hae.resource.vo;

import io.fabric8.kubernetes.api.model.LimitRangeSpec;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * @author by zhouzhigang6 on 2018/1/22.
 */
public class LimitRangeDetailVO implements Serializable {

    private static final long serialVersionUID = -8789577654899769248L;

    private String name;

    private String namespace;

    private Date createTime;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private LimitRangeSpec limitRangeSpec;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public LimitRangeSpec getLimitRangeSpec() {
        return limitRangeSpec;
    }

    public void setLimitRangeSpec(LimitRangeSpec limitRangeSpec) {
        this.limitRangeSpec = limitRangeSpec;
    }
}
