package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public class PodDetailVO implements Serializable {
    private static final long serialVersionUID = 1786401264313385838L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private Map<String, String> annotations;

    private Date createTime;

    private String podPhase;

    private String nodeName;

    private String podIP;

    private List<ContainerVO> containers;

    private List<ContainerVO> initContainers;
    //创建者只有一条记录，但页面显示成表格，所以要以分页的数据结构返回
    private List<PodControllerItemVO> controller;

    private List<ConditionVO> conditions;

    public static class ContainerVO implements Serializable {
        private static final long serialVersionUID = -5910668597567946394L;
        // Name of the container.
        private String name;

        // Image URI of the container.
        private String image;

        // List of environment variables.
        private List<EnvVarVO> env;

        // Commands of the container
        private List<String> commands;

        // Command arguments
        private List<String> args;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public List<EnvVarVO> getEnv() {
            return env;
        }

        public void setEnv(List<EnvVarVO> env) {
            this.env = env;
        }

        public List<String> getCommands() {
            return commands;
        }

        public void setCommands(List<String> commands) {
            this.commands = commands;
        }

        public List<String> getArgs() {
            return args;
        }

        public void setArgs(List<String> args) {
            this.args = args;
        }
    }

    public static class EnvVarVO implements Serializable {
        private static final long serialVersionUID = 2183167229943813829L;
        private String name;

        private String value;

        public EnvVarVO() {
        }

        public EnvVarVO(String name, String value) {
            this.name = name;
            this.value = value;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public static class ConditionVO implements Serializable {
        private static final long serialVersionUID = -159265763569034989L;

        private Date lastProbeTime;
        private Date lastTransitionTime;
        private String message;
        private String reason;
        private String status;
        private String type;

        public Date getLastProbeTime() {
            return lastProbeTime;
        }

        public void setLastProbeTime(Date lastProbeTime) {
            this.lastProbeTime = lastProbeTime;
        }

        public Date getLastTransitionTime() {
            return lastTransitionTime;
        }

        public void setLastTransitionTime(Date lastTransitionTime) {
            this.lastTransitionTime = lastTransitionTime;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public Map<String, String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(Map<String, String> annotations) {
        this.annotations = annotations;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getPodPhase() {
        return podPhase;
    }

    public void setPodPhase(String podPhase) {
        this.podPhase = podPhase;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getPodIP() {
        return podIP;
    }

    public void setPodIP(String podIP) {
        this.podIP = podIP;
    }

    public List<ContainerVO> getContainers() {
        return containers;
    }

    public void setContainers(List<ContainerVO> containers) {
        this.containers = containers;
    }

    public List<ContainerVO> getInitContainers() {
        return initContainers;
    }

    public void setInitContainers(List<ContainerVO> initContainers) {
        this.initContainers = initContainers;
    }

    public List<ConditionVO> getConditions() {
        return conditions;
    }

    public void setConditions(List<ConditionVO> conditions) {
        this.conditions = conditions;
    }

    public List<PodControllerItemVO> getController() {
        return controller;
    }

    public void setController(List<PodControllerItemVO> controller) {
        this.controller = controller;
    }
}