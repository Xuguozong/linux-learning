package com.hikvision.hae.image.service;

import java.util.List;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.image.vo.RepositoryConfigVO;
import com.hikvision.hae.image.vo.RepositoryQueryVO;
import com.hikvision.hae.img.entity.ImageProjectEntity;
import com.hikvision.hae.img.entity.ImageRepositoryEntity;
import com.hikvision.hae.img.entity.ImageRepositoryTagEntity;

/**
 * 镜像列表相关服务
 * 
 * @author qiuzhihao
 *
 */
public interface ImageRepositoryService {
	

	boolean isProjectExist(String projectName);
	
	/**
	 * 创建仓库
	 * @param projectName
	 */
	void createProject(String projectName);
	
	/**
	 * 删除仓库
	 * @param projectId
	 */
	void deleteProject(long projectId);
	/**
	 * 镜像仓库项目列表
	 * @param pageInfo
	 * @return
	 */
	Pagination<ImageProjectEntity> project(PageParam pageInfo);
	/**
	 * 镜像仓库列表
	 * @param query
	 * @return
	 */
	Pagination<ImageRepositoryEntity> repository(RepositoryQueryVO query);
	/**
	 * 镜像仓库下各个Tag详细
	 * @param repoName
	 * @return
	 */
	List<ImageRepositoryTagEntity> repositoryTagList(String repoName);
	
	/**
	 * 删除仓库
	 * @param repoName
	 */
	void deleteRepository(String repoName);
	
	/**
	 * 删除仓库下某个tag
	 * @param repoName
	 * @param tag
	 */
	void deleteRepositoryTag(String repoName, String tag);
	
	/**
	 * 镜像仓库配置信息
	 * @return
	 */
	RepositoryConfigVO getImageRepositoryConfigData();
}
