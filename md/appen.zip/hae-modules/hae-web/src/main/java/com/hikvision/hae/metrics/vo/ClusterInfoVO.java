package com.hikvision.hae.metrics.vo;

/**
 * 集群信息VO
 * Created by zhanjiejun on 2017/11/21.
 */
public class ClusterInfoVO {

	private int totalNode;

	private int normalNode;

	private int abnormalNode;

	private int totalNamespace;

	private int normalNamespace;

	private int abnormalNamespace;

	private int totalGpu;

	private int requestGpu;

	private int limitGpu;

	private int totalPod;

	private int runningPod;

	private double totalCpu;

	private double totalMemory;

	public int getTotalNode() {
		return totalNode;
	}

	public void setTotalNode(int totalNode) {
		this.totalNode = totalNode;
	}

	public int getNormalNode() {
		return normalNode;
	}

	public void setNormalNode(int normalNode) {
		this.normalNode = normalNode;
	}

	public int getAbnormalNode() {
		return abnormalNode;
	}

	public void setAbnormalNode(int abnormalNode) {
		this.abnormalNode = abnormalNode;
	}

	public int getTotalNamespace() {
		return totalNamespace;
	}

	public void setTotalNamespace(int totalNamespace) {
		this.totalNamespace = totalNamespace;
	}

	public int getNormalNamespace() {
		return normalNamespace;
	}

	public void setNormalNamespace(int normalNamespace) {
		this.normalNamespace = normalNamespace;
	}

	public int getAbnormalNamespace() {
		return abnormalNamespace;
	}

	public void setAbnormalNamespace(int abnormalNamespace) {
		this.abnormalNamespace = abnormalNamespace;
	}

	public int getTotalGpu() {
		return totalGpu;
	}

	public void setTotalGpu(int totalGpu) {
		this.totalGpu = totalGpu;
	}

	public int getRequestGpu() {
		return requestGpu;
	}

	public void setRequestGpu(int requestGpu) {
		this.requestGpu = requestGpu;
	}

	public int getLimitGpu() {
		return limitGpu;
	}

	public void setLimitGpu(int limitGpu) {
		this.limitGpu = limitGpu;
	}

	public int getTotalPod() {
		return totalPod;
	}

	public void setTotalPod(int totalPod) {
		this.totalPod = totalPod;
	}

	public int getRunningPod() {
		return runningPod;
	}

	public void setRunningPod(int runningPod) {
		this.runningPod = runningPod;
	}

	public double getTotalCpu() {
		return totalCpu;
	}

	public void setTotalCpu(double totalCpu) {
		this.totalCpu = totalCpu;
	}

	public double getTotalMemory() {
		return totalMemory;
	}

	public void setTotalMemory(double totalMemory) {
		this.totalMemory = totalMemory;
	}
}
