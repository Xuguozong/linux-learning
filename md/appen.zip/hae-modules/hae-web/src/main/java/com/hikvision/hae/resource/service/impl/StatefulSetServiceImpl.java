package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.service.StatefulSetService;
import com.hikvision.hae.resource.statefulset.biz.StatefulSetBiz;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.StatefulSetDetailVO;
import io.fabric8.kubernetes.api.model.extensions.StatefulSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/21.
 */
@Service
public class StatefulSetServiceImpl implements StatefulSetService {
    private static final Logger logger = LoggerFactory.getLogger(StatefulSetServiceImpl.class);

    @Resource
    private StatefulSetBiz statefulSetBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<StatefulSet> statefulSetPage = statefulSetBiz.findAndPage(filterQuery, pageParam);
        if (statefulSetPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<StatefulSet, PodInfo> podInfoFunc = (StatefulSet statefulSet) ->
                podBiz.getPodInfo(statefulSet.getSpec().getSelector(), namespace,
                        statefulSet.getStatus().getReplicas(), statefulSet.getSpec().getReplicas(), statefulSet.getMetadata().getUid());
        Function<Collection<StatefulSet>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<StatefulSet> dtoList) -> dtoList.stream()
                        .map(statefulSet -> ResourceVOBuilder.buildPodControllerItemVO(statefulSet, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(statefulSetPage, rowsConverter);
    }

    @Override
    public StatefulSetDetailVO getDetail(String namespace, String name) {
        StatefulSet statefulSet = statefulSetBiz.getByName(namespace, name);
        if (statefulSet == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在StatefulSet[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.STATEFULSET_NOT_EXIST);
        }
        StatefulSetDetailVO detailVO = new StatefulSetDetailVO();
        //StatefulSet基础属性
        detailVO.setNamespace(namespace);
        detailVO.setName(name);
        detailVO.setLabels(statefulSet.getMetadata().getLabels());
        detailVO.setAnnotations(statefulSet.getMetadata().getAnnotations());
        detailVO.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(statefulSet.getMetadata().getCreationTimestamp().getTime()));
        detailVO.setImages(ResourceVOBuilder.getContainerImages(statefulSet.getSpec().getTemplate()));
        PodInfo podInfo = podBiz.getPodInfo(statefulSet.getSpec().getSelector(), namespace,
                statefulSet.getStatus().getReplicas(), statefulSet.getSpec().getReplicas(), statefulSet.getMetadata().getUid());
        detailVO.setPodInfo(ResourceVOBuilder.buildPodInfoVO(podInfo));
        return detailVO;
    }

    @Override
    public void scale(String namespace, String name, int newReplicas) {
        statefulSetBiz.scale(namespace, name, newReplicas);
        kubeEventHelper.publishScaleEvent(ActionLogModules.STATEFUL_SET, PrincipalCategory.STATEFUL_SET, namespace, name, "伸缩有状态副本集（StatefulSet）");
    }

    @Override
    public void delete(String namespace, String name) {
        statefulSetBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.STATEFUL_SET, PrincipalCategory.STATEFUL_SET, namespace, name, "删除有状态副本集（StatefulSet）");
    }
}
