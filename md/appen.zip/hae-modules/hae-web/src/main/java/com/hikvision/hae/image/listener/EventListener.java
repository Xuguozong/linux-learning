package com.hikvision.hae.image.listener;

public interface EventListener<E> {

	void process(E event);
}
