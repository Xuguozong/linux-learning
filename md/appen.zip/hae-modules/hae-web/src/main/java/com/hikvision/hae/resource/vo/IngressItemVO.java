package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
public class IngressItemVO implements Serializable {
    private static final long serialVersionUID = -6877441781872448248L;

    private String namespace;

    private String name;

    private List<String> endpoints;

    private Date createTime;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getEndpoints() {
        return endpoints;
    }

    public void setEndpoints(List<String> endpoints) {
        this.endpoints = endpoints;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
