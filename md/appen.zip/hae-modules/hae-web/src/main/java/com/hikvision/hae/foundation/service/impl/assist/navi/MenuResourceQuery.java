package com.hikvision.hae.foundation.service.impl.assist.navi;

/**
 * 查询菜单l类别的系统资源的参数条件
 *
 * Created by zhouziwei on 2017/11/3.
 */
public class MenuResourceQuery {
    /**
     * 用户ID
     */
    private String userId;
   /**
    * 命名空间
    */
    private String namespace;

    public MenuResourceQuery(String userId, String namespace) {
        this.userId = userId;
        this.namespace = namespace;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

}
