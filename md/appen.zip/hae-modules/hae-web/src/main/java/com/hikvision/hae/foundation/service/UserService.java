package com.hikvision.hae.foundation.service;


import com.hikvision.hae.foundation.user.dto.UserDTO;
import com.hikvision.hae.foundation.web.assist.LoginUser;

import javax.security.auth.login.LoginException;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public interface UserService {

	/**
	 * 判断用户密码是否正确
	 *
	 * @param username
	 * @param orginPwd
	 * @return
	 * @throws LoginException
	 */
	LoginUser login(String username, String orginPwd) throws LoginException;

	/**
	 * 强制修改密码
	 *
	 * @param username
	 * @param newPassword
	 */
	void forceModifyPassword(String username, String newPassword);

	/**
	 * 修改密码
	 *
	 * @param username
	 * @param oldPwd
	 * @param newPwd
	 */
	void modifyPassword(String username, String oldPwd, String newPwd);

	/**
	 * 根据用户名获取用户信息
	 *
	 * @param username
	 * @return
	 */
	UserDTO getUserByName(String username);

}
