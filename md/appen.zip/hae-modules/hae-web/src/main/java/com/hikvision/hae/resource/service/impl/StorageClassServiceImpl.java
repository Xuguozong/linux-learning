package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.service.StorageClassService;
import com.hikvision.hae.resource.storageclass.StorageClassBiz;
import com.hikvision.hae.resource.vo.StorageClassVO;
import io.fabric8.kubernetes.api.model.StorageClass;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/24.
 */
@Service
public class StorageClassServiceImpl implements StorageClassService {

    @Resource
    private StorageClassBiz storageClassBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<StorageClassVO> findAndPage(String name, PageParam pageParam) {
        FilterQuery filterQuery = FilterQuery.build().name(name);
        Pagination<StorageClass> storageClassPage = storageClassBiz.findAndPage(filterQuery, pageParam);
        if (storageClassPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<Collection<StorageClass>, Collection<StorageClassVO>> rowsConverter =
                (Collection<StorageClass> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildStorageClassVO).collect(Collectors.toList());
        return new Pagination<>(storageClassPage, rowsConverter);
    }

    @Override
    public void delete(String name) {
        storageClassBiz.delete(name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.STORAGE_CLASS, PrincipalCategory.STORAGE_CLASS, null, name, "删除存储类（StorageClass）");
    }
}
