package com.hikvision.hae.foundation.web.assist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Set;

@Configuration
@Profile(value = {"prod", "test", "dev"})
public class UserFrozenCleanTask {

	private final static Logger logger = LoggerFactory.getLogger(UserFrozenCleanTask.class);

	@Value("${user.frozen.interval:3600000}")
	private int frozenInterval;

	@Autowired
	private InvalidLoginTimesRegistry invalidLoginTimesRegistry;

	// 30s执行一次清除操作
	@Scheduled(fixedRate = 30000)
	public void cleanTask() {
		final long cleanTime = System.currentTimeMillis() - frozenInterval;
		final Set<String> frozenCache = invalidLoginTimesRegistry.getFrozenReadyToClean(cleanTime);
		frozenCache.forEach(key -> {
			invalidLoginTimesRegistry.delFailedTimes(key);
			invalidLoginTimesRegistry.delFrozen(key);
		});
	}

}