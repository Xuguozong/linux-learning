package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public class ResourceFileVO implements Serializable {

    private static final long serialVersionUID = -2257986991162235670L;

    private int id;

    private int groupId;

    private String fileName;

    private String content;

    private Date createTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
