package com.hikvision.hae.resource.service.impl;

import com.google.common.collect.Lists;
import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.deployment.biz.DeploymentBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.replicaset.biz.ReplicaSetBiz;
import com.hikvision.hae.resource.service.ReplicaSetService;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.ReplicaSetDetailVO;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
@org.springframework.stereotype.Service
public class ReplicaSetServiceImpl implements ReplicaSetService {
    private static final Logger logger = LoggerFactory.getLogger(ReplicaSetServiceImpl.class);

    @Resource
    private DeploymentBiz deploymentBiz;

    @Resource
    private ReplicaSetBiz replicaSetBiz;

    @Resource
    private PodBiz podBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PodControllerItemVO> findAndPage(String namespace, String name, String labels, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, labels);
        Pagination<ReplicaSet> replicaSetPage = replicaSetBiz.findAndPage(filterQuery, pageParam);
        return convertReplicaSetPageAsVO(replicaSetPage, pageParam);
    }

    @Override
    public List<PodControllerItemVO> findNewReplicaSet(String namespace, String deploymentName) {
        Deployment deployment = deploymentBiz.getByName(namespace, deploymentName);
        if (deployment == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Deployment[" + deploymentName + "]");
            throw new HAERuntimeException(ResourceResultCode.DEPLOYMENT_NOT_EXIST);
        }
        ReplicaSet rs = replicaSetBiz.getNewReplicaSet(deployment);
        if (rs == null) {
            return null;
        }
        Function<ReplicaSet, PodInfo> podInfoFunc = (ReplicaSet replicaSet) ->
                podBiz.getPodInfo(replicaSet.getSpec().getSelector(), namespace,
                        replicaSet.getStatus().getReplicas(), replicaSet.getSpec().getReplicas(), replicaSet.getMetadata().getUid());
        return Lists.newArrayList(ResourceVOBuilder.buildPodControllerItemVO(rs, podInfoFunc));
    }

    @Override
    public Pagination<PodControllerItemVO> findAndPageOldReplciaSet(String namespace, String deploymentName, PageParam pageParam) {
        Deployment deployment = deploymentBiz.getByName(namespace, deploymentName);
        if (deployment == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Deployment[" + deploymentName + "]");
            throw new HAERuntimeException(ResourceResultCode.DEPLOYMENT_NOT_EXIST);
        }
        Pagination<ReplicaSet> replicaSetPage = replicaSetBiz.findAndPageOldReplicaSet(deployment, pageParam);
        return convertReplicaSetPageAsVO(replicaSetPage, pageParam);
    }

    private Pagination<PodControllerItemVO> convertReplicaSetPageAsVO(Pagination<ReplicaSet> replicaSetPage, PageParam pageParam) {
        if (replicaSetPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<ReplicaSet, PodInfo> podInfoFunc = (ReplicaSet replicaSet) ->
                podBiz.getPodInfo(replicaSet.getSpec().getSelector(), replicaSet.getMetadata().getNamespace(),
                        replicaSet.getStatus().getReplicas(), replicaSet.getSpec().getReplicas(), replicaSet.getMetadata().getUid());
        Function<Collection<ReplicaSet>, Collection<PodControllerItemVO>> rowsConverter =
                (Collection<ReplicaSet> dtoList) -> dtoList.stream()
                        .map(rs -> ResourceVOBuilder.buildPodControllerItemVO(rs, podInfoFunc)).collect(Collectors.toList());
        return new Pagination<>(replicaSetPage, rowsConverter);
    }

    @Override
    public ReplicaSetDetailVO getDetail(String namespace, String name) {
        //ReplicaSet基础属性
        ReplicaSet replicaSet = replicaSetBiz.getByName(namespace, name);
        if (replicaSet == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在ReplicaSet[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.REPLICASET_NOT_EXIST);
        }
        ReplicaSetDetailVO vo = new ReplicaSetDetailVO();
        vo.setNamespace(replicaSet.getMetadata().getNamespace());
        vo.setName(replicaSet.getMetadata().getName());
        vo.setLabels(replicaSet.getMetadata().getLabels());
        vo.setAnnotations(replicaSet.getMetadata().getAnnotations());
        vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(replicaSet.getMetadata().getCreationTimestamp().getTime()));
        vo.setSelectors(replicaSet.getSpec().getSelector().getMatchLabels());
        vo.setImages(ResourceVOBuilder.getContainerImages(replicaSet.getSpec().getTemplate()));
        PodInfo podInfo = podBiz.getPodInfo(replicaSet.getSpec().getSelector(), namespace,
                replicaSet.getStatus().getReplicas(), replicaSet.getSpec().getReplicas(), replicaSet.getMetadata().getUid());
        vo.setPodInfo(ResourceVOBuilder.buildPodInfoVO(podInfo));
        return vo;
    }

    @Override
    public void delete(String namespace, String name) {
        replicaSetBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.REPLICA_SET, PrincipalCategory.REPLICA_SET, namespace, name, "删除副本集（ReplicaSet）");
    }
}
