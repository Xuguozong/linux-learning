package com.hikvision.hae.resource.vo;

import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/17.
 */
public class NodeResourceVO {

	private Map<String, String> requests;

	private Map<String, String> limits;

	private int podUsed;

	public Map<String, String> getRequests() {
		return requests;
	}

	public void setRequests(Map<String, String> requests) {
		this.requests = requests;
	}

	public Map<String, String> getLimits() {
		return limits;
	}

	public void setLimits(Map<String, String> limits) {
		this.limits = limits;
	}

	public int getPodUsed() {
		return podUsed;
	}

	public void setPodUsed(int podUsed) {
		this.podUsed = podUsed;
	}
}
