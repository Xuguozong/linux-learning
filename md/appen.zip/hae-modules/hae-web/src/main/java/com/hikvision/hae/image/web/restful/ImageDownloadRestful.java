package com.hikvision.hae.image.web.restful;

import com.hikvision.hae.image.service.ImageService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Created by zhanjiejun on 2017/12/26.
 */
@Controller
@RequestMapping("/image")
public class ImageDownloadRestful {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ImageService imgService;

	@GetMapping("/download")
	public void downloadImage(String imageFullName, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		response.setContentType("multipart/form-data");
		response.setHeader("Content-Disposition", "attachment;fileName=" + imageFullName + ".tar.gz");
		try(InputStream inputStream = imgService.downloadImage(imageFullName); GZIPOutputStream os = new GZIPOutputStream(response.getOutputStream())){
			byte[] b = new byte[2048];
			int length;
			while ((length = inputStream.read(b)) > 0) {
				os.write(b, 0, length);
			}
			logger.info("镜像{}下载完毕", imageFullName);
		} catch (Exception e){
			logger.error("镜像{}下载出错", imageFullName, e);
		}
	}

}
