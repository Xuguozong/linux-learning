package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.PersistentVolumeDetailVO;
import com.hikvision.hae.resource.vo.PersistentVolumeItemVO;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
public interface PersistentVolumeService {

    /**
     * 分页查询PersistentVolume
     *
     * @param name      PersistentVolume名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PersistentVolumeItemVO> findAndPage(String name, PageParam pageParam);

    /**
     * 查看PersistentVolume详情
     *
     * @param name PersistentVolume名称
     * @return PersistentVolume详情
     */
    PersistentVolumeDetailVO getDetail(String name);

    /**
     * 删除PersistentVolume
     *
     * @param name      PersistentVolume名称
     */
    void delete(String name);

}
