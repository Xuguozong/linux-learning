package com.hikvision.hae.resource.service.impl;

import com.google.common.collect.Maps;
import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.util.CollectionUtils;
import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.util.encrypt.RSAUtils;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.NodeActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.util.eventcenter.event.UserOperationEvent;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.vo.TableParam;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import com.hikvision.hae.resource.assist.NodeLabelChecker;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.EventType;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.event.biz.EventBiz;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.node.dto.NodeDTO;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.service.NodeService;
import com.hikvision.hae.resource.vo.*;
import io.fabric8.kubernetes.api.model.Event;
import io.fabric8.kubernetes.api.model.Pod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by zhanjiejun on 2017/11/15.
 */
@Service
@Transactional
public class NodeServiceImpl implements NodeService {

	@Autowired
	private NodeBiz nodeBiz;

	@Autowired
	private PodBiz podBiz;

	@Autowired
	private EventBiz eventBiz;

	@Autowired
	private EventPublisher eventPublisher;

	@Autowired
	private NodeLabelChecker nodeLabelChecker;

	@Override
	public void addNode(NodeWriteVO nodeWriteVO) {
		NodeBaseDTO nodeBaseDTO = new NodeBaseDTO();
		nodeBaseDTO.setName(nodeWriteVO.getName());
		nodeBaseDTO.setSshPwd(RSAUtils.decode(nodeWriteVO.getSshPwd()));
		nodeBaseDTO.setIp(nodeWriteVO.getIp());
		nodeBiz.addNode(nodeBaseDTO);
		// 记录操作日志
		publishEvent(NodeActionType.ADD, nodeBaseDTO, "添加节点");
	}

	@Override
	public void hardDeleteNode(int id) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.hardDeleteNode(id);
		// 记录操作日志
		publishEvent(NodeActionType.DELETE, nodeBaseDTO, "删除节点（清理配置）");
	}

	@Override
	public void softDeleteNode(int id) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.softDeleteNode(id);
		// 记录操作日志
		publishEvent(NodeActionType.DELETE, nodeBaseDTO, "删除节点");
	}

	@Override
	public Pagination<NodeBaseVO> findAndPageNodes(TableParam tableParam) {
		Page<NodeBaseDTO> page = nodeBiz.findAndPageNodes(tableParam.getPageNo(), tableParam.getPageSize(), tableParam.getFuzzyQuery());
		Pagination<NodeBaseVO> resultPage = new Pagination<>(tableParam);
		if (!CollectionUtils.isEmpty(page.getContent())) {
			resultPage.setRows(page.getContent().stream().map(ResourceVOBuilder::buildNodeBaseVO).collect(Collectors.toList()));
		}
		resultPage.setTotal(page.getTotalElements());
		resultPage.setLastPage(page.getTotalPages());
		return resultPage;
	}

	@Override
	public boolean isNameExist(String name, int id) {
		return nodeBiz.isNameExist(name, id);
	}

	@Override
	public boolean isIpExist(String ip) {
		return nodeBiz.isIpExist(ip);
	}

	@Override
	public void mergeNodeLabel(int id, LabelVO label) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.mergeNodeLabel(id, new KeyValue(label.getKey(), label.getValue()));
		// 记录操作日志
		publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "添加/修改节点标签[" + label.getKey() + ":" + label.getValue() + "]");
	}

	@Override
	public void deleteNodeLabel(int id, String key) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.deleteNodeLabel(id, key);
		// 记录操作日志
		publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "删除节点标签[" + key + "]");
	}

	@Override
	public boolean isLabelKeyExist(int id, String key) {
		return nodeBiz.isLabelKeyExist(key, id);
	}

	@Override
	public NodeBaseVO getNodeBaseDetail(int id) {
		return ResourceVOBuilder.buildNodeBaseVO(nodeBiz.getNodeBaseDetail(id));
	}

	@Override
	public void maintainNode(int id) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.maintainNode(id);
		// 记录操作日志
		publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "维护节点");
	}

	@Override
	public void exitMaintainNode(int id) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.exitMaintainNode(id);
		// 记录操作日志
		publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "启用节点（退出维护模式）");
	}

	@Override
	public void updateNode(int id, NodeWriteVO nodeWriteVO) {
		NodeBaseDTO nodeBaseDTO = new NodeBaseDTO();
		nodeBaseDTO.setId(id);
		nodeBaseDTO.setName(nodeWriteVO.getName());
		boolean modifySSH = !StringUtils.isEmpty(nodeWriteVO.getSshPwd());
		if (modifySSH) {
			nodeBaseDTO.setSshPwd(RSAUtils.decode(nodeWriteVO.getSshPwd()));
		}
		NodeBaseDTO oldNodeBaseDTO = nodeBiz.updateNode(nodeBaseDTO);
		if (modifySSH) {
			publishEvent(NodeActionType.UPDATE, oldNodeBaseDTO, "录入/修改节点SSH信息");
		} else {
			publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "修改节点名称[" + oldNodeBaseDTO.getName() + " -> " + nodeBaseDTO.getName() + "]");
		}
	}

	@Override
	public NodeReadVO getNodeDetail(int id) {
		NodeDTO nodeDTO = nodeBiz.getNodeDetail(id);
		NodeReadVO nodeReadVO = new NodeReadVO();
		nodeReadVO.setBaseInfo(ResourceVOBuilder.buildNodeBaseVO(nodeDTO.getNodeBaseDTO()));
		nodeReadVO.setResourceInfo(ResourceVOBuilder.buildNodeResourceVO(nodeDTO.getNodeResourceDTO()));
		return nodeReadVO;
	}

	@Override
	public boolean isNodeLabelKeyAvailable(int id, String key) {
		return !nodeLabelChecker.isSystemDefault(key) && !isLabelKeyExist(id, key);
	}

	@Override
	public void syncNodeList() {
		nodeBiz.syncNodeList();
		NodeBaseDTO nodeBaseDTO = new NodeBaseDTO();
		nodeBaseDTO.setName("节点");
		publishEvent(NodeActionType.UPDATE, nodeBaseDTO, "同步节点列表数据");
	}

	@Override
	public Pagination<PodItemVO> getPodsInNode(int id, PageParam pageParam) {
		String k8sName = nodeBiz.getK8SNameById(id);
		FilterQuery filterQuery = new FilterQuery();
		Map mapFields = Maps.newHashMap();
		mapFields.put("spec.nodeName", k8sName);
		filterQuery.setFields(mapFields);
		Pagination<Pod> podPagination = podBiz.findAndPage(filterQuery, pageParam);
		if (podPagination.getTotal() == 0) {//无满足条件的数据
			return Pagination.build(pageParam);
		}
		Map<String, String> nodeNames = nodeBiz.getK8SNameNodeNameMap();
		List<Event> eventList = eventBiz.find(null, ResourceKind.Pod, null, null, EventType.WARNING.getCode()); // 取得所有Pod事件
		Function<Collection<Pod>, Collection<PodItemVO>> rowsConverter =
				(Collection<Pod> dtoList) -> dtoList.stream()
						.map(pod -> ResourceVOBuilder.buildPodItemVO(pod, nodeNames, eventList)).collect(Collectors.toList());
		return new Pagination<>(podPagination, rowsConverter);
	}

	public void publishEvent(NodeActionType actionType, NodeBaseDTO nodeBaseDTO, String remark) {
		if (nodeBaseDTO != null) {
			LoginUser loginUser = LoginUtils.getLoginUser();
			UserOperationEvent operEvent = UserOperationEvent.builder().source(ActionLogModules.NODE_MANAGE)
					.principalCategory(PrincipalCategory.NODE).actionType(actionType).actorIp(loginUser.getClientIP())
					.actorId(loginUser.getId()).principalName(nodeBaseDTO.getName()).principalIndexCode("").remark(remark)
					.build();
			eventPublisher.publish(operEvent);
		}
	}

}
