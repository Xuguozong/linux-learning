package com.hikvision.hae.foundation.web.restful;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.util.encrypt.RSAUtils;
import com.hikvision.hae.common.util.eventcenter.EventPublisher;
import com.hikvision.hae.common.util.eventcenter.enums.UserActionType;
import com.hikvision.hae.common.util.eventcenter.event.UserLoginEvent;
import com.hikvision.hae.common.vo.AjaxResult;
import com.hikvision.hae.foundation.common.constant.FoundationResultCode;
import com.hikvision.hae.foundation.common.exception.ForceModifyPwdException;
import com.hikvision.hae.foundation.common.exception.UserFrozenException;
import com.hikvision.hae.foundation.common.exception.WrongCaptchaException;
import com.hikvision.hae.foundation.service.UserService;
import com.hikvision.hae.foundation.vo.LoginResultVO;
import com.hikvision.hae.foundation.vo.LoginVO;
import com.hikvision.hae.foundation.vo.ModifyPwdVO;
import com.hikvision.hae.foundation.web.assist.CaptchaUtils;
import com.hikvision.hae.foundation.web.assist.InvalidLoginTimesRegistry;
import com.hikvision.hae.foundation.web.assist.LoginUser;
import com.hikvision.hae.foundation.web.assist.LoginUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 登录Rest层
 *
 * @author zhanjiejun
 */
@RestController
@RequestMapping("/api")
public class LoginRestful {

	private final static Logger logger = LoggerFactory.getLogger(LoginRestful.class);

	@Autowired
	private UserService userService;

	@Autowired
	private InvalidLoginTimesRegistry invalidLoginTimesRegistry;

	@Autowired
	private EventPublisher eventPublisher;

	/**
	 * 登录
	 *
	 * @param user
	 * @param request
	 * @return
	 */
	@PostMapping("/login")
	public AjaxResult<LoginResultVO> login(@RequestBody LoginVO user, HttpServletRequest request) {
		HttpSession session = request.getSession();
		// 获取当前用户
		LoginUser loginUser = (LoginUser) session.getAttribute(CommonConstants.LOGIN_USER);
		if (loginUser != null) {
			return AjaxResult.build(FoundationResultCode.SOME_ACCOUNT_ALREADY_LOGIN);
		}

		// 用户名密码为空
		String userName = user.getUsername();
		if (userName == null || user.getPassword() == null) {
			return AjaxResult.build(FoundationResultCode.USERNAME_OR_PASSWORD_BLANK);
		}

		Integer tmpFailedTimes = 0;
		LoginResultVO loginResult = new LoginResultVO();
		try {
			tmpFailedTimes = preLogin(user, session);
			String orginPwd = RSAUtils.decode(user.getPassword());
			loginUser = userService.login(userName, orginPwd);
			loginUser.setClientIP(LoginUtils.getClientIP(request));
			// 记录操作日志
			UserLoginEvent userLoginEvent = new UserLoginEvent();
			userLoginEvent.setActionType(UserActionType.LOGIN);
			userLoginEvent.setSource(ActionLogModules.USER_MANAGE);
			userLoginEvent.setUserId(loginUser.getId());
			userLoginEvent.setUserName(userName);
			userLoginEvent.setUserIp(loginUser.getClientIP());
			userLoginEvent.setRemark("用户登录");
			eventPublisher.publish(userLoginEvent);
		} catch (ForceModifyPwdException e) {
			// 强制修改密码
			logger.debug("Need modify pwd for user [{}].", userName);
			loginResult.setForceModifyPwd(true);
			session.setAttribute(CommonConstants.PRE_LOGIN_USER_PREFIX + userName, e.getUserId());
		} catch (WrongCaptchaException e) {
			// 验证码错误
			logger.debug("Wrong captcha for user [{}].", userName);
			loginResult.setShowCaptcha(showCaptcha(e.getFailedTimes()));
			return new AjaxResult<>(FoundationResultCode.WRONG_CAPTCHA, loginResult);
		} catch (UserFrozenException e) {
			// 用户被冻结
			logger.debug("User [{}] has been frozen.", userName);
			return new AjaxResult<>(FoundationResultCode.USER_FROZEN, loginResult);
		} catch (LoginException e) {
			// 登录失败
			logger.debug("User [{}] login failed, current failed times: [{}]", userName, tmpFailedTimes + 1);
			loginResult.setShowCaptcha(showCaptcha(tmpFailedTimes + 1));
			invalidLoginTimesRegistry.plusFailedTimes(userName);
			return new AjaxResult<>(FoundationResultCode.USERNAME_OR_PASSWORD_ERROR, loginResult);
		}
		session.setAttribute(CommonConstants.LOGIN_USER, loginUser);
		invalidLoginTimesRegistry.delFailedTimes(userName);
		return new AjaxResult<>(CommonResultCode.SUCCESS, loginResult);
	}

	/**
	 * 登录强制修改密码
	 *
	 * @param modifyPwd 新密码、确认密码
	 * @return
	 */
	@PostMapping("/forceModifyPwd")
	public AjaxResult<Void> forceModifyPwd(HttpServletRequest request, @RequestBody ModifyPwdVO modifyPwd) {
		boolean isIlleaglArg = modifyPwd == null || StringUtils.isBlank(modifyPwd.getUserName()) || StringUtils.isBlank(modifyPwd.getNewPwd()) || StringUtils.isBlank(modifyPwd.getConfirmPwd());
		if (isIlleaglArg) {
			return new AjaxResult<>(CommonResultCode.ILLEGAL_ARGUMENT);
		}
		String ordinalNewPwd = RSAUtils.decode(modifyPwd.getNewPwd());
		String ordinalConfirmPwd = RSAUtils.decode(modifyPwd.getConfirmPwd());
		if (!ordinalNewPwd.equals(ordinalConfirmPwd)) {
			return new AjaxResult<>(CommonResultCode.ILLEGAL_ARGUMENT);
		}

		HttpSession session = request.getSession();
		String userName = modifyPwd.getUserName();
		String sessionKey = CommonConstants.PRE_LOGIN_USER_PREFIX + userName;
		Object sessionValue = session.getAttribute(sessionKey);
		if (sessionValue == null) {
			return new AjaxResult<>(CommonResultCode.USER_NOT_LOGIN);
		}
		userService.forceModifyPassword(userName, RSAUtils.decode(modifyPwd.getNewPwd()));
		// FIXME 避免Converity报错
//		session.removeAttribute(sessionKey);

		// 记录操作日志
		UserLoginEvent userActiveEvent = new UserLoginEvent();
		userActiveEvent.setActionType(UserActionType.ACTIVE);
		userActiveEvent.setSource(ActionLogModules.USER_MANAGE);
		userActiveEvent.setUserId((String) sessionValue);
		userActiveEvent.setUserName(userName);
		userActiveEvent.setUserIp(LoginUtils.getClientIP(request));
		userActiveEvent.setRemark("用户激活");
		eventPublisher.publish(userActiveEvent);
		return AjaxResult.buildSuccess();
	}

	/**
	 * 登录是否展示验证码
	 * @param username
	 * @return
	 */
	@GetMapping("/showCaptcha")
	public AjaxResult<Boolean> showCaptcha(@RequestParam String username) {
		Integer failedTimes = invalidLoginTimesRegistry.getFailedTimes(username);
		return new AjaxResult<>(CommonResultCode.SUCCESS, showCaptcha(failedTimes));
	}

	private boolean showCaptcha(Integer failedTimes) {
		return failedTimes >= 3 && failedTimes < 5;
	}

	private Integer preLogin(LoginVO user, HttpSession session) throws LoginException {
		Integer failedTimes = invalidLoginTimesRegistry.getFailedTimes(user.getUsername());
		if (failedTimes >= 3 && failedTimes < 5) { // 校验验证码
			String captcha = user.getCaptcha();
			if (!CaptchaUtils.checkCaptcha(captcha, session)) {
				throw new WrongCaptchaException(failedTimes);
			}
		} else if (failedTimes >= 5) { // 校验是否冻结
			throw new UserFrozenException();
		}
		return failedTimes;
	}

}
