package com.hikvision.hae.resource.vo;

import java.util.Date;

/**
 * Created by zhanjiejun on 2017/11/10.
 */
public class NamespaceReadVO {

	private String name;

	private Date createTime;

	private String status;

	private String statusName;

	/**
	 * CPU单位：cores
	 */
	private double cpuTotal;

	private double cpuUsed;

	/**
	 * 内存单位：Gi bytes
	 */
	private double memoryTotal;

	private double memoryUsed;

	/**
	 * GPU单位：张
	 */
	private int gpuTotal;

	private int gpuUsed;

	private boolean isK8SDefault;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public double getCpuTotal() {
		return cpuTotal;
	}

	public void setCpuTotal(double cpuTotal) {
		this.cpuTotal = cpuTotal;
	}

	public double getCpuUsed() {
		return cpuUsed;
	}

	public void setCpuUsed(double cpuUsed) {
		this.cpuUsed = cpuUsed;
	}

	public double getMemoryTotal() {
		return memoryTotal;
	}

	public void setMemoryTotal(double memoryTotal) {
		this.memoryTotal = memoryTotal;
	}

	public double getMemoryUsed() {
		return memoryUsed;
	}

	public void setMemoryUsed(double memoryUsed) {
		this.memoryUsed = memoryUsed;
	}

	public int getGpuTotal() {
		return gpuTotal;
	}

	public void setGpuTotal(int gpuTotal) {
		this.gpuTotal = gpuTotal;
	}

	public int getGpuUsed() {
		return gpuUsed;
	}

	public void setGpuUsed(int gpuUsed) {
		this.gpuUsed = gpuUsed;
	}

	public boolean isK8SDefault() {
		return isK8SDefault;
	}

	public void setK8SDefault(boolean k8SDefault) {
		isK8SDefault = k8SDefault;
	}
}
