package com.hikvision.hae.foundation.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 菜单类别的系统资源
 *
 * Created by zhouziwei on 2017/11/3.
 */
public class MenuResourceVO implements Serializable, Cloneable{
    private static final long serialVersionUID = -3616042249700148345L;

    private static final Logger logger = LoggerFactory.getLogger(MenuResourceVO.class);
    /**
     * 菜单ID
     */
    private int id;

    /**
     * 菜单名称。菜单有分组时，菜单名称作为分组中子菜单的分组标题
     */
    private String name;

    /**
     * 菜单图标的URL
     */
    private String iconUrl;

    /**
     * 未指定iconurl时默认的icon位置的样式。目前为硬编码值"fa-bullhorn"
     */
    private String icon = "fa-bullhorn";

    /**
     * 菜单的URL
     */
    private String url;

    /**
     * 分组标记：true时表示当前菜单是分组的标题
     */
    private boolean group;

    /**
     * 是否隐藏分组名称（即name属性值），隐藏后分组还存在，但是页面中不会显示name值
     */
    private boolean hideGroupTitle;

    /**
     * 子菜单。仅当查询请求要求返回子菜单时才有效
     */
    private List<MenuResourceVO> clist;

    /**
     * 当前菜单是true，其它菜单是false
     */
    private boolean active;

    /**
     * menu编码，不返回给客户端。active当前菜单时用于确定哪个是当前菜单
     */
    @JSONField(serialize = false)
    private SysResourceCode code;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isGroup() {
        return group;
    }

    public void setGroup(boolean group) {
        this.group = group;
    }

    public boolean isHideGroupTitle() {
        return hideGroupTitle;
    }

    public void setHideGroupTitle(boolean hideGroupTitle) {
        this.hideGroupTitle = hideGroupTitle;
    }

    public List<MenuResourceVO> getClist() {
        return clist;
    }

    public void setClist(List<MenuResourceVO> clist) {
        this.clist = clist;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public SysResourceCode getCode() {
        return code;
    }

    public void setCode(SysResourceCode code) {
        this.code = code;
    }

    public static MenuResourceVO readFromDTO(SysResourceDTO dto) {
        MenuResourceVO vo = new MenuResourceVO();
        vo.setId(dto.getId());
        vo.setName(dto.getName());
        vo.setIconUrl(dto.getIconUrl());
        vo.setUrl(dto.getUrl());
        vo.setGroup(dto.isGroup());
        vo.setHideGroupTitle(dto.isHideGroupTitle());
        vo.setCode(dto.getCode());
        if (dto.getChildren() != null && !dto.getChildren().isEmpty()) {
            List<MenuResourceVO> children = dto.getChildren().stream().map(MenuResourceVO::readFromDTO).collect(Collectors.toList());
            vo.setClist(children);
        }
        return vo;
    }

    /**
     * 深度复制对象。
     * 由于完全采用的是内存操作，基本上不可能出现IOException,故而没处理异常
     *
     * @return 复制后的对象
     */
    @Override
    public MenuResourceVO clone() {
        ByteArrayOutputStream bos = null;
        ObjectOutputStream oos = null;
        ObjectInputStream ois = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(this);
            ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
            return (MenuResourceVO) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            logger.error("failed to clone object deeply", e);
            DelayedLogger.error(logger, () -> "failed to clone object deeply", e);
        } finally {
            try {
                if (bos != null) {
                    bos.close();
                }
                if (oos != null) {
                    oos.close();
                }
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException e) {
                logger.error("failed to clone object deeply",e);
                DelayedLogger.error(logger, () -> "failed to clone object deeply", e);
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.getName() + "[" + this.url + "]";
    }
}
