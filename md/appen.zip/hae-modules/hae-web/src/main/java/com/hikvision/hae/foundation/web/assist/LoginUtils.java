package com.hikvision.hae.foundation.web.assist;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by zhanjiejun on 2017/11/1.
 */
public class  LoginUtils {

    public static LoginUser getLoginUser() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        return getLoginUser(request, true);
    }

    public static LoginUser getLoginUser(HttpServletRequest request) {
        return getLoginUser(request, false);
    }

    public static LoginUser getLoginUser(HttpServletRequest request, boolean throwEx) {
        LoginUser loginUser = null;
        HttpSession session = request.getSession();
        if (session != null) {
            loginUser = (LoginUser) session.getAttribute(CommonConstants.LOGIN_USER);
        }
        if (throwEx && loginUser == null) {
            throw new HAERuntimeException(CommonResultCode.USER_NOT_LOGIN);
        }
        if (loginUser != null) {
            loginUser.setClientIP(getClientIP(request));
        }
        return loginUser;
    }

    public static String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        return StringUtils.isBlank(xForwardedFor) ? request.getRemoteAddr() : xForwardedFor;
    }

}
