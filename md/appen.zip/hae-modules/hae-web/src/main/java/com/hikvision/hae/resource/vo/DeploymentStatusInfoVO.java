package com.hikvision.hae.resource.vo;

import java.io.Serializable;

/**
 * @author jianghaiyang5 on 2017/11/13.
 */
public class DeploymentStatusInfoVO implements Serializable {
    private static final long serialVersionUID = -476263872274958785L;

    private Integer available;
    private Integer replicas;
    private Integer unavailable;
    private Integer updated;

    public DeploymentStatusInfoVO() {
    }

    public DeploymentStatusInfoVO(Integer available, Integer replicas, Integer unavailable, Integer updated) {
        this.available = available;
        this.replicas = replicas;
        this.unavailable = unavailable;
        this.updated = updated;
    }

    public Integer getAvailable() {
        return available;
    }

    public void setAvailable(Integer available) {
        this.available = available;
    }

    public Integer getReplicas() {
        return replicas;
    }

    public void setReplicas(Integer replicas) {
        this.replicas = replicas;
    }

    public Integer getUnavailable() {
        return unavailable;
    }

    public void setUnavailable(Integer unavailable) {
        this.unavailable = unavailable;
    }

    public Integer getUpdated() {
        return updated;
    }

    public void setUpdated(Integer updated) {
        this.updated = updated;
    }
}
