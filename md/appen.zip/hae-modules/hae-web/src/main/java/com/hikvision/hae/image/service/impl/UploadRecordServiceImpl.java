package com.hikvision.hae.image.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hikvision.hae.file.biz.UploadFileBiz;
import com.hikvision.hae.file.model.UploadFile;
import com.hikvision.hae.file.model.UploadStatus;
import com.hikvision.hae.image.service.UploadRecordService;
import com.hikvision.hae.image.vo.UploadFileItemVO;
import org.springframework.util.CollectionUtils;

@Service
public class UploadRecordServiceImpl implements UploadRecordService {

	@Resource
	private UploadFileBiz fileRecordBiz;

	private List<UploadStatus> fileUploadingStatus;

	private List<UploadStatus> imagePushingStatus;

	@PostConstruct
	public void init() {
		fileUploadingStatus = Collections.singletonList(UploadStatus.UPLOADING);
		imagePushingStatus = Arrays.asList(UploadStatus.UPLOADED, UploadStatus.PUSHING);
	}

	@Override
	public List<UploadFileItemVO> getUploadRecordList() {
		List<UploadFile> recordList = fileRecordBiz.getAll();
		sortUploadFile(recordList);
		return recordList.stream().map(origin -> new UploadFileItemVO(origin)).collect(Collectors.toList());
	}

	@Override
	public void deleteUploadRecord(String fileId) {
		fileRecordBiz.clean(fileId);
		fileRecordBiz.delete(fileId);
	}

	@Override
	public List<UploadFile> uploadFileMiddleStatusList() {
		return fileRecordBiz.getByStatus(fileUploadingStatus);
	}

	@Override
	public List<UploadFile> pushImageMiddleStatusList() {
		return fileRecordBiz.getByStatus(imagePushingStatus);
	}

	/**
	 * 优先按照上传镜像状态排序，排序方式参见UploadStatus
	 * 再按照创建时间倒序
	 *
	 * @param uploadFiles 待排序集合
	 */
	private void sortUploadFile(List<UploadFile> uploadFiles) {
		if (CollectionUtils.isEmpty(uploadFiles)) {
			return;
		}
		Collections.sort(uploadFiles, new Comparator<UploadFile>() {
			@Override
			public int compare(UploadFile o1, UploadFile o2) {
				int result = o2.getStatus().getOrder() - o1.getStatus().getOrder();
				if (result != 0) {
					return result;
				}
				return o1.getCreated().before(o2.getCreated()) ? 1 : -1;
			}
		});
	}

}
