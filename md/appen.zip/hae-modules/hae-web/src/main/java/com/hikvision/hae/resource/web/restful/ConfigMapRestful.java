package com.hikvision.hae.resource.web.restful;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.vo.*;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.service.ConfigMapService;
import com.hikvision.hae.resource.vo.ConfigMapDetailVO;
import com.hikvision.hae.resource.vo.ConfigMapItemVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @author by zhanjiejun on 2017/11/23.
 */
@RestController
@RequestMapping("/api/configMaps/v1")
@Api(description = "配置与存储/配置集")
public class ConfigMapRestful {

	@Autowired
	private ConfigMapService configMapService;

	/**
	 * 分页查询ConfigMap
	 *
	 * @param namespace 命名空间
	 * @param pageSize  每页记录数
	 * @param pageNo    页码，从1开始
	 * @param name      ConfigMap名称，模糊匹配
	 * @return ConfigMap分页数据
	 */
	@ApiOperation(value = "分页查询配置集", produces = "application/json")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
			@ApiImplicitParam(paramType = "path", name = "pageSize", dataType = "int", required = true, value = "页大小"),
			@ApiImplicitParam(paramType = "path", name = "pageNo", dataType = "int", required = true, value = "页码"),
			@ApiImplicitParam(paramType = "query", name = "name", dataType = "String", value = "名称")
	})
	@GetMapping("/namespace/{namespace}/pagination/{pageSize}/{pageNo}")
	public AjaxResult<Pagination<ConfigMapItemVO>> findAndPage(@PathVariable String namespace,
															   @PathVariable int pageSize,
															   @PathVariable int pageNo,
															   @RequestParam(required = false) String name) {
		PageParam pageParam = new PageParam(pageNo, pageSize);
		AjaxResult<Pagination<ConfigMapItemVO>> result = AjaxResult.buildSuccess();
		result.setData(configMapService.findAndPage(namespace, name, pageParam));
		return result;
	}

	/**
	 * 查看ConfigMap详情
	 *
	 * @param namespace 命名空间
	 * @param name      ConfigMap名称
	 * @return ConfigMap详情
	 */
	@ApiOperation(value = "查询配置集详情", produces = "application/json")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
			@ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
	})
	@GetMapping("/namespace/{namespace}/{name}")
	public AjaxResult<ConfigMapDetailVO> getDetail(@PathVariable String namespace,
												   @PathVariable String name) {
		AjaxResult<ConfigMapDetailVO> result = AjaxResult.buildSuccess();
		result.setData(configMapService.getDetail(namespace, name));
		return result;
	}

	/**
	 * 删除ConfigMap
	 *
	 * @param namespace 命名空间
	 * @param name      ConfigMap名称
	 */
	@ApiOperation(value = "删除配置集", produces = "application/json")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "path", name = "namespace", dataType = "String", required = true, value = "命名空间"),
			@ApiImplicitParam(paramType = "path", name = "name", dataType = "String", required = true, value = "名称")
	})
	@DeleteMapping("/namespace/{namespace}/{name}")
	public AjaxResult<Void> delete(@PathVariable String namespace,
								   @PathVariable String name) {
		configMapService.delete(namespace, name);
		return AjaxResult.buildSuccess();
	}

	@ApiOperation(value = "创建配置集", produces = "application/json")
	@PostMapping("/namespace/{namespace}/{name}")
	public AjaxResult<Void> create(@PathVariable String namespace,
								   @PathVariable String name,
								   @RequestParam MultipartFile[] files) {
		List<KeyValue> fileList = new ArrayList<>();
		if (files == null || files.length <= 0) {
			return new AjaxResult<>(ResourceResultCode.AT_LEAST_ONE_FILE_FOR_CONFIGMAP_NEED);
		}
		try {
			for (MultipartFile f : files) {
				String originFilename = f.getOriginalFilename(); //上传的文件有可能同名，为
				if (originFilename.contains("\\")) {
					//低版本的IE会上传文件的完整路径
					originFilename = originFilename.substring(originFilename.lastIndexOf('\\') + 1);
				}
				fileList.add(new KeyValue(originFilename, new String(f.getBytes(), StandardCharsets.UTF_8)));
			}
		} catch (IOException e) {
			throw new HAERuntimeException(CommonResultCode.FILE_UPSTREAM_RESOLVE_FAIL);
		}
		configMapService.create(namespace, name, fileList);
		return AjaxResult.buildSuccess();
	}

	@GetMapping("/namespace/{namespace}/{name}/nameExist")
	public AjaxResult<ExistCheckVO> isNameExist(@PathVariable String namespace,
												@PathVariable String name) {
		AjaxResult<ExistCheckVO> result = AjaxResult.buildSuccess();
		result.setData(new ExistCheckVO(configMapService.isNameExist(namespace, name)));
		return result;
	}

}