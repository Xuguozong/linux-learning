package com.hikvision.hae.foundation.service.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.vo.Select2VO;
import com.hikvision.hae.foundation.service.LogService;
import com.hikvision.hae.foundation.vo.LogTableVO;
import com.hikvision.hae.foundation.vo.LogVO;
import com.hikvision.hae.log.biz.LogBiz;
import com.hikvision.hae.log.dto.LogQuery;
import com.hikvision.hae.log.model.Log;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.namespace.biz.NamespaceBiz;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import io.fabric8.kubernetes.api.model.Pod;
import jef.common.wrapper.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Created by zhouziwei on 2017/11/10.
 */
@Service
public class LogServiceImpl implements LogService {

    private static final Logger logger = LoggerFactory.getLogger(LogServiceImpl.class);

    @Resource
    private LogBiz logBiz;

    @Resource
    private NamespaceBiz namespaceBiz;

    @Resource
    private PodBiz podBiz;

    @Override
    public void batchAdd(List<LogVO> logs) {
        List<Log> logList = new ArrayList<>();
        for (LogVO logVO : logs) {
            logList.add(LogVO.readToModel(logVO));
        }
        logBiz.batchAdd(logList);
    }

    @Override
    public Pagination<LogTableVO> findAndPage(LogQuery logQuery, PageParam pageParam) {
        Page<Log> modelPage = logBiz.findAndPage(logQuery, pageParam);
        Page<LogTableVO> voPage = new Page<>(modelPage.getTotalCount(), modelPage.getPageSize());
        List<LogTableVO> voList = Optional.ofNullable(modelPage.getList())
                .map(rows -> rows.stream() //构建流
                        .map(LogTableVO::readFromModel) //model -> dto
                        .collect(Collectors.toList())) // 归集到集合
                .orElse(Collections.emptyList()); //原集合为null返回空list
        voPage.setList(voList);
        return new Pagination<>(pageParam.getPageNo(), voPage);
    }

    @Override
    public List<LogTableVO> download(LogQuery logQuery) {
        List<Log> logList = logBiz.listLogs(logQuery);
        List<LogTableVO> voList = Optional.ofNullable(logList)
                .map(rows -> rows.stream() //构建流
                        .map(LogTableVO::readFromModel) //model -> vo
                        .collect(Collectors.toList())) // 归集到集合
                .orElse(Collections.emptyList()); //原集合为null返回空list
        return voList;
    }

    @Override
    public List<Select2VO> getPodsByNamespace(String namespace) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, null, null);
        List<Pod> podList = podBiz.find(filterQuery);
        List<Select2VO> selects = Optional.of(podList).map(pods -> {
            return pods.stream() // 构建流
                    .map(pod -> {
                        return new Select2VO(pod.getMetadata().getName(), ""); //id->pod名，text->""
                    }).collect(Collectors.toList()); // 归集到List
        }).orElse(new ArrayList<>());
        return selects;
    }

    @Override
    public List<Select2VO> getContainersByNamespaceAndPod(String namespace, String podName) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, podName, null);
        List<Pod> podList = podBiz.find(filterQuery);
        List<Select2VO> selects = new ArrayList<>();
        podList.forEach(pod -> {
            pod.getSpec().getContainers().forEach(container -> {
                selects.add(new Select2VO(container.getName(), "")); //id->container名，text->null
            });
        });
        return selects;
    }

}
