package com.hikvision.hae.foundation.service.impl.assist.navi;

import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import com.hikvision.hae.foundation.resource.model.SysResourceLayout;
import com.hikvision.hae.foundation.vo.MenuResourceVO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhouziwei on 2017/11/8.
 */
@Component
public class LeftSecondLayerMenuBuilder extends AbstractMenuBuilder {

    @Resource
    private SysResourceBiz sysResourceBiz;

    private static final String NAMESPACE_PLACEHOLDER = "{namespace}";

    /**
     * 构建第二层左侧菜单
     *
     * @param userId  用户ID
     * @param namespace 命名空间
     * @return
     */
    public MenuResourceVO build(String userId, String namespace) {
        SysResourceDTO sysResourceDTO = sysResourceBiz.getResourceTree(SysResourceLayout.LEFT_LV2);
        MenuResourceVO menuResourceVO = MenuResourceVO.readFromDTO(sysResourceDTO);
        replacePathVariable(menuResourceVO, namespace);
        return menuResourceVO;
    }

}
