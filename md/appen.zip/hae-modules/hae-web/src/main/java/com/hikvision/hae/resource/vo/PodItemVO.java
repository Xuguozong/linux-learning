package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
public class PodItemVO implements Serializable {
    private static final long serialVersionUID = 7924137487090527382L;

    private String namespace;

    private String name;

    private String nodeName;

    private String phase;

    private Integer restartCount;

    private Date createTime;
    
    /** 容器状态 */
    private String containerStatus;
    
    /** 原因 */
    private String reason;
    
    /** 警告消息 */
    private List<String> warningMessages;

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public Integer getRestartCount() {
        return restartCount;
    }

    public void setRestartCount(Integer restartCount) {
        this.restartCount = restartCount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

	public String getContainerStatus() {
		return containerStatus;
	}

	public void setContainerStatus(String containerStatus) {
		this.containerStatus = containerStatus;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
    
	public List<String> getWarningMessages() {
		return warningMessages;
	}

	public void setWarningMessages(List<String> warningMessages) {
		this.warningMessages = warningMessages;
	}
}
