/**
 * 
 */
package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * @author qihongfei
 *
 */
public class ServiceAccountListVO implements Serializable {

	private static final long serialVersionUID = 4217836465176428401L;

	private String name;

	private String namespace;

	private Date createTime;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
}
