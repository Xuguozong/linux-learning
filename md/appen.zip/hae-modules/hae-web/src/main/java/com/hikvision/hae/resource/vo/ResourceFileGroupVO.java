package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public class ResourceFileGroupVO implements Serializable {
    private static final long serialVersionUID = 2371927347372137157L;
    private int id;

    private String groupName;

    private Date createTime;

    private List<ResourceFileVO> files;

    public ResourceFileGroupVO() {
    }

    public ResourceFileGroupVO(String groupName, List<ResourceFileVO> files) {
        this.groupName = groupName;
        this.files = files;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public List<ResourceFileVO> getFiles() {
        return files;
    }

    public void setFiles(List<ResourceFileVO> files) {
        this.files = files;
    }
}
