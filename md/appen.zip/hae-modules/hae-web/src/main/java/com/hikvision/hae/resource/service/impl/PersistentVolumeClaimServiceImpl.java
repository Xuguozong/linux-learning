package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.persistentvolumeclaim.PersistentVolumeClaimBiz;
import com.hikvision.hae.resource.service.PersistentVolumeClaimService;
import com.hikvision.hae.resource.vo.PersistentVolumeClaimVO;
import io.fabric8.kubernetes.api.model.PersistentVolumeClaim;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/23.
 */
@Service
public class PersistentVolumeClaimServiceImpl implements PersistentVolumeClaimService {
    private static final Logger logger = LoggerFactory.getLogger(PersistentVolumeClaimServiceImpl.class);

    @Resource
    private PersistentVolumeClaimBiz persistentVolumeClaimBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<PersistentVolumeClaimVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<PersistentVolumeClaim> pvcPage = persistentVolumeClaimBiz.findAndPage(filterQuery, pageParam);
        if (pvcPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }
        Function<Collection<PersistentVolumeClaim>, Collection<PersistentVolumeClaimVO>> rowsConverter =
                (Collection<PersistentVolumeClaim> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildPersistentVolumeClaimVO).collect(Collectors.toList());
        return new Pagination<>(pvcPage, rowsConverter);
    }

    @Override
    public PersistentVolumeClaimVO getDetail(String namespace, String name) {
        PersistentVolumeClaim pvc = persistentVolumeClaimBiz.getByName(namespace, name);
        if (pvc == null) {
            DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在PersistentVolumeClaim[" + name + "]");
            throw new HAERuntimeException(ResourceResultCode.PERSISTENTVOLUMECLAIM_NOT_EXIST);
        }
        return ResourceVOBuilder.buildPersistentVolumeClaimVO(pvc);
    }

    @Override
    public void delete(String namespace, String name) {
        persistentVolumeClaimBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.PERSISTENT_VOLUME_CLAIM, PrincipalCategory.PERSISTENT_VOLUME_CLAIM,
                namespace, name, "删除持久化存储卷索取（PersistentVolumeClaim）");
    }
}
