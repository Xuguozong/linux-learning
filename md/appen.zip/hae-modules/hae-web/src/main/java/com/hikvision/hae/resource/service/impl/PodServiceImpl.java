package com.hikvision.hae.resource.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.util.encrypt.JWTUtil;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.PodHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.EventType;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.configmap.biz.ConfigMapBiz;
import com.hikvision.hae.resource.daemonset.DaemonSetBiz;
import com.hikvision.hae.resource.event.biz.EventBiz;
import com.hikvision.hae.resource.job.JobBiz;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.replicaset.biz.ReplicaSetBiz;
import com.hikvision.hae.resource.replicationcontroller.biz.ReplicationControllerBiz;
import com.hikvision.hae.resource.secret.biz.SecretBiz;
import com.hikvision.hae.resource.service.PodService;
import com.hikvision.hae.resource.service.biz.ServiceBiz;
import com.hikvision.hae.resource.statefulset.biz.StatefulSetBiz;
import com.hikvision.hae.resource.vo.ContainerWebconsoleVO;
import com.hikvision.hae.resource.vo.PodControllerItemVO;
import com.hikvision.hae.resource.vo.PodDetailVO;
import com.hikvision.hae.resource.vo.PodItemVO;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.api.model.extensions.DaemonSet;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import io.fabric8.kubernetes.api.model.extensions.StatefulSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
@Service
public class PodServiceImpl implements PodService {

	private static final Logger logger = LoggerFactory.getLogger(PodServiceImpl.class);

	private static final String sec = "HAE_jwt_HAE";

	@Resource
	private DaemonSetBiz daemonSetBiz;

	@Resource
	private JobBiz jobBiz;

	@Resource
	private ReplicaSetBiz replicaSetBiz;

	@Resource
	private ReplicationControllerBiz replicationControllerBiz;

	@Resource
	private ServiceBiz serviceBiz;

	@Resource
	private StatefulSetBiz statefulSetBiz;

	@Resource
	private PodBiz podBiz;

	@Resource
	private ConfigMapBiz configMapBiz;

	@Resource
	private SecretBiz secretBiz;

	@Resource
	private EventBiz eventBiz;

	@Resource
	private NodeBiz nodeBiz;

	@Resource
	private KubeEventHelper kubeEventHelper;

	@Value("${container.webconsole.port:32339}")
	private int containerWebconsolePort;

	@Override
	public Pagination<PodItemVO> findAndPage(String namespace, String name, String ownerKind, String ownerName, PageParam pageParam) {
		FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
		addOwnerAsQueryParam(filterQuery, ownerKind, ownerName);
		Pagination<Pod> podPage = podBiz.findAndPage(filterQuery, pageParam);
		if (podPage.getTotal() == 0) {//无满足条件的数据
			return Pagination.build(pageParam);
		}
		Map<String, String> nodeNames = nodeBiz.getK8SNameNodeNameMap();
		List<Event> eventList = eventBiz.find(namespace, ResourceKind.Pod, null, null, EventType.WARNING.getCode()); // 取得所有Pod事件
		Function<Collection<Pod>, Collection<PodItemVO>> rowsConverter =
				(Collection<Pod> dtoList) -> dtoList.stream()
						.map(pod -> ResourceVOBuilder.buildPodItemVO(pod, nodeNames, eventList)).collect(Collectors.toList());
		return new Pagination<>(podPage, rowsConverter);
	}

	@Override
	public PodDetailVO getDetail(String namespace, String name) {
		//Pod属性信息
		Pod pod = podBiz.getByName(namespace, name);
		if (pod == null) {
			DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Pod[" + name + "]");
			throw new HAERuntimeException(ResourceResultCode.POD_NOT_EXIST);
		}

		PodDetailVO vo = new PodDetailVO();
		vo.setNamespace(pod.getMetadata().getNamespace());
		vo.setName(pod.getMetadata().getName());
		vo.setLabels(pod.getMetadata().getLabels());

		vo.setCreateTime(UTCDateUtil.parseUTCTimeToStandardDate(pod.getMetadata().getCreationTimestamp().getTime()));
		vo.setPodPhase(pod.getStatus().getPhase());
		if (pod.getSpec().getNodeName() != null) {
			vo.setNodeName(nodeBiz.getNodeNameByK8SName(pod.getSpec().getNodeName()));
		}
		vo.setPodIP(pod.getStatus().getPodIP());
		//容器信息
		FilterQuery filterQuery = FilterQuery.build().namespace(pod.getMetadata().getNamespace());
		List<ConfigMap> configMaps = configMapBiz.find(filterQuery);
		List<Secret> secrets = secretBiz.find(filterQuery);
		vo.setContainers(PodHelper.extractContainerInfo(pod.getSpec().getContainers(), pod, configMaps, secrets));
		vo.setInitContainers(PodHelper.extractContainerInfo(pod.getSpec().getInitContainers(), pod, configMaps, secrets));
		//现状
		vo.setConditions(PodHelper.buildConditionvO(pod));
		//创建者
		PodControllerItemVO podControllerItemVO = PodHelper.getPodController(pod, podBiz);
		if (podControllerItemVO != null) {
			vo.setController(Lists.newArrayList(podControllerItemVO));
		}
		//详情页有单独的创建者列表，注释中不再返回创建者。注意：必须放在创建者代码之后，因为获取创建者要用到此annotation
		Map<String, String> annos = pod.getMetadata().getAnnotations();
		if (annos != null) {
			if (annos.containsKey(ResourceConstants.CREATED_BY_ANNOTATION)) {
				annos.remove(ResourceConstants.CREATED_BY_ANNOTATION);
			}
			vo.setAnnotations(annos.isEmpty() ? null : annos);
		}
		return vo;
	}

	@Override
	public void delete(String namespace, String name) {
		podBiz.delete(namespace, name);
		kubeEventHelper.publishDeleteEvent(ActionLogModules.POD, PrincipalCategory.POD, namespace, name, "删除容器组（Pod）");
	}

	@Override
	public ContainerWebconsoleVO getContainerWebconsoleInfo(String namespace, String name, String containerName) {
		Pod pod = podBiz.getByName(namespace, name);
		if (pod == null) {
			DelayedLogger.error(logger, () -> "在Namespace[" + namespace + "]中不存在Pod[" + name + "]");
			throw new HAERuntimeException(ResourceResultCode.POD_NOT_EXIST);
		}
		List<ContainerStatus> containerStatuses = pod.getStatus().getContainerStatuses();
		List<ContainerStatus> initContainerStatuses = pod.getStatus().getInitContainerStatuses();
		if (!CollectionUtils.isEmpty(initContainerStatuses)) {
			containerStatuses.addAll(initContainerStatuses);
		}
		ContainerStatus containerStatus = containerStatuses.stream().filter(c -> containerName.equals(c.getName())).findAny().get();
		if (containerStatus == null) {
			throw new HAERuntimeException(ResourceResultCode.CONTAINER_NOT_EXIST);
		}

		String nodeName = pod.getSpec().getNodeName();
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoByK8SName(nodeName);

		JSONObject extJson = new JSONObject();
		extJson.put("containerId", interceptContainerId(containerStatus));

		ContainerWebconsoleVO containerWebconsoleVO = new ContainerWebconsoleVO();
		containerWebconsoleVO.setIp(nodeBaseDTO.getIp());
		containerWebconsoleVO.setPort(containerWebconsolePort);
		containerWebconsoleVO.setToken(JWTUtil.signJWT(sec, "container_webconsole", extJson.toJSONString()));
		return containerWebconsoleVO;
	}

	private String interceptContainerId(ContainerStatus containerStatus) {
		String id = containerStatus.getContainerID();
		// id -> docker://7d2214c543f74f648bb6ec3afb0fbd0c86f28571c82e7938aa9a8cf55c86352c
		// containerId -> 7d2214c543f7
		return id.substring(9, 21);
	}

	private void addOwnerAsQueryParam(FilterQuery filterQuery, String ownerKindStr, String ownerName) {
		if (StringUtils.isEmpty(ownerKindStr)) {
			return;
		}
		String namespace = filterQuery.getNamespace();
		ResourceKind ownerKind = ResourceKind.parse(ownerKindStr);
		LabelSelector labelSelector;
		String ownerUid = null;
		switch (ownerKind) {
			case DaemonSet:
				DaemonSet daemonSet = daemonSetBiz.getByName(namespace, ownerName);
				labelSelector = daemonSet == null ? null : daemonSet.getSpec().getSelector();
				ownerUid = daemonSet.getMetadata().getUid();
				break;
			case Job:
				Job job = jobBiz.getByName(namespace, ownerName);
				labelSelector = job == null ? null : job.getSpec().getSelector();
				break;
			case ReplicaSet:
				ReplicaSet replicaSet = replicaSetBiz.getByName(namespace, ownerName);
				labelSelector = replicaSet == null ? null : replicaSet.getSpec().getSelector();
				ownerUid = replicaSet.getMetadata().getUid();
				break;
			case ReplicationController:
				ReplicationController rc = replicationControllerBiz.getByName(namespace, ownerName);
				labelSelector = rc == null ? null : new LabelSelectorBuilder().addToMatchLabels(rc.getSpec().getSelector()).build();
				ownerUid = rc.getMetadata().getUid();
				break;
			case Service:
				io.fabric8.kubernetes.api.model.Service svc = serviceBiz.getByName(namespace, ownerName);
				labelSelector = svc == null ? null : new LabelSelectorBuilder().addToMatchLabels(svc.getSpec().getSelector()).build();
				break;
			case StatefulSet:
				StatefulSet statefulSet = statefulSetBiz.getByName(namespace, ownerName);
				labelSelector = statefulSet == null ? null : statefulSet.getSpec().getSelector();
				ownerUid = statefulSet.getMetadata().getUid();
				break;
			default:
				labelSelector = null;
		}
		filterQuery.setOwnerUid(ownerUid);
		if (labelSelector != null) {
			filterQuery.setLabelSelector(labelSelector);
		} else {
			DelayedLogger.error(logger, () -> "无效的Pod关联方. Kind: " + ownerKindStr + ", Name: " + ownerName);
			throw new HAERuntimeException(ResourceResultCode.INVALID_POD_OWNER);
		}
	}

}
