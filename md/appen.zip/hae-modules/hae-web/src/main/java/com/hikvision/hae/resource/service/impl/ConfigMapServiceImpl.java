package com.hikvision.hae.resource.service.impl;

import com.hikvision.hae.common.constant.ActionLogModules;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import com.hikvision.hae.common.vo.KeyValue;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.assist.KubeEventHelper;
import com.hikvision.hae.resource.assist.ResourceRequestResolver;
import com.hikvision.hae.resource.assist.ResourceVOBuilder;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.configmap.biz.ConfigMapBiz;
import com.hikvision.hae.resource.service.ConfigMapService;
import com.hikvision.hae.resource.vo.ConfigMapDetailVO;
import com.hikvision.hae.resource.vo.ConfigMapItemVO;
import io.fabric8.kubernetes.api.model.ConfigMap;
import io.fabric8.kubernetes.api.model.ObjectMeta;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author zhanjiejun on 2017/11/23.
 */
@Service
public class ConfigMapServiceImpl implements ConfigMapService {

    @Resource
    private ConfigMapBiz configMapBiz;

    @Resource
    private KubeEventHelper kubeEventHelper;

    @Override
    public Pagination<ConfigMapItemVO> findAndPage(String namespace, String name, PageParam pageParam) {
        FilterQuery filterQuery = ResourceRequestResolver.parseTableRequestParam(namespace, name, null);
        Pagination<ConfigMap> configMapPage = configMapBiz.findAndPage(filterQuery, pageParam);
        if (configMapPage.getTotal() == 0) {//无满足条件的数据
            return Pagination.build(pageParam);
        }

        Function<Collection<ConfigMap>, Collection<ConfigMapItemVO>> rowsConverter =
                (Collection<ConfigMap> dtoList) -> dtoList.stream().map(ResourceVOBuilder::buildConfigMapItemVO).collect(Collectors.toList());
        return new Pagination<>(configMapPage, rowsConverter);
    }

    @Override
    public ConfigMapDetailVO getDetail(String namespace, String name) {
        ConfigMap configMap = configMapBiz.getByName(namespace, name);
        if (configMap == null) {
            throw new HAERuntimeException(ResourceResultCode.CONFIGMAP_NOT_EXIST);
        }
        return ResourceVOBuilder.buildConfigMapDetailVO(configMap);
    }

    @Override
    public void delete(String namespace, String name) {
        configMapBiz.delete(namespace, name);
        kubeEventHelper.publishDeleteEvent(ActionLogModules.CONFIG_MAP, PrincipalCategory.CONFIG_MAP, namespace, name, "删除配置集（ConfigMap）");
    }

    @Override
    public void create(String namespace, String name, List<KeyValue> data) {
        ConfigMap configMap = new ConfigMap();
        configMap.setData(convert2Data(data));
        ObjectMeta objectMeta = new ObjectMeta();
        objectMeta.setName(name);
        objectMeta.setNamespace(namespace);
        configMap.setMetadata(objectMeta);
        configMapBiz.create(configMap);
        kubeEventHelper.publishAddEvent(ActionLogModules.CONFIG_MAP, PrincipalCategory.CONFIG_MAP, namespace, name, "添加配置集（ConfigMap）");
    }

    @Override
    public boolean isNameExist(String namespace, String name) {
        return configMapBiz.getByName(namespace, name) != null;
    }

    private Map<String, String> convert2Data(List<KeyValue> kvs) {
        Map<String, String> resultMap = new HashMap<>();
        kvs.forEach(kv -> {
            resultMap.put(kv.getKey(), kv.getValue());
        });
        return resultMap;
    }

}
