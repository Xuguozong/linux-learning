package com.hikvision.hae.resource.service;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.vo.ContainerWebconsoleVO;
import com.hikvision.hae.resource.vo.PodDetailVO;
import com.hikvision.hae.resource.vo.PodItemVO;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public interface PodService {

    /**
     * 分页查询Pod
     *
     * @param namespace 命名空间
     * @param name      Pod名称
     * @param ownerKind Pod关联方的类型
     * @param ownerName Pod关联方名称
     * @param pageParam 分页参数
     * @return 列表记录
     */
    Pagination<PodItemVO> findAndPage(String namespace, String name, String ownerKind, String ownerName, PageParam pageParam);

    /**
     * 查看Pod详情
     *
     * @param namespace 命名空间
     * @param name      Pod名称
     * @return Pod详情
     */
    PodDetailVO getDetail(String namespace, String name);

    /**
     * 删除Pod
     *
     * @param namespace 命名空间
     * @param name      Pod名称
     */
    void delete(String namespace, String name);

    /**
     * 获取容器控制台信息
     * @param namespace 命名空间
     * @param name POD名称
     * @param containerName 容器名称
     * @return
     */
    ContainerWebconsoleVO getContainerWebconsoleInfo(String namespace, String name, String containerName);
}
