package com.hikvision.hae.foundation.assit;

import com.hikvision.hae.foundation.common.enums.SysResourceCode;
import com.hikvision.hae.foundation.resource.biz.SysResourceBiz;
import com.hikvision.hae.foundation.resource.dto.SysResourceDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by zhanjiejun on 2017/12/14.
 */
@Component
public class SysResourceIniter {

	@Autowired
	private SysResourceBiz sysResourceBiz;

	@Value("${image.enabled:true}")
	private boolean imageEnabled;

	@PostConstruct
	public void init() {
		sysResourceBiz.updateResourceDeletedFlag(SysResourceCode.IMAGE_MANAGE, !imageEnabled);
	}

}
