package com.hikvision.hae.metrics.assist;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.util.DigitUtils;
import com.hikvision.hae.common.util.K8SResourceUnitConverter;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import jef.tools.DateFormats;
import jef.tools.DateUtils;

import java.util.*;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public class MetricsVOBuilder {

	/**
	 * @param id
	 * @param metricsDTO
	 * @param metricsType
	 * @return
	 */
	public static MetricsTrendVO buildMetricsTrendVO(String id, MetricsDTO metricsDTO, MetricsType metricsType) {
		MetricsTrendVO metricsVO = new MetricsTrendVO();
		metricsVO.setUnit(metricsType.getUnit());
		List<MetricsTrendVO.Trend> trends = new ArrayList<>(1);
		if (metricsDTO != null) {
			MetricsTrendVO.Trend trend = new MetricsTrendVO.Trend();
			trend.setResourceId(id);
			Map<String, String> metrics = new TreeMap<>();
			metricsDTO.getMetrics().forEach(m -> {
				Date time = UTCDateUtil.parseUTCTimeToStandardDate(m.getTimestamp());
				metrics.put(DateUtils.format(time, DateFormats.DATE_TIME_CS), convertUnit(m.getValue(), metricsType));
			});
			trend.setMetrics(metrics);
			trends.add(trend);
		}
		metricsVO.setTrend(trends);
		return metricsVO;
	}

	public static MetricsTrendVO buildMetricsTrendVO(String id, Map<String, Long> metricsDataMap, MetricsType metricsType) {
		MetricsTrendVO metricsVO = new MetricsTrendVO();
		metricsVO.setUnit(metricsType.getUnit());
		List<MetricsTrendVO.Trend> trends = new ArrayList<>(1);
		if (metricsDataMap != null) {
			MetricsTrendVO.Trend trend = new MetricsTrendVO.Trend();
			trend.setResourceId(id);
			Map<String, String> metrics = new TreeMap<>();
			metricsDataMap.forEach((k, v) -> {
				Date time = UTCDateUtil.parseUTCTimeToStandardDate(k);
				metrics.put(DateUtils.format(time, DateFormats.DATE_TIME_CS), convertUnit(v, metricsType));
			});
			trend.setMetrics(metrics);
			trends.add(trend);
		}
		metricsVO.setTrend(trends);
		return metricsVO;
	}

	private static String convertUnit(long value, MetricsType metricsType) {
		switch (metricsType) {
			case CPU_USAGE_RATE:
				return String.valueOf(K8SResourceUnitConverter.convertCPU2Cores(String.valueOf(value / 1000f)));
			case MEMORY_USAGE:
				return String.valueOf(K8SResourceUnitConverter.convertMemory2Gi(String.valueOf(value)));
			case GPU_POWER_DRAW:
				return String.valueOf(DigitUtils.toTwoDigits(value / 1000d));
			default:
				return String.valueOf(value);
		}
	}

}
