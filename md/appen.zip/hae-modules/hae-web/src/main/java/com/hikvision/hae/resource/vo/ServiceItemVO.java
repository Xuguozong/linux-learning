package com.hikvision.hae.resource.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
public class ServiceItemVO implements Serializable {
    private static final long serialVersionUID = 3495517954276403671L;

    private String namespace;

    private String name;

    private Map<String, String> labels;

    private String clusterIP;

    private EndpointVO internalEndpoint;

    private List<EndpointVO> externalEndpoints;

    private String type;

    private Date createTime;

    public static class EndpointVO implements Serializable {
        private static final long serialVersionUID = 2651560963248694165L;

        private String host;

        private List<PortVO> ports;

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public List<PortVO> getPorts() {
            return ports;
        }

        public void setPorts(List<PortVO> ports) {
            this.ports = ports;
        }
    }

    public static class PortVO implements Serializable {
        private static final long serialVersionUID = -5450841310939948797L;

        private Integer nodePort;

        private Integer port;

        private String protocol;

        private String targetPort;

        public PortVO() {
        }

        public PortVO(Integer nodePort, Integer port, String protocol, String targetPort) {
            this.nodePort = nodePort;
            this.port = port;
            this.protocol = protocol;
            this.targetPort = targetPort;
        }

        public Integer getNodePort() {
            return nodePort;
        }

        public void setNodePort(Integer nodePort) {
            this.nodePort = nodePort;
        }

        public Integer getPort() {
            return port;
        }

        public void setPort(Integer port) {
            this.port = port;
        }

        public String getProtocol() {
            return protocol;
        }

        public void setProtocol(String protocol) {
            this.protocol = protocol;
        }

        public String getTargetPort() {
            return targetPort;
        }

        public void setTargetPort(String targetPort) {
            this.targetPort = targetPort;
        }
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public String getClusterIP() {
        return clusterIP;
    }

    public void setClusterIP(String clusterIP) {
        this.clusterIP = clusterIP;
    }

    public EndpointVO getInternalEndpoint() {
        return internalEndpoint;
    }

    public void setInternalEndpoint(EndpointVO internalEndpoint) {
        this.internalEndpoint = internalEndpoint;
    }

    public List<EndpointVO> getExternalEndpoints() {
        return externalEndpoints;
    }

    public void setExternalEndpoints(List<EndpointVO> externalEndpoints) {
        this.externalEndpoints = externalEndpoints;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
