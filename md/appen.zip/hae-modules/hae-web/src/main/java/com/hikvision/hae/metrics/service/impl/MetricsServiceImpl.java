package com.hikvision.hae.metrics.service.impl;

import com.hikvision.hae.common.constant.CommonConstants;
import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.vo.MetricsTrendVO;
import com.hikvision.hae.metrics.assist.MetricsVOBuilder;
import com.hikvision.hae.metrics.biz.MetricsBiz;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.service.MetricsService;
import com.hikvision.hae.resource.node.biz.NodeBiz;
import com.hikvision.hae.resource.node.dto.NodeBaseDTO;
import io.fabric8.kubernetes.api.model.Quantity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
@Service
public class MetricsServiceImpl implements MetricsService {

	@Autowired
	private MetricsBiz metricsBiz;

	@Autowired
	private NodeBiz nodeBiz;

	@Override
	public MetricsTrendVO getNodeMetricsTrend(int nodeId, MetricsType metricsType) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		MetricsDTO metricsDTO = metricsBiz.metricsNode(nodeBaseDTO.getK8sName(), metricsType);
		return MetricsVOBuilder.buildMetricsTrendVO(String.valueOf(nodeId), metricsDTO, metricsType);
	}

	@Override
	public Map<String, String> getNodeGpuUsage(int nodeId) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeBaseDetail(nodeId);
		int gpuCount = 0;
		if (nodeBaseDTO.getCapacity() != null) {
			Quantity gpuCapacity = nodeBaseDTO.getCapacity().get(CommonConstants.MAP_GPU_RESOURCE_KEY_OF_K8S);
			if (gpuCapacity != null) {
				gpuCount = Integer.valueOf(gpuCapacity.getAmount());
			}
		}
		Map<String, String> gpuUsages = new HashMap<>();
		if (gpuCount <= 0) {
			return gpuUsages;
		}
		Calendar calendar = Calendar.getInstance();
		Date end = calendar.getTime();
		// 默认取当前时间到15分钟前的指标
		calendar.add(Calendar.MINUTE, -15);
		Date start = calendar.getTime();

		for (int i = 0; i < gpuCount; i++) {
			String gpuIndex = String.valueOf(i);
			MetricsDTO metricsDTO = metricsBiz.metricsNodeGpu(nodeBaseDTO.getK8sName(), gpuIndex, start, end, MetricsType.GPU_USAGE);
			if (metricsDTO != null && !CollectionUtils.isEmpty(metricsDTO.getMetrics())) {
				int size = metricsDTO.getMetrics().size();
				// 取最后一次监控的数据作为当前时间的实时使用率
				gpuUsages.put(gpuIndex, String.valueOf(metricsDTO.getMetrics().get(size - 1).getValue()));
			} else {
				gpuUsages.put(gpuIndex, "NA");
			}
		}
		return gpuUsages;
	}

	@Override
	public MetricsTrendVO getNodeGpuMetricsTrend(int nodeId, String gpuIndex, MetricsType metricsType) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		Calendar calendar = Calendar.getInstance();
		Date end = calendar.getTime();
		// 默认取当前时间到15分钟前的指标
		calendar.add(Calendar.MINUTE, -15);
		Date start = calendar.getTime();
		MetricsDTO metricsDTO = metricsBiz.metricsNodeGpu(nodeBaseDTO.getK8sName(), gpuIndex, start, end, metricsType);
		return MetricsVOBuilder.buildMetricsTrendVO(gpuIndex, metricsDTO, metricsType);
	}

	@Override
	public GpuBaseInfo getNodeGpuBaseInfo(int nodeId, String gpuIndex) {
		NodeBaseDTO nodeBaseDTO = nodeBiz.getNodeDBInfoById(nodeId);
		return metricsBiz.getNodeGpuBaseInfo(nodeBaseDTO.getK8sName(), gpuIndex);
	}

}
