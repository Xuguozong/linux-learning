package com.hikvision.hae.common.util.eventcenter.event;

import com.hikvision.hae.common.util.StringUtils;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.Instant;

/**
 *事件中心中事件的基类
 *
 * Created by zhouziwei on 2017/11/1.
 */
public class Event implements Serializable{

    private static final long serialVersionUID = 1330342817493802363L;

    // 事件的唯一标识，使用无参构造函数时会自动生成
    @NotNull(message = "field indexCode is required")
    private String indexCode;

    // 事件源：事件来自哪个模块
    @NotNull(message = "field source is required")
    private String source;

    // 事件发生的主体：用户等
    @NotNull(message = "field principalCategory is required")
    private PrincipalCategory principalCategory;

    // 主体行为类型：新增、修改、删除资源，用户登录、登出
    @NotNull(message = "field actionType is required")
    private PrincipalActionType actionType;

    // 事件发生的时间
    private Instant occurTime = Instant.now(); //默认值

    public Event() {
        this.indexCode = StringUtils.uuid();
    }

    public Event(String indexCode) {
        this.indexCode = indexCode;
    }

    public String getIndexCode() {
        return indexCode;
    }

    public void setIndexCode(String indexCode) {
        this.indexCode = indexCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public PrincipalCategory getPrincipalCategory() {
        return principalCategory;
    }

    public void setPrincipalCategory(PrincipalCategory principalCategory) {
        this.principalCategory = principalCategory;
    }

    public PrincipalActionType getActionType() {
        return actionType;
    }

    public void setActionType(PrincipalActionType actionType) {
        this.actionType = actionType;
    }

    public Instant getOccurTime() {
        return occurTime;
    }

    public void setOccurTime(Instant occurTime) {
        this.occurTime = occurTime;
    }

}
