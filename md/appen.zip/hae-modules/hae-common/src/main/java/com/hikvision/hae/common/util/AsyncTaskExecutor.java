package com.hikvision.hae.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Supplier;

/**
 * 封装异步任务执行逻辑
 *
 * @author jianghaiyang5 on 2017/11/8.
 */
public class AsyncTaskExecutor {

    private static final Logger logger = LoggerFactory.getLogger(AsyncTaskExecutor.class);

    private static final int DEFAULT_TIMEOUT_SECONDS = 60;

    private static ExecutorService executorService = Executors.newCachedThreadPool();

    /**
     * 异步地在新线程中执行单个任务
     *
     * @param task 单个待执行的任务
     * @return CompletableFuture对象
     */
    public static CompletableFuture<Void> tryExecute(Runnable task) {
        return CompletableFuture.runAsync(task, executorService);
    }

    /**
     * 多线程并行执行多个任务，并等待所有任务执行完，忽略任务返回值
     *
     * @param tasks 批量任务
     */
    public static void executeBatch(Runnable[] tasks) {
        List<CompletableFuture<Void>> futures = new ArrayList<>(tasks.length);
        for (Runnable task : tasks) {
            futures.add(CompletableFuture.runAsync(task, executorService));
        }
        for (CompletableFuture<Void> future : futures) {
            try {
                future.get(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                DelayedLogger.error(logger, () -> "异步任务执行异常：", e);
            }
        }
    }

    /**
     * 多线程并行执行多个任务，不等待任务执行完就立即返回
     *
     * @param tasks 批量任务
     * @return CompletableFuture对象集合
     */
    public static List<CompletableFuture<Void>> tryExecuteBatch(Runnable[] tasks) {
        List<CompletableFuture<Void>> futures = new ArrayList<>(tasks.length);
        for (Runnable task : tasks) {
            futures.add(CompletableFuture.runAsync(task, executorService));
        }
        return futures;
    }

    /**
     * 异步地在新线程中执行单个任务，有返回值
     *
     * @param taskSupplier 任务提供者
     * @param <T>          返回值类型
     * @return CompletableFuture对象
     */
    public static <T> CompletableFuture<T> tryExecute(Supplier<T> taskSupplier) {
        return CompletableFuture.supplyAsync(taskSupplier);
    }

    /**
     * 多线程并行执行多个任务，并等待所有任务执行完，有返回值
     *
     * @param taskSuppliers 批量任务
     * @return 任务的返回值在集合中的索引和任务本身索引相同
     */
    public static List<Object> executeBatch(List<Supplier<?>> taskSuppliers) {
        List<CompletableFuture<?>> futures = new ArrayList<>(taskSuppliers.size());
        for (Supplier<?> taskSupplier : taskSuppliers) {
            futures.add(CompletableFuture.supplyAsync(taskSupplier, executorService));
        }

        List<Object> result = new ArrayList<>(taskSuppliers.size());
        for (CompletableFuture<?> future : futures) {
            try {
                result.add(future.get(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS));
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                DelayedLogger.error(logger, () -> "异步任务执行异常：", e);
                result.add(null);
            }
        }
        return result;
    }

    /**
     * 多线程并行执行多个任务，不等待任务执行完就立即返回
     *
     * @param taskSuppliers 批量任务
     * @return CompletableFuture对象集合
     */
    public static List<CompletableFuture<Object>> tryExecuteBatch(Supplier<Object>[] taskSuppliers) {
        List<CompletableFuture<Object>> futures = new ArrayList<>(taskSuppliers.length);
        for (Supplier<Object> taskSupplier : taskSuppliers) {
            futures.add(CompletableFuture.supplyAsync(taskSupplier, executorService));
        }
        return futures;
    }
}
