package com.hikvision.hae.common.util.eventcenter.event;

import com.hikvision.hae.common.i18n.Localeable;

import java.util.stream.Stream;

/**
 * 事件的主体类别枚举
 * <p>
 * Created by zhouziwei on 2017/11/1.
 */
public enum PrincipalCategory implements Localeable {
    /**
     * 用户
     */
    USER,
    /**
     * 镜像
     */
    IMAGE,
    /**
     * 节点
     */
    NODE,
    /**
     * 应用日志
     */
    LOG,
    /**
     * 命名空间
     */
    NAMESPACE,
    /**
     * 配置集
     */
    CONFIG_MAP,
    /**
     * 守护进程集
     */
    DAEMON_SET,
    /**
     * 部署
     */
    DEPLOYMENT,
    /**
     * 访问权
     */
    INGRESS,
    /**
     * 任务
     */
    JOB,
    /**
     * 持久化存储卷索取
     */
    PERSISTENT_VOLUME_CLAIM,
    /**
     * 持久化存储卷
     */
    PERSISTENT_VOLUME,
    /**
     * 容器组
     */
    POD,
    /**
     * 副本集
     */
    REPLICA_SET,
    /**
     * 副本控制器
     */
    REPLICATION_CONTROLLER,
    /**
     * 保密字典
     */
    SECRET,
    /**
     * 服务
     */
    SERVICE,
    /**
     * 服务账号
     */
    SERVICE_ACCOUNT,
    /**
     * 有状态副本集
     */
    STATEFUL_SET,
    /**
     * 存储类
     */
    STORAGE_CLASS,
    /**
     * HPA
     */
    HORIZONTAL_POD_AUTOSCALER,
    /**
     * K8S资源文件
     */
    RESOURCE_FILE,
    /**
     * 资源限额
     */
    RESOURCE_QUOTA,
    /**
     * LIMIT限制
     */
    LIMIT_RANGE,

    /**
     * K8S角色
     */
    ROLE,
    /**
     * K8S集群角色
     */
    CLUSTER_ROLE,
    /**
     * K8S角色绑定
     */
    ROLE_BINDING,
    /**
     * K8S集群角色绑定
     */
    CLUSTER_ROLE_BINDING;

    private final String i18nPrefix = "EVENT_CENTER.PRINCIPAL.";

    public static PrincipalCategory parse(String name) {
        return Stream.of(PrincipalCategory.values()) // 由数组构建流
                .filter(c -> c.name().equals(name)) // 设置筛选条件为name相等
                .findFirst() // 找到第一个相等的就结束
                .orElse(null); // 如果没有name相等的枚举实例则返回null
    }

    /**
     * 获取当前枚举常量在视图中的国际化文本的key
     *
     * @return
     */
    @Override
    public String i18nKey() {
        return i18nPrefix + this.name();
    }

}
