package com.hikvision.hae.common.util;

import java.math.BigDecimal;

/**
 * 小数位数保留工具类
 *
 * @author xieyuejun
 */
public class DigitUtils {

	/**
	 * 四舍五入保留一位小数
	 *
	 * @param val
	 * @return 保留一位位小数
	 */
	public static Double toOneDigit(Double val) {
		return new BigDecimal(val).setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	/**
	 * 四舍五入保留两位小数
	 *
	 * @param val
	 * @return 保留两位位小数
	 */
	public static Double toTwoDigits(Double val) {
		return new BigDecimal(val).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	/**
	 * 四舍五入保留三位小数
	 *
	 * @param val
	 * @return 保留三位小数
	 */
	public static Double toThreeDigits(Double val) {
		return new BigDecimal(val).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	/**
	 * 四舍五入保留两位小数
	 *
	 * @param val
	 * @return 保留两位位小数
	 */
	public static String toTwoDigitsString(Double val) {
		return new BigDecimal(val).setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString();
	}

	/**
	 * 返回百分比（四舍五入保留两位小数）
	 *
	 * @param val
	 * @return
	 */
	public static String toTwoDigitsPercent(Double val) {
		return new BigDecimal(val).multiply(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString();
	}

	/**
	 * 数值转换KB->GB
	 *
	 * @param valkB
	 * @return
	 */
	public static double transB2GB(double valkB) {
		return valkB / 1024 / 1024 / 1024;
	}

	/**
	 * 数值转换KB->TB
	 *
	 * @param valkB
	 * @return
	 */
	public static double transB2TB(double valkB) {
		return valkB / 1024 / 1024 / 1024 / 1024;
	}
}
