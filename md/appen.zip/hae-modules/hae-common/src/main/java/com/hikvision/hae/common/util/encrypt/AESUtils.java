/**
 * @Copyright: 2010 HangZhou Hikvision System Technology Co., Ltd. All Right Reserved.
 * @address: http://www.hikvision.com
 * @date: 2013-3-27 上午09:41:47
 */
package com.hikvision.hae.common.util.encrypt;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;

/**
 * 封装V6.x平台中AES加密和解密的算法
 * 
 * @author huanghuafeng 2013-3-27 上午09:41:47
 * @version V1.0
 */
public class AESUtils {

	private static Cipher cipher = null;

	private static Cipher getCipher() throws NoSuchAlgorithmException, NoSuchPaddingException {
		cipher = Cipher.getInstance("AES/CFB/NoPadding");
		return cipher;
	}

	/**
	 * AES加密原文
	 * 
	 * @author huanghuafeng 2013-4-17 上午11:31:19
	 * @param sSrc
	 *            原文
	 * @param sKey
	 *            密钥
	 * @param ivParameter
	 *            cbc加密的起始向量，长度必须是16
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptWithBase64(byte[] sSrc, String sKey, String ivParameter) throws Exception {
		ensureSrcNotNull(sSrc);
		ensureKeyIsRight(sKey);
		byte[] raw = sKey.getBytes("UTF8");
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = getCipher();
		// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
		IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes(Charset.forName("UTF8")));
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
		byte[] encrypted = cipher.doFinal(sSrc);
		return Base64.encodeBase64(encrypted);
	}

	/**
	 * 使用aes算法解密<br>
	 * 算法是方法encryptWithBase64的反向
	 * 
	 * @see AESUtils#encryptWithBase64(String ,String);
	 * @author huanghuafeng 2013-4-17 上午11:34:07
	 * @param sSrc
	 *            密文
	 * @param sKey
	 *            密钥
	 * @param ivParameter
	 *            cbc解密的起始向量，长度必须是16
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptWithBase64(byte[] sSrc, String sKey, String ivParameter) throws Exception {
		ensureSrcNotNull(sSrc);
		ensureKeyIsRight(sKey);
		byte[] raw = sKey.getBytes("UTF8");
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = getCipher();
		// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
		IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes(Charset.forName("UTF8")));
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
		byte[] encrypted = new Base64().decode(sSrc);
		byte[] original = cipher.doFinal(encrypted);
		return original;
	}

    public static String encryptWithBase64(String plainText, String sKey, String ivParameter) throws Exception {
        try {
            byte[] bts = plainText.getBytes("UTF-8");
            byte[] encryptedBts = encryptWithBase64(bts, sKey, ivParameter);
            return new String(encryptedBts, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e); //其实不可能发生，utf-8肯定是支持的
        }
    }

    public static String decryptWithBase64(String encrytedText, String sKey, String ivParameter) throws Exception {
        try {
            byte[] bts = encrytedText.getBytes("UTF-8");
            byte[] decryptedBts = decryptWithBase64(bts, sKey, ivParameter);
            return new String(decryptedBts, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e); //其实不可能发生，utf-8肯定是支持的
        }
    }

	private static void ensureSrcNotNull(byte[] sSrc) {
		if (sSrc == null) {
			throw new IllegalArgumentException("src is empty.");
		}
	}

	private static void ensureKeyIsRight(String key) {
		// 判断Key是否正确
		if (key == null) {
			throw new IllegalArgumentException("key is empty.");
		}
		// 判断Key是否为16位
		if (key.length() != 16) {
			throw new IllegalArgumentException("Key length is wrong.");
		}
	}
	
	private static final String FISH = "clown_lie_to_hae";

	public static String encrypt(String info) {
		try {
			byte[] kbytes = FISH.getBytes();
			SecretKeySpec key = new SecretKeySpec(kbytes, "AES");
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encoding = cipher.doFinal(info.getBytes());
			BigInteger n = new BigInteger(encoding);
			return n.toString(16);
		} catch (Exception e) {
			throw new IllegalArgumentException(e);
		}
	}

	public static String decrypt(String info) {
		try {
			byte[] kbytes = FISH.getBytes();
			SecretKeySpec key = new SecretKeySpec(kbytes, "AES");
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, key);
			BigInteger n = new BigInteger(info, 16);
			byte[] encoding = n.toByteArray();
			byte[] decode = cipher.doFinal(encoding);
			return new String(decode);
		} catch (Exception e) {
			throw new IllegalArgumentException(e);
		}
	}

}
