package com.hikvision.hae.common.util.eventcenter;

import com.alibaba.fastjson.JSON;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.Event;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalCategory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 监听所有事件，以JSON格式将事件内容输出到标准输出。
 *
 */
public class DefaultEventListener implements EventListener {
    private static Logger logger = LoggerFactory.getLogger(DefaultEventListener.class);

    @Override
    public void process(Event event) {
        DelayedLogger.info(logger, () -> "[Event] " + JSON.toJSONString(event));
    }

    @Override
    public boolean support(Event event) {
        return true;
    }

    @Override
    public boolean interest(PrincipalCategory category, PrincipalActionType actionType) {
        return true;
    }
}
