package com.hikvision.hae.common.constant;

/**
 * 公用常量
 *
 * @author zhanjiejun
 */
public class CommonConstants {

	// session中登录用户的key
	public static final String LOGIN_USER = "_login_user";

	// session中需要激活的用户的key前缀
	public static final String PRE_LOGIN_USER_PREFIX = "_pre_login_user_";

	/**
	 * 激活态系统资源在model中的Key
	 */
	public static final String ACTIVE_SYS_RESOURCE = "ACTIVE_SYS_RESOURCE";

	/**
	 * 弱密码级别
	 */
	public static final int WEAK_PASSWORD_LEVEL = 1;

	/**
	 * 中密码级别
	 */
	public static final int MIDDLE_PASSWORD_LEVEL = 2;

	/**
	 * 强密码级别
	 */
	public static final int STRONG_PASSWORD_LEVEL = 3;

	/**
	 * Map中CPU资源Key
	 */
	public static final String MAP_CPU_RESOURCE_KEY = "cpu";

	/**
	 * Map中内存资源Key
	 */
	public static final String MAP_MEMORY_RESOURCE_KEY = "memory";

	/**
	 * Map中存储资源Key
	 */
	public static final String MAP_STORAGE_RESOURCE_KEY = "storage";

	/**
	 * Map中POD资源Key
	 */
	public static final String MAP_POD_RESOURCE_KEY = "pods";

	/**
	 * K8S Map中GPU资源Key
	 */
	public static final String MAP_GPU_RESOURCE_KEY_OF_K8S = "alpha.kubernetes.io/nvidia-gpu";

	/**
	 * 前端数据 Map中GPU资源Key
	 */
	public static final String MAP_GPU_RESOURCE_KEY_FOR_FRONT = "gpu";

	public static final String K8S_MASTER_NODE_LABEL_KEY = "node-role.kubernetes.io/master";

	public static final String K8S_MASTER_NODE_LABEL_VALUE = "true";

	/**
	 * ansible主机标签键
	 */
	public static final String ANSIBLE_NODE_LABEL_KEY = "hikcloud.kubernetes.io/ansible";

	/**
	 * ansible主机标签值
	 */
	public static final String ANSIBLE_NODE_LABEL_VALUE = "true";

}
