package com.hikvision.hae.common.util;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import org.springframework.util.CollectionUtils;

import java.util.Comparator;
import java.util.List;

/**
 * 顾名思义：数据选择器。从一批数据中选择一些符合条件的数据。
 *
 * @author jianghaiyang5 on 2017/11/3.
 */
public class DataSelector {


    /**
     * 内存分页。先排序后分页。如果起始下标大于分页的元素数量，返回空集合
     *
     * @param items     待分页的对象集合
     * @param sortBy    排序用的比较器
     * @param pageParam 分页参数
     * @param <T>       对象的类型
     * @return 分页后的对象集合
     */
    public static <T> Pagination<T> paginate(List<T> items, Comparator<T> sortBy, PageParam pageParam) {
        Pagination<T> pageResult = Pagination.build(pageParam);
        if (CollectionUtils.isEmpty(items)) {
            return pageResult;
        }
        int size = items.size();
        int pageNo = pageParam.getPageNo(); //从1开始
        int pageSize = pageParam.getPageSize();

        int fromIndex = (pageNo - 1) * pageSize;
        if (fromIndex >= size) {
            return pageResult;
        }
        if(sortBy != null){
            items.sort(sortBy);
        }
        int toIndex = pageNo * pageSize;
        if (toIndex >= size) {
            toIndex = size;
        }
        pageResult.setRows(items.subList(fromIndex, toIndex));
        pageResult.setTotal(size);
        pageResult.setLastPage((size - 1) / pageSize + 1);
        return pageResult;
    }
}
