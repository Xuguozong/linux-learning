package com.hikvision.hae.common.util;

import org.slf4j.Logger;

import java.util.function.Supplier;

/**
 * 传统的写法有两种： 用法一：
 * 
 * <pre>
 * {@code
 * logger.error("Problem： "+ getErrorMessage());
 * }
 * </pre>
 * 
 * 用法二：
 * 
 * <pre>
 * {@code
 * if(logger.isErrorEnable()){
 * 	logger.error("Problem： "+ getErrorMessage());
 * }}
 * </pre>
 * 
 * 用法二相比用法一在仅当日志器支持error级别时才会调用logger.error方法，但仍然存在一些问题： 
 * 1）日志的状态（当前支持的日志级别）需要通过isErrorEnable暴露给客户端 <br/>
 * 2）在每次输出日志之前都需要先查询日志器状态 <br/>
 * 3）用法一在无论日志级别是否支持时都需要构造消息记录 <br/>
 * 
 * DelayedLogger参考JDK8的java.util.logging.Logger对slf4j常用方法做了延迟执行封装。 
 * 1）不会向客户端暴露日志器的内部状态; <br/>
 * 2）仅当日志器logger的级别设置恰当时，日志器才会执行作为参数传递进来的lambda表达式.<br/>
 * 
 * @author jianghaiyang5 2017年6月6日
 *
 */
public class DelayedLogger {

	/**
	 * Log a message at the TRACE level.
	 * 
	 * @param logger
	 * @param messageSupplier the message string to be logged
	 */
	public static void trace(Logger logger, Supplier<String> messageSupplier) {
		if (logger.isTraceEnabled()) {
			logger.trace(messageSupplier.get());
		}
	}

	/**
	 * Log a message at the DEBUG level.
	 * 
	 * @param logger
	 * @param messageSupplier the message string to be logged
	 */
	public static void debug(Logger logger, Supplier<String> messageSupplier) {
		if (logger.isDebugEnabled()) {
			logger.debug(messageSupplier.get());
		}
	}

	/**
	 * Log a message at the INFO level.
	 * 
	 * @param logger
	 * @param messageSupplier the message string to be logged
	 */
	public static void info(Logger logger, Supplier<String> messageSupplier) {
		if (logger.isInfoEnabled()) {
			logger.info(messageSupplier.get());
		}
	}

	/**
	 * Log a message at the WARN level.
	 * 
	 * @param logger
	 * @param messageSupplier the message string to be logged
	 */
	public static void warn(Logger logger, Supplier<String> messageSupplier) {
		if (logger.isWarnEnabled()) {
			logger.warn(messageSupplier.get());
		}
	}

	/**
	 * Log a message at the ERROR level.
	 * 
	 * @param logger
	 * @param messageSupplier the message string to be logged
	 */
	public static void error(Logger logger, Supplier<String> messageSupplier) {
		if (logger.isErrorEnabled()) {
			logger.error(messageSupplier.get());
		}
	}

	/**
	 * Log an exception (throwable) at the TRACE level with an accompanying message
	 * 
	 * @param logger
	 * @param messageSupplier
	 *            the message accompanying the exception
	 * @param t
	 *            the exception (throwable) to log
	 */
	public static void trace(Logger logger, Supplier<String> messageSupplier, Throwable t) {
		if (logger.isTraceEnabled()) {
			logger.trace(messageSupplier.get(), t);
		}
	}

	/**
	 * Log an exception (throwable) at the debug level with an accompanying message
	 * 
	 * @param logger
	 * @param messageSupplier
	 *            the message accompanying the exception
	 * @param t
	 *            the exception (throwable) to log
	 */
	public static void debug(Logger logger, Supplier<String> messageSupplier, Throwable t) {
		if (logger.isDebugEnabled()) {
			logger.debug(messageSupplier.get(), t);
		}
	}

	/**
	 * Log an exception (throwable) at the info level with an accompanying message
	 * 
	 * @param logger
	 * @param messageSupplier
	 *            the message accompanying the exception
	 * @param t
	 *            the exception (throwable) to log
	 */
	public static void info(Logger logger, Supplier<String> messageSupplier, Throwable t) {
		if (logger.isInfoEnabled()) {
			logger.info(messageSupplier.get(), t);
		}
	}

	/**
	 * Log an exception (throwable) at the warn level with an accompanying message
	 * 
	 * @param logger
	 * @param messageSupplier
	 *            the message accompanying the exception
	 * @param t
	 *            the exception (throwable) to log
	 */
	public static void warn(Logger logger, Supplier<String> messageSupplier, Throwable t) {
		if (logger.isWarnEnabled()) {
			logger.warn(messageSupplier.get(), t);
		}
	}

	/**
	 * Log an exception (throwable) at the error level with an accompanying message
	 * 
	 * @param logger
	 * @param messageSupplier
	 *            the message accompanying the exception
	 * @param t
	 *            the exception (throwable) to log
	 */
	public static void error(Logger logger, Supplier<String> messageSupplier, Throwable t) {
		if (logger.isErrorEnabled()) {
			logger.error(messageSupplier.get(), t);
		}
	}

	/**
	 * Log a message at the TRACE level according to the specified format and argument.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg
	 *            the argument
	 */
	public static void trace(Logger logger, Supplier<String> format, Object arg) {
		if (logger.isTraceEnabled()) {
			logger.trace(format.get(), arg);
		}
	}

	/**
	 * Log a message at the DEBUG level according to the specified format and argument.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg
	 *            the argument
	 */
	public static void debug(Logger logger, Supplier<String> format, Object arg) {
		if (logger.isDebugEnabled()) {
			logger.debug(format.get(), arg);
		}
	}

	/**
	 * Log a message at the INFO level according to the specified format and argument.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg
	 *            the argument
	 */
	public static void info(Logger logger, Supplier<String> format, Object arg) {
		if (logger.isInfoEnabled()) {
			logger.info(format.get(), arg);
		}
	}

	/**
	 * Log a message at the WARN level according to the specified format and argument.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg
	 *            the argument
	 */
	public static void warn(Logger logger, Supplier<String> format, Object arg) {
		if (logger.isWarnEnabled()) {
			logger.warn(format.get(), arg);
		}
	}

	/**
	 * Log a message at the ERROR level according to the specified format and argument.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg
	 *            the argument
	 */
	public static void error(Logger logger, Supplier<String> format, Object arg) {
		if (logger.isErrorEnabled()) {
			logger.error(format.get(), arg);
		}
	}

	/**
	 * Log a message at the TRACE level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg1
	 *            the first argument
	 * @param arg2
	 *            the second argument
	 */
	public static void trace(Logger logger, Supplier<String> format, Object arg1, Object arg2) {
		if (logger.isTraceEnabled()) {
			logger.trace(format.get(), arg1, arg2);
		}
	}

	/**
	 * Log a message at the DEBUG level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg1
	 *            the first argument
	 * @param arg2
	 *            the second argument
	 */
	public static void debug(Logger logger, Supplier<String> format, Object arg1, Object arg2) {
		if (logger.isDebugEnabled()) {
			logger.debug(format.get(), arg1, arg2);
		}
	}

	/**
	 * Log a message at the INFO level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg1
	 *            the first argument
	 * @param arg2
	 *            the second argument
	 */
	public static void info(Logger logger, Supplier<String> format, Object arg1, Object arg2) {
		if (logger.isInfoEnabled()) {
			logger.info(format.get(), arg1, arg2);
		}
	}

	/**
	 * Log a message at the WARN level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg1
	 *            the first argument
	 * @param arg2
	 *            the second argument
	 */
	public static void warn(Logger logger, Supplier<String> format, Object arg1, Object arg2) {
		if (logger.isWarnEnabled()) {
			logger.warn(format.get(), arg1, arg2);
		}
	}

	/**
	 * Log a message at the ERROR level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arg1
	 *            the first argument
	 * @param arg2
	 *            the second argument
	 */
	public static void error(Logger logger, Supplier<String> format, Object arg1, Object arg2) {
		if (logger.isErrorEnabled()) {
			logger.error(format.get(), arg1, arg2);
		}
	}

	/**
	 * Log a message at the TRACE level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arguments
	 *            a list of 3 or more arguments
	 */
	public static void trace(Logger logger, Supplier<String> format, Object... arguments) {
		if (logger.isTraceEnabled()) {
			logger.trace(format.get(), arguments);
		}
	}

	/**
	 * Log a message at the DEBUG level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arguments
	 *            a list of 3 or more arguments
	 */
	public static void debug(Logger logger, Supplier<String> format, Object... arguments) {
		if (logger.isDebugEnabled()) {
			logger.debug(format.get(), arguments);
		}
	}

	/**
	 * Log a message at the INFO level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arguments
	 *            a list of 3 or more arguments
	 */
	public static void info(Logger logger, Supplier<String> format, Object... arguments) {
		if (logger.isInfoEnabled()) {
			logger.info(format.get(), arguments);
		}
	}

	/**
	 * Log a message at the WARN level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arguments
	 *            a list of 3 or more arguments
	 */
	public static void warn(Logger logger, Supplier<String> format, Object... arguments) {
		if (logger.isWarnEnabled()) {
			logger.warn(format.get(), arguments);
		}
	}

	/**
	 * Log a message at the ERROR level according to the specified format and arguments.
	 * 
	 * @param logger
	 * @param format
	 *            the format string
	 * @param arguments
	 *            a list of 3 or more arguments
	 */
	public static void error(Logger logger, Supplier<String> format, Object... arguments) {
		if (logger.isErrorEnabled()) {
			logger.error(format.get(), arguments);
		}
	}
}
