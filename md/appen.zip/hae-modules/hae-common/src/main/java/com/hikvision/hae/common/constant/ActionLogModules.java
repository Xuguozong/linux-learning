package com.hikvision.hae.common.constant;

/**
 * 操作日志模块常量
 * <p>
 * Created by zhouziwei on 2017/11/17.
 */
public class ActionLogModules {
    /**
     * 用户管理(登录、登出、修改密码)
     */
    public static final String USER_MANAGE = "USER_MANAGE";
    /**
     * 镜像管理
     */
    public static final String IMAGE_MANAGE = "IMAGE_MANAGE";
    /**
     * 节点管理
     */
    public static final String NODE_MANAGE = "NODE_MANAGE";
    /**
     * 应用日志管理
     */
    public static final String LOG_MANAGE = "LOG_MANAGE";
    /**
     * 命名空间管理
     */
    public static final String NAMESPACE_MANAGE = "NAMESPACE_MANAGE";

    /**
     * 配置集
     */
    public static final String CONFIG_MAP = "CONFIG_MAP";
    /**
     * 守护进程集
     */
    public static final String DAEMON_SET = "DAEMON_SET";
    /**
     * 部署
     */
    public static final String DEPLOYMENT = "DEPLOYMENT";
    /**
     * 访问权
     */
    public static final String INGRESS = "INGRESS";
    /**
     * 任务
     */
    public static final String JOB = "JOB";

    /**
     * 持久化存储卷索取
     */
    public static final String PERSISTENT_VOLUME_CLAIM = "PERSISTENT_VOLUME_CLAIM";

    /**
     * 持久化存储卷
     */
    public static final String PERSISTENT_VOLUME = "PERSISTENT_VOLUME";
    /**
     * 容器组
     */
    public static final String POD = "POD";
    /**
     * 副本集
     */
    public static final String REPLICA_SET = "REPLICA_SET";
    /**
     * 副本控制器
     */
    public static final String REPLICATION_CONTROLLER = "REPLICATION_CONTROLLER";
    /**
     * 保密字典
     */
    public static final String SECRET = "SECRET";
    /**
     * 服务
     */
    public static final String SERVICE = "SERVICE";
    /**
     * 有状态副本集
     */
    public static final String STATEFUL_SET = "STATEFUL_SET";
    /**
     * 存储类
     */
    public static final String STORAGE_CLASS = "STORAGE_CLASS";
    /**
     * HPA
     */
    public static final String HORIZONTAL_POD_AUTOSCALER = "HORIZONTAL_POD_AUTOSCALER";
    /**
     * 编辑YAML
     */
    public static final String YAML_EDIT = "YAML_EDIT";
    /**
     * 资源文件管理
     */
    public static final String RESOURCE_FILE_MGMT = "RESOURCE_FILE_MGMT";
    
    /**
     * 服务账号
     */
    public static final String SERVICE_ACCOUNT = "SERVICE_ACCOUNT";

    /**
     * 资源限额
     */
    public static final String RESOURCE_QUOTA = "RESOURCE_QUOTA";

    /**
     * LIMIT限制
     */
    public static final String LIMIT_RANGE = "LIMIT_RANGE";
}
