package com.hikvision.hae.common.util.eventcenter;

import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * 临时的任务队列
 *
 */
public class EventQueue {
	private static Logger logger = LoggerFactory.getLogger(EventPublisher.class);

	private static LinkedBlockingQueue<Event> eventQueue;

	static {
		eventQueue = new LinkedBlockingQueue<>();
	}

	public static void addEvent(Event e) {
		eventQueue.offer(e);
	}

	public static Event fetchEvent() {
		try {
			return eventQueue.take();
		} catch (InterruptedException e) {
			DelayedLogger.error(logger, () -> e.getMessage(), e);
		}
		return null;
	}

}
