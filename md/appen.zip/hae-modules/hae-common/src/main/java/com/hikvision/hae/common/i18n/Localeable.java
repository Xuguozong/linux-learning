package com.hikvision.hae.common.i18n;

/**
 * 实现该接口的类拥有国际化文本的能力
 *
 * Created by zhouziwei on 2017/11/1.
 */
@FunctionalInterface
public interface Localeable {

    /**
     * 返回国际化资源配置文件中定义的key
     *
     * @return
     */
    String i18nKey();
}
