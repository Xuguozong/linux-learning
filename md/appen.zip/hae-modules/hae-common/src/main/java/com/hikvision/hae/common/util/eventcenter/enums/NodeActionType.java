package com.hikvision.hae.common.util.eventcenter.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.util.eventcenter.event.PrincipalActionType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;

/**
 * 节点
 *
 * Created by zhouziwei on 2017/11/6.
 */
public enum NodeActionType implements PrincipalActionType{
    /**
     * 新建
     */
    ADD,
    /**
     * 更新
     */
    UPDATE,
    /**
     * 删除
     */
    DELETE,
    /**
     * 增加标签
     */
    TAG_ADD,
    /**
     * 删除标签
     */
    TAG_DELETE,
    /**
     * 新增SSH信息
     */
    SSH_ADD,
    /**
     * 删除SSH信息
     */
    SSH_DELETE,
    /**
     * 软删除
     */
    SOFT_DELETE,
    /**
     * 硬删除
     */
    HARD_DELETE,
    /**
     * 维护模式
     */
    MAINTENANCE_MODE;

    private final String i18nPrefix = "EVENT_CENTER.ACTION_TYPE.NODE.";

    private static final Logger logger = LoggerFactory.getLogger(NodeActionType.class);

    public static NodeActionType parse(String name) {
        NodeActionType actionType = Stream.of(NodeActionType.values()).filter(c -> c.name().equals(name)).findFirst().orElse(null);
        if (actionType == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型VmwareActionType失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return actionType;
    }

    /**
     * 获取当前枚举常量在视图中的国际化文本的key
     *
     * @return
     */
    @Override
    public String i18nKey() {
        return i18nPrefix + this.name();
    }
}
