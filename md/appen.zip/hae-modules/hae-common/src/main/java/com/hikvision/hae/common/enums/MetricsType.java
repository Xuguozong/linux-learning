package com.hikvision.hae.common.enums;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public enum MetricsType {

	/**
	 * 内存使用率
	 */
	MEMORY_USAGE("memory/usage", "GiB"),

	/**
	 * CPU使用率
	 */
	CPU_USAGE_RATE("cpu/usage_rate", "Cores"),

	/**
	 * GPU风扇转速
	 */
	GPU_FAN_SPEED("fan_speed", "转"),

	/**
	 * GPU显存
	 */
	GPU_MEMORY_USED("memory_used", "MiB"),

	/**
	 * GPU能耗
	 */
	GPU_POWER_DRAW("power_draw", "W"),

	/**
	 * GPU温度
	 */
	GPU_TEMPERATURE("temperature", "℃"),

	/**
	 * GPU使用率
	 */
	GPU_USAGE("gpu_util", "%");

	MetricsType(String type, String unit) {
		this.type = type;
		this.unit = unit;
	}

	private String type;

	private String unit;

	public String getType() {
		return type;
	}

	public String getUnit() {
		return unit;
	}

}
