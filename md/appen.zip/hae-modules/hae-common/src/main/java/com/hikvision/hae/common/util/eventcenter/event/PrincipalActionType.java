package com.hikvision.hae.common.util.eventcenter.event;

import com.hikvision.hae.common.i18n.Localeable;

/**
 * Created by zhouziwei on 2017/11/1.
 */
public interface PrincipalActionType extends Localeable {
    String name();
}
