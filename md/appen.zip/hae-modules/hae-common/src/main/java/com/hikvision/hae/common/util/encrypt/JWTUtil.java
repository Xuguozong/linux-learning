package com.hikvision.hae.common.util.encrypt;

import com.alibaba.fastjson.JSON;
import com.auth0.jwt.JWTSigner;
import com.auth0.jwt.JWTVerifier;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 从云门户复用
 * 
 * @author zhanjiejun
 *
 */
@Component
public class JWTUtil {

	private static final Logger logger = LoggerFactory.getLogger(JWTUtil.class);
	
	private static JWTUtil jwtUtil;

	@PostConstruct
	public void init() {
		jwtUtil = this;
		jwtUtil.iss = this.iss;
		jwtUtil.exp = this.exp;
	}

	@Value("${hae.jwt.iss:HAE}")
	private String iss;

	@Value("${hae.jwt.exp:120}")
	private long exp;

	/**
	 * @param sub
	 *            签发对象
	 * @return
	 */
	public static String signJWT(final String sec, final String sub) {
		return signJWT(sec, sub, null, null);
	}

	/**
	 * @param sub
	 *            签发对象
	 * @param extJSON
	 *            额外的属性，按JSON编码
	 * @return
	 */
	public static String signJWT(final String sec, final String sub, final String extJSON) {
		return signJWT(sec, sub, extJSON, null);
	}

	/**
	 * @param sub
	 *            签发对象
	 * @param extMap
	 *            额外的属性
	 * @return
	 */
	public static String signJWT(final String sec, final String sub, final Map<String, Object> extMap) {
		return signJWT(sec, sub, null, extMap);
	}

	/**
	 *
	 * @param sub
	 *            签发对象
	 * @param extJSON
	 *            额外数据，以extJSON为名
	 * @param extMap
	 *            额外数据Map，自定义键值对
	 * @return
	 */
	public static String signJWT(final String sec, final String sub, final String extJSON, final Map<String, Object> extMap) {
		final long iat = System.currentTimeMillis() / 1000L; // 签发时间
		final long exp = iat + jwtUtil.exp; // 过期时间
		final JWTSigner signer = new JWTSigner(sec);
		final HashMap<String, Object> claims = new HashMap<String, Object>();
		claims.put("iss", jwtUtil.iss); // 签发者
		claims.put("sub", sub); // 签发对象
		claims.put("iat", iat); // 签发时间
		claims.put("exp", exp); // 过期时间
		if (extJSON != null) {
			claims.put("extJSON", extJSON);
		}
		if (extMap != null) {
			extMap.forEach(claims::put);
		}
		return signer.sign(claims);
	}

	public static boolean verifyJWT(final String sec, final String jwt) {
		if (StringUtils.isBlank(jwt)) {
			return false;
		}
		try {
			final JWTVerifier verifier = new JWTVerifier(sec);
			Map<String, Object> claims = verifier.verify(jwt);
			logger.debug("Claims -> {}", JSON.toJSONString(claims));
			logger.debug("iss -> {}", jwtUtil.iss);
			// 判断签发者
			// TODO 后续按需求修改
			String iss = (String) claims.get("iss");
			if (!jwtUtil.iss.equals(iss)) {
				return false;
			}
			return true;
		} catch (Exception e) {
			logger.error("Decode jwt failed.", e);
			return false;
		}
	}

}
