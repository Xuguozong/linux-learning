package com.hikvision.hae.common.vo;

import java.io.Serializable;

/**
 * 分页参数VO
 * 
 * @author zhanjiejun
 *
 */
public class PageParam implements Serializable {
    private static final long serialVersionUID = 4115696002935390367L;

    private int pageNo = 1;
	
	private int pageSize = 10;

    public PageParam() {
    }

    public PageParam(int pageNo, int pageSize) {
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }

    public static PageParam defaultPageParam(){
        return new PageParam();
    }

    public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public int getStart() {
        return (pageNo - 1) * pageSize;
    }

}
