package com.hikvision.hae.common.util;

/**
 * Created by zhanjiejun on 2017/11/10.
 */
public class K8SResourceUnitConverter {

	/**
	 * CPU
	 *
	 * @param amount
	 * @return 单位：cores
	 */
	public static double convertCPU2Cores(String amount) {
		// 暂时知道的单位：k、m
		// 1000m = 1cores 1k = 1000cores
		if (amount.endsWith("m")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) / 1000);
		} else if (amount.endsWith("k")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) * 1000);
		} else {
			return DigitUtils.toTwoDigits(Double.valueOf(amount));
		}
	}

	/**
	 * 内存
	 *
	 * @param amount
	 * @return 单位：Gi
	 */
	public static double convertMemory2Gi(String amount) {
		// 暂时知道的单位：Ti bytes、Ki bytes、Mi bytes、Gi bytes、m bytes、bytes，在K8S中单位中的B被省略了
		// 1Gi bytes = 1024Mi bytes = 1024*1024Ki bytes = 1024*1024*1024 bytes
		// 1 bytes = 1000m bytes
		// 1Ti bytes = 1024Gi bytes
		// 1T = 1000G = 1000*1000M = 1000*1000*1000K
		if (amount.endsWith("Ti")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 2)) * 1024);
		} else if (amount.endsWith("Gi")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 2)));
		} else if (amount.endsWith("Mi")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 2)) / 1024);
		} else if (amount.endsWith("Ki")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 2)) / 1024 / 1024);
		} else if (amount.endsWith("m")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) / 1024 / 1024 / 1024 / 1000);
		} else if (amount.endsWith("T")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) * 1000 * 1000 * 1000 * 1000 / 1024 / 1024 / 1024);
		} else if (amount.endsWith("G")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) * 1000 * 1000 * 1000 / 1024 / 1024 / 1024);
		} else if (amount.endsWith("M")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) * 1000 * 1000 / 1024 / 1024 / 1024);
		} else if (amount.endsWith("K")) {
			return DigitUtils.toTwoDigits(Double.valueOf(amount.substring(0, amount.length() - 1)) * 1000 / 1024 / 1024 / 1024);
		} else {
			return DigitUtils.toTwoDigits(Double.valueOf(amount) / 1024 / 1024 / 1024);
		}
	}

	/**
	 * GPU
	 *
	 * @param amount
	 * @return 单位：张
	 */
	public static int formatGPUAmount(String amount) {
		//GPU单位只有张。但是get到的是String类型。转成int
		return Integer.valueOf(amount);
	}

}
