package com.hikvision.hae.common.util;

import java.util.*;
import java.util.stream.Stream;

/**
 * Collection相关工具类
 *
 * Created by zhouziwei on 2017/11/8.
 */
public class CollectionUtils {

    public static boolean isEmpty(Collection<?> collection) {
        return collection == null || collection.isEmpty();
    }

    public static boolean isEmpty(Map<?, ?> map) {
        return map == null || map.isEmpty();
    }

    public static boolean isEmpty(String[] arr) {
        return arr == null || arr.length == 0 || Stream.of(arr).filter(a -> a.length() > 0).count() == 0;
    }

    public static boolean isNotEmpty(Collection<?> collection) {
        return !isEmpty(collection);
    }

    public static String commaJoin(Collection<String> collection) {
        if (isEmpty(collection)) {
            return null;
        }
        return String.join(",", collection);
    }

    public static boolean containsInstance(Collection<?> collection, Object element) {
        if (collection != null) {
            Iterator<?> var2 = collection.iterator();
            while (var2.hasNext()) {
                Object candidate = var2.next();
                if (candidate == element) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean containsAny(Collection<?> source, Collection<?> candidates) {
        if (!isEmpty(source) && !isEmpty(candidates)) {
            Iterator<?> var2 = candidates.iterator();
            Object candidate;
            do {
                if (!var2.hasNext()) {
                    return false;
                }
                candidate = var2.next();
            } while (!source.contains(candidate));
            return true;
        } else {
            return false;
        }
    }

    public static <E> List<E> iterableToList(Iterable<E> iter) {
        if (iter instanceof List) {
            return (List<E>) iter;
        }
        List<E> list = new ArrayList<E>();
        if (iter != null) {
            iter.forEach((i) -> list.add(i));
        }
        return list;
    }
}
