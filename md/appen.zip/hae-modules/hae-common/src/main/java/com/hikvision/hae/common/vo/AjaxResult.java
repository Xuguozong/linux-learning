package com.hikvision.hae.common.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.hikvision.hae.common.constant.CommonResultCode;

import java.io.Serializable;

/**
 * Rest接口公共返回类型
 *
 * @param <T>
 * @author zhanjiejun
 */
public class AjaxResult<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private int resultCode;

	private String message;

	private String detailMessage;

	private T data;

	@JSONField(serialize = false)
	private Object[] messageParam;

	public AjaxResult() {
	}

	public AjaxResult(int resultCode) {
		this.resultCode = resultCode;
	}

	public AjaxResult(int resultCode, String message) {
		this.resultCode = resultCode;
		this.message = message;
	}

	public AjaxResult(int resultCode, T data) {
		this.resultCode = resultCode;
		this.data = data;
	}

	public AjaxResult(int resultCode, T data, Object[] messageParam) {
		this.resultCode = resultCode;
		this.data = data;
		this.messageParam = messageParam;
	}

	public int getResultCode() {
		return resultCode;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Object[] getMessageParam() {
		return messageParam;
	}

	public void setMessageParam(Object[] messageParam) {
		this.messageParam = messageParam;
	}

	public static <T> AjaxResult<T> build(int code) {
		AjaxResult<T> result = new AjaxResult<>();
		result.setResultCode(code);
		return result;
	}

	public static <T> AjaxResult<T> buildSuccess() {
		AjaxResult<T> result = new AjaxResult<>();
		result.setResultCode(CommonResultCode.SUCCESS);
		return result;
	}

	public static <T> AjaxResult<T> buildFail() {
		AjaxResult<T> result = new AjaxResult<>();
		result.setResultCode(CommonResultCode.FAIL);
		return result;
	}

}
