package com.hikvision.hae.common.constant;

/**
 * 公共ResultCode常量定义
 *
 * @author zhanjiejun
 */
public class CommonResultCode {

	/**
	 * 成功
	 */
	public static final int SUCCESS = 10000;

	/**
	 * 失败
	 */
	public static final int FAIL = 10001;

	/**
	 * 非法参数
	 */
	public static final int ILLEGAL_ARGUMENT = 10002;

	/**
	 * 未登录或登录已过期
	 */
	public static final int USER_NOT_LOGIN = 10003;

	/**
	 * 未知异常
	 */
	public static final int UNKNOW_ERROR = 10004;

	/**
	 * 系统异常，请联系运维人员
	 */
	public static final int SYSTEM_ERROR = 10005;

	/**
	 * 无权限
	 */
	public static final int UNAUTHORIZATION_ERROR = 10006;

	/**
	 * 文件上传失败
	 */
	public static final int FILE_UPLOAD_FAIL = 10007;

	/**
	 * 上传文件大小超出系统限制（{0}）
	 */
	public static final int FILE_EXCEEDS_LIMIT = 10008;

    /**
     * URL格式错误
     */
    public static final int MALFORMED_URL_ERROR = 10009;

    /**
     * 服务端异常
     */
    public static final int K8S_SERVER_RESPONSE_ERROR = 10010;

	/**
	 * 非法的事件资源类型
	 */
	public static final int INVALID_RESTYPE_FOR_EVENT = 10011;

	/**
	 * 不合法的枚举字符串
	 */
	public static final int INVALID_ENUM_STRING = 10012;

    /**
     * 异步任务执行失败
     */
	public static final int AYSNC_TASK_EXECUTE_FAIL = 10013;

    /**
     * YAML文本格式错误
     */
    public static final int INVALID_YAML_TEXT = 10014;

    /**
     * JSON文本格式错误
     */
    public static final int INVALID_JSON_TEXT = 10015;

	/**
	 * 镜像管理功能不支持
	 */
	public static final int IMAGE_MANAGE_NOT_SUPPORTED = 10016;

	/**
	 * 文件流解析异常
	 */
	public static final int FILE_UPSTREAM_RESOLVE_FAIL = 10017;

}
