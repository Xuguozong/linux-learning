package com.hikvision.hae.common.util.encrypt;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.Map;

/**
 * RSA相关工具类
 *
 * @author shixiafeng
 */
public class RSAUtils {

	public static String PUBLIC_KEY_BASE64 = "";
	public static String PRIVATE_KEY_BASE64 = "";

	static {
		Map<String, byte[]> keyMap = RSA.generateKeyBytes();
		PUBLIC_KEY_BASE64 = Base64.getEncoder().encodeToString(keyMap.get(RSA.PUBLIC_KEY));
		PRIVATE_KEY_BASE64 = Base64.getEncoder().encodeToString(keyMap.get(RSA.PRIVATE_KEY));
	}

	public static String getPublicKey() {
		return PUBLIC_KEY_BASE64;
	}

	/**
	 * 加密
	 *
	 * @param plainText 明文
	 * @return
	 */
	public static String encode(String plainText) {
		PublicKey publicKey;
		String encode = null;
		publicKey = RSA.restorePublicKey(Base64.getDecoder().decode(PUBLIC_KEY_BASE64));
		byte[] encodedText = RSA.encode(publicKey, plainText.getBytes());
		encode = Base64.getEncoder().encodeToString(encodedText);
		return encode;
	}

	/**
	 * 解密
	 *
	 * @param encodedText 密文
	 * @return
	 */
	public static String decode(String encodedText) {
		String decoded = null;
		PrivateKey privateKey = RSA.restorePrivateKey(Base64.getDecoder().decode(PRIVATE_KEY_BASE64));
		decoded = RSA.decode(privateKey, Base64.getDecoder().decode(encodedText));
		return decoded;
	}

}
