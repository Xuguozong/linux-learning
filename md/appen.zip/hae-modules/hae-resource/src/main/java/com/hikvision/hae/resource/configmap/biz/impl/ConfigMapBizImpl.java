package com.hikvision.hae.resource.configmap.biz.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.configmap.biz.ConfigMapBiz;
import io.fabric8.kubernetes.api.model.ConfigMap;
import io.fabric8.kubernetes.api.model.ConfigMapList;
import io.fabric8.kubernetes.api.model.DoneableConfigMap;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
@Service
public class ConfigMapBizImpl
        extends KubeMixedOperation<ConfigMap, ConfigMapList, DoneableConfigMap, Resource<ConfigMap, DoneableConfigMap>>
        implements ConfigMapBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.ConfigMap, this);
    }

    @Override
    public MixedOperation<ConfigMap, ConfigMapList, DoneableConfigMap, Resource<ConfigMap, DoneableConfigMap>> getKubeOperation() {
        return kubeClient.configMaps();
    }
}
