package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.ClusterRole;

import java.util.List;

/**
 * RBAC ClusterRole 操作
 *
 * @author jianghaiyang5 on 2017/12/21.
 */
public interface ClusterRoleBiz {

    /**
     * 查询满足条件的所有 RbacClusterRole
     *
     * @param filterQuery 查询条件
     * @return RbacClusterRole 对象列表
     */
    List<ClusterRole> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有 RbacClusterRole
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return RbacClusterRole 对象列表
     */
    Pagination<ClusterRole> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定name的 RbacClusterRole
     *
     * @param name RbacClusterRole 的名称
     * @return null或者 RbacClusterRole 对象
     */
    ClusterRole getByName(String name);

    /**
     * 删除指定namespace和name的 RbacClusterRole
     *
     * @param name RbacClusterRole 的名称
     */
    void delete(String name);
}
