package com.hikvision.hae.resource.service.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.enums.ServiceType;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.service.biz.ServiceBiz;
import com.hikvision.hae.resource.service.dto.EndpointDTO;
import io.fabric8.kubernetes.api.model.DoneableService;
import io.fabric8.kubernetes.api.model.LoadBalancerIngress;
import io.fabric8.kubernetes.api.model.Service;
import io.fabric8.kubernetes.api.model.ServiceList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/10.
 */
@org.springframework.stereotype.Service
public class ServiceBizImpl
        extends KubeMixedOperation<Service, ServiceList, DoneableService, Resource<Service, DoneableService>>
        implements ServiceBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Service, this);
    }

    @Override
    public Pagination<Service> findAndPage(FilterQuery filterQuery, Map<String, String> postResourceSelector, PageParam pageParam) {
        List<Service> items = super.find(filterQuery);
        if (items.isEmpty()) {
            return Pagination.build(pageParam);
        }
        if (postResourceSelector != null) {
            items = items.stream().filter(item -> {
                Set<Map.Entry<String, String>> svcSelectors = item.getSpec().getSelector().entrySet();
                for (Map.Entry<String, String> svcSelector : svcSelectors) {
                    String prsVal = postResourceSelector.get(svcSelector.getKey());
                    if (prsVal == null || !Objects.equals(svcSelector.getValue(), prsVal)) {
                        return false;
                    }
                }
                return true;
            }).collect(Collectors.toList());
        }
        Comparator<Service> comparator = Comparator.comparing((Service t) -> t.getMetadata().getName());
        return DataSelector.paginate(items, comparator, pageParam);
    }

    @Override
    public EndpointDTO getInternalEndpoint(Service service) {
        String name = service.getMetadata().getName();
        String namespace = service.getMetadata().getNamespace();

        if (!Objects.equals(ResourceConstants.DEFAULT_NAMESPACE, namespace) && namespace.length() > 0 && name.length() > 0) {
            StringBuilder buf = new StringBuilder(name);
            buf.append(".").append(namespace);
            name = buf.toString();
        }

        return new EndpointDTO(name, service.getSpec().getPorts());
    }

    @Override
    public List<EndpointDTO> getExternalEndpoint(Service service) {
        List<EndpointDTO> endpointList = new ArrayList<>();
        ServiceType svcType = ServiceType.parse(service.getSpec().getType());
        if (svcType == null) {
            return endpointList;
        }

        if (svcType == ServiceType.LOAD_BALANCER) {
            List<LoadBalancerIngress> ingresses = service.getStatus().getLoadBalancer().getIngress();
            ingresses.forEach(ingress -> {
                String host = StringUtils.hasText(ingress.getHostname()) ? ingress.getHostname() : ingress.getIp();
                endpointList.add(new EndpointDTO(host, service.getSpec().getPorts()));
            });
        }

        List<String> externalIPList = service.getSpec().getExternalIPs();
        externalIPList.forEach(externalIP -> endpointList.add(new EndpointDTO(externalIP, service.getSpec().getPorts())));

        return endpointList;
    }

    @Override
    public MixedOperation<Service, ServiceList, DoneableService, Resource<Service, DoneableService>> getKubeOperation() {
        return kubeClient.services();
    }
}
