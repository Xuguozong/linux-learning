package com.hikvision.hae.resource.event.biz;

import java.util.List;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.Event;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public interface EventBiz {

    /**
     * 分页查询指定Namespace下指定Deployment的所有事件
     *
     * @param namespace    命名空间
     * @param resourceName 资源名称
     * @param kind         资源类别
     * @param pageParam    分页参数
     * @return 事件列表
     */
    Pagination<Event> findAndPage(String namespace, ResourceKind kind, String resourceName, PageParam pageParam);
    
    /**
     * 查询指定Namespace下指定条件的所有事件
     *
     * @param namespace    命名空间
     * @param kind         关联资源类别
     * @param resourceName 关联资源名称
     * @param uid          关联资源ID
     * @param type         事件类型
     * @return 事件列表
     */
    List<Event> find(String namespace, ResourceKind kind, String resourceName, String uid, String type);
}
