package com.hikvision.hae.resource.node.dto;

/**
 * Created by zhanjiejun on 2017/11/18.
 */
public class NodeDTO {

	private NodeBaseDTO nodeBaseDTO;

	private NodeResourceDTO nodeResourceDTO;

	public NodeBaseDTO getNodeBaseDTO() {
		return nodeBaseDTO;
	}

	public void setNodeBaseDTO(NodeBaseDTO nodeBaseDTO) {
		this.nodeBaseDTO = nodeBaseDTO;
	}

	public NodeResourceDTO getNodeResourceDTO() {
		return nodeResourceDTO;
	}

	public void setNodeResourceDTO(NodeResourceDTO nodeResourceDTO) {
		this.nodeResourceDTO = nodeResourceDTO;
	}
}
