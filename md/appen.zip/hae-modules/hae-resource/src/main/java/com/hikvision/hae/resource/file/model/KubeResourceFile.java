package com.hikvision.hae.resource.file.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;

import javax.persistence.*;
import java.util.Date;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
@Entity
@Table(name = "kube_resource_file")
@Comment("K8S资源文件表")
public class KubeResourceFile extends DataObject {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "group_id")
    private int groupId;

    @Column(name = "file_name", nullable = false, length = 64)
    private String fileName;

    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    public enum Field implements jef.database.Field {
        id, groupId, fileName, content, createTime
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
