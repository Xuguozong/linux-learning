package com.hikvision.hae.resource.common.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;

/**
 * @author jianghaiyang5 on 2017/11/8.
 */
public enum ResourceKind {
    ConfigMap("CONFIG_MAP"),
    DaemonSet("DAEMON_SET"),
    Deployment("DEPLOYMENT"),
    Event("EVENT"),
    HorizontalPodAutoscaler("HORIZONTAL_POD_AUTOSCALER"),
    Ingress("INGRESS"),
    Job("JOB"),
    LimitRange("LIMIT_RANGE"),
    Namespace("NAMESPACE"),
    Node("NODE"),
    PersistentVolumeClaim("PERSISTENT_VOLUME_CLAIM"),
    PersistentVolume("PERSISTENT_VOLUME"),
    Pod("POD"),
    ReplicaSet("REPLICA_SET"),
    ReplicationController("REPLICATION_CONTROLLER"),
    ResourceQuota("RESOURCE_QUOTA"),
    Secret("SECRET"),
    ServiceAccount("SERVICE_ACCOUNT"),
    Service("SERVICE"),
    StatefulSet("STATEFUL_SET"),
    StorageClass("STORAGE_CLASS"),
    ThirdPartyResource("THIRD_PARTY_RESOURCE"),
    Role("ROLE"),
    ClusterRole("CLUSTER_ROLE"),
    RoleBinding("ROLE_BINDING"),
    ClusterRoleBinding("CLUSTER_ROLE_BINDING");

    private static final Logger logger = LoggerFactory.getLogger(ResourceKind.class);

    private String code;

    ResourceKind(String code) {
        this.code = code;
    }

    public static ResourceKind parse(String name) {
        ResourceKind resourceKind = Stream.of(ResourceKind.values()).filter(c -> c.name().equalsIgnoreCase(name)).findFirst().orElse(null);
        if (resourceKind == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型ResourceKind失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return resourceKind;
    }

    public String getCode() {
        return code;
    }
}
