package com.hikvision.hae.resource.pod.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import io.fabric8.kubernetes.api.model.LabelSelector;
import io.fabric8.kubernetes.api.model.Pod;

import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
public interface PodBiz {

    /**
     * 查询满足条件的所有Pod
     *
     * @param filterQuery 查询条件
     * @return Pod对象列表
     */
    List<Pod> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有Pod
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return Pod对象列表
     */
    Pagination<Pod> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的Pod
     *
     * @param namespace Pod所在的namespace
     * @param name      Pod的名称
     * @return null或者Pod对象
     */
    Pod getByName(String namespace, String name);

    /**
     * 查询符合标签选择器的Pod的汇总信息
     *
     * @param mapSelector 标签选择器
     * @param namespace   命名空间
     * @param currentPods 当前Pod数量
     * @param desiredPods 目标Pod数量
     * @return Pod汇总信息
     */
    PodInfo getPodInfo(Map<String, String> mapSelector, String namespace, Integer currentPods, Integer desiredPods, String ownerUid);

    /**
     * 查询符合标签选择器的Pod的汇总信息
     *
     * @param labelSelector 标签选择器
     * @param namespace     命名空间
     * @param currentPods   当前Pod数量
     * @param desiredPods   目标Pod数量
     * @return Pod汇总信息
     */
    PodInfo getPodInfo(LabelSelector labelSelector, String namespace, Integer currentPods, Integer desiredPods, String ownerUid);

    /**
     * 删除指定namespace和name的Pod
     *
     * @param namespace Pod所在的namespace
     * @param name      Pod的名称
     */
    void delete(String namespace, String name);
}
