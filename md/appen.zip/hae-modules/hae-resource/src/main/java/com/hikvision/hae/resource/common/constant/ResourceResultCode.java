package com.hikvision.hae.resource.common.constant;

/**
 * Resource错误码
 * 节点 12000~12099
 * 命名空间 12100~12199
 * 资源文件 12200~12299
 * K8S资源 12300~12399
 * Created by zhanjiejun on 2017/11/7.
 */
public class ResourceResultCode {

    //***************节点 12000~12099****************

    /**
     * Ansible节点不存在
     */
    public static final int ANSIBLE_NODE_NOT_EXIST = 12000;

    /**
     * 缺少Ansible节点SSH信息
     */
    public static final int LACK_ANSIBLE_NODE_SSH_INFO = 12001;

    /**
     * Ansible节点SSH信息错误
     */
    public static final int WRONG_ANSIBLE_NODE_SSH_INFO = 12002;

    /**
     * SSH Ansible节点失败
     */
    public static final int SSH_ANSIBLE_NODE_FAIL = 12003;

    /**
     * 存在节点处于添加中或硬删除中
     */
    public static final int NODE_BUILDING_OR_HARD_DELETING_EXIST = 12004;

    /**
     * 节点信息写入数据库失败
     */
    public static final int WRITE_NODE_INFO_TO_DB_FAIL = 12005;

    /**
     * 节点软删除失败
     */
    public static final int SOFT_DELETE_NODE_FAIL = 12006;

    /**
     * 节点不存在
     */
    public static final int NODE_NOT_EXIST = 12007;

    /**
     * 节点状态不正确
     */
    public static final int WRONG_NODE_STATUS = 12008;

    /**
     * 节点名称已存在
     */
    public static final int NODE_NAME_ALREADY_EXIST = 12009;

    /**
     * 缺少节点SSH信息
     */
    public static final int LACK_NODE_SSH_INFO = 12010;

    /**
     * 节点IP已存在
     */
    public static final int NODE_IP_ALREADY_EXIST = 12011;

    /**
     * 同步节点列表数据失败
     */
    public static final int SYNC_NODE_LIST_FAILED = 12012;

    //***************命名空间 12100~12199****************
    /**
     * 命名空间不存在
     */
    public static final int NAMESPACE_NOT_EXIST = 12100;

    /**
     * 命名空间配额低于资源已使用值
     */
    public static final int NAMESPACE_QUOTA_LESS_THAN_USED = 12101;

    /**
     * 命名空间已存在
     */
    public static final int NAMESPACE_ALREADY_EXIST = 12102;

    //-------上：命名空间； 下：k8s资源文件 12200~12299
    /**
     * 资源文件不存在
     */
    public static final int RESOURCE_FILE_NOT_EXIST = 12200;
    /**
     * 资源上传失败
     */
    public static final int RESOURCE_FILE_UPLOAD_FAIL = 12201;
    /**
     * 文件流解析异常
     */
    public static final int RESOURCE_FILE_UPSTREAM_RESOLVE_FAIL = 12202;
    /**
     * 不支持的文件格式
     */
    public static final int RESOURCE_FILE_FORMAT_ILLEGAL = 12203;
    /**
     * 资源文档内容错误
     */
    public static final int MALFORMED_KUBE_DOCUMENT = 12204;
    /**
     * 资源分组名称已存在
     */
    public static final int RESOURCE_FILE_GROUP_NAME_ALREADY_EXIST = 12205;

    //-------上：资源管理； 下：k8s资源 12300 ~ 12399
    /**
     * 请求的资源不存在
     */
    public static final int REQUEST_RESOURCE_NOT_EXIST = 12300;

    /**
     * Deployment不存在
     */
    public static final int DEPLOYMENT_NOT_EXIST = 12301;
    /**
     * ReplicaSet不存在
     */
    public static final int REPLICASET_NOT_EXIST = 12302;

    /**
     * ReplicationController不存在
     */
    public static final int REPLICATION_CONTROLLER_NOT_EXIST = 12303;

    /**
     * Service不存在
     */
    public static final int SERVICE_NOT_EXIST = 12304;

    /**
     * Pod不存在
     */
    public static final int POD_NOT_EXIST = 12305;

    /**
     * StatefulSet不存在
     */
    public static final int STATEFULSET_NOT_EXIST = 12306;

    /**
     * Job不存在
     */
    public static final int JOB_NOT_EXIST = 12307;

    /**
     * DaemonSet不存在
     */
    public static final int DAEMONSET_NOT_EXIST = 12308;

    /**
     * Secret不存在
     */
    public static final int SECRET_NOT_EXIST = 12309;

    /**
     * ConfigMap不存在
     */
    public static final int CONFIGMAP_NOT_EXIST = 12310;

    /**
     * Persistentvolume不存在
     */
    public static final int PERSISTENTVOLUME_NOT_EXIST = 12311;
    /**
     * PersistentvolumeClaim不存在
     */
    public static final int PERSISTENTVOLUMECLAIM_NOT_EXIST = 12312;

    /**
     * Ingress不存在
     */
    public static final int INGRESS_NOT_EXIST = 12313;

    /**
     * 无效的Pod关联方
     */
    public static final int INVALID_POD_OWNER = 12314;

    /**
     * 无效的Service关联方
     */
    public static final int INVALID_SERVICE_OWNER = 12315;
    
    /**
     * ServiceAccount不存在
     */
    public static final int SERVICE_ACCOUNT_NOT_EXIST = 12316;

    /**
     * ResourceQuota不存在
     */
    public static final int RESOURCE_QUOTA_NOT_EXIST = 12317;

    /**
     * LimitRange不存在
     */
    public static final int LIMIT_RANGE_NOT_EXIST = 12318;

    /**
     * 请至少上传一个文件
     */
    public static final int AT_LEAST_ONE_FILE_FOR_CONFIGMAP_NEED = 12319;

    public static final int CONTAINER_NOT_EXIST = 12320;

}
