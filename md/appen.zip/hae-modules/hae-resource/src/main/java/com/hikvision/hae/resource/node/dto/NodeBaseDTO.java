package com.hikvision.hae.resource.node.dto;

import com.hikvision.hae.common.util.encrypt.AESUtils;
import com.hikvision.hae.resource.common.constant.ResourceConstants;
import com.hikvision.hae.resource.node.model.Node;
import com.hikvision.hae.resource.node.model.NodeStatus;
import io.fabric8.kubernetes.api.model.Quantity;

import java.util.Date;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/2.
 */
public class NodeBaseDTO {

	private int id;

	private String k8sName;

	private String name;

	private String ip;

	private NodeStatus status;

	private String sshPwd;

	private Date createTime;

	private Map<String, String> labels;

	/**
	 * 节点实际可分配资源
	 */
	private Map<String, Quantity> allocatable;

	/**
	 * 节点规格
	 */
	private Map<String, Quantity> capacity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getK8sName() {
		return k8sName;
	}

	public void setK8sName(String k8sName) {
		this.k8sName = k8sName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getSshPwd() {
		return sshPwd;
	}

	public void setSshPwd(String sshPwd) {
		this.sshPwd = sshPwd;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Map<String, String> getLabels() {
		return labels;
	}

	public void setLabels(Map<String, String> labels) {
		this.labels = labels;
	}

	public Map<String, Quantity> getAllocatable() {
		return allocatable;
	}

	public void setAllocatable(Map<String, Quantity> allocatable) {
		this.allocatable = allocatable;
	}

	public Map<String, Quantity> getCapacity() {
		return capacity;
	}

	public void setCapacity(Map<String, Quantity> capacity) {
		this.capacity = capacity;
	}

	public NodeStatus getStatus() {
		return status;
	}

	public void setStatus(NodeStatus status) {
		this.status = status;
	}

	public static NodeBaseDTO fromNode(Node node) {
		if (node == null) {
			return null;
		}
		NodeBaseDTO nodeBaseDTO = new NodeBaseDTO();
		nodeBaseDTO.setId(node.getId());
		nodeBaseDTO.setIp(node.getIp());
		nodeBaseDTO.setName(node.getName());
		nodeBaseDTO.setCreateTime(node.getCreateTime());
		nodeBaseDTO.setK8sName(node.getK8sName());
		nodeBaseDTO.setStatus(node.getStatus());
		return nodeBaseDTO;
	}

	public Node toNodeForSave() {
		Node node = new Node();
		node.setName(this.name);
		node.setIp(this.ip);
		node.setCreateTime(new Date());
		node.setSshUser(ResourceConstants.DEFAULT_SSH_USER);
		node.setSshPwd(AESUtils.encrypt(this.sshPwd));
		return node;
	}

	public Node toNodeForUpdate() {
		Node node = new Node();
		node.setName(this.name);
		node.setSshPwd(AESUtils.encrypt(this.sshPwd));
		return node;
	}

}
