package com.hikvision.hae.resource.pod.biz.assist;

import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.common.enums.PodPhase;
import io.fabric8.kubernetes.api.model.ContainerStatus;
import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.kubernetes.api.model.PodCondition;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
public class PodHelper {

    /**
     * Pods状态汇总信息
     *
     * @param current 当前Pod数量
     * @param desired 期望的Pod数量
     * @param pods    Pod列表
     * @return Pods状态汇总信息
     */
    public static PodInfo getPodInfo(Integer current, Integer desired, List<Pod> pods) {
        PodInfo podInfo = new PodInfo(current, desired);
        pods.forEach(pod -> {
            PodPhase podPhase = PodPhase.parse(pod.getStatus().getPhase());
            if (podPhase == null) {
                return;
            }
            switch (podPhase) {
                case Running:
                    podInfo.setRunning((podInfo.getRunning() == null ? 0 : podInfo.getRunning()) + 1);
                    break;
                case Pending:
                    podInfo.setPending((podInfo.getPending() == null ? 0 : podInfo.getPending()) + 1);
                    break;
                case Failed:
                    podInfo.setFailed((podInfo.getFailed() == null ? 0 : podInfo.getFailed()) + 1);
                    break;
                case Succeeded:
                    podInfo.setSucceeded((podInfo.getSucceeded() == null ? 0 : podInfo.getSucceeded()) + 1);
                    break;
            }
        });
        return podInfo;
    }

    public static int getRestartCount(Pod pod) {
        List<ContainerStatus> containerStatuses = pod.getStatus().getContainerStatuses();
        int restartCount = 0;
        for (ContainerStatus cs : containerStatuses) {
            restartCount += cs.getRestartCount();
        }
        return restartCount;
    }
    
    /**
     * 判断Pod是否ready或者succeeded
     * @param pod
     * @return
     */
    public static boolean isReadyOrSucceeded(Pod pod){
    	
    	PodPhase podPhase = PodPhase.parse(pod.getStatus().getPhase());

    	if(PodPhase.Succeeded.equals(podPhase)){
    		return true;
    	}
    	
    	if(PodPhase.Running.equals(podPhase)){
    		for(PodCondition condition : pod.getStatus().getConditions()){
    			if("Ready".equals(condition.getType())){
    				if(!"True".equals(condition.getStatus())){
    					return false;
    				}
    			}
    		}
    		return true;
    	}
    	
    	return false;
    }
}
