package com.hikvision.hae.resource.file.dto;

import com.hikvision.hae.resource.file.model.KubeResourceFile;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public class ResourceFileDTO implements Serializable {
    private static final long serialVersionUID = 3906794004412819449L;

    private int id;

    private int groupId;

    private String fileName;

    private String content;

    private Date createTime;

    public ResourceFileDTO() {
    }

    public ResourceFileDTO(int groupId, String fileName, String content) {
        this.groupId = groupId;
        this.fileName = fileName;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public static ResourceFileDTO readFromModel(KubeResourceFile model) {
        ResourceFileDTO dto = new ResourceFileDTO();
        dto.setId(model.getId());
        dto.setGroupId(model.getGroupId());
        dto.setFileName(model.getFileName());
        dto.setContent(model.getContent());
        dto.setCreateTime(model.getCreateTime());
        return dto;
    }

    public KubeResourceFile convertToModel() {
        KubeResourceFile model = new KubeResourceFile();
        model.setId(this.getId());
        model.setGroupId(this.getGroupId());
        model.setFileName(this.getFileName());
        model.setContent(this.getContent());
        model.setCreateTime(this.getCreateTime());
        return model;
    }
}
