package com.hikvision.hae.resource.pod.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.common.enums.EventType;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.event.biz.EventBiz;
import com.hikvision.hae.resource.event.biz.assist.EventHelper;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import com.hikvision.hae.resource.pod.biz.assist.PodHelper;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.PodResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
@org.springframework.stereotype.Service
public class PodBizImpl
        extends KubeMixedOperation<Pod, PodList, DoneablePod, PodResource<Pod, DoneablePod>>
        implements PodBiz {
	
	@Autowired
	EventBiz eventBiz;

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Pod, this);
    }

    @Override
    public MixedOperation<Pod, PodList, DoneablePod, PodResource<Pod, DoneablePod>> getKubeOperation() {
        return kubeClient.pods();
    }

    @Override
    public Pagination<Pod> findAndPage(FilterQuery filterQuery, PageParam pageParam) {
        List<Pod> items = this.find(filterQuery);
        if (items.isEmpty()) {
            return Pagination.build(pageParam);
        }
        //按ownerUid过滤
        items = filterByOwnerUid(filterQuery.getOwnerUid(), items);
        Comparator<Pod> comparator = Comparator.comparing((Pod t) -> t.getMetadata().getName());
        return DataSelector.paginate(items, comparator, pageParam);
    }

    @Override
    public PodInfo getPodInfo(Map<String, String> mapSelector, String namespace, Integer currentPods, Integer desiredPods, String ownerUid) {
        LabelSelector labelSelector = new LabelSelectorBuilder().addToMatchLabels(mapSelector).build();
        return getPodInfo(labelSelector, namespace, currentPods, desiredPods, ownerUid);
    }

    @Override
    public PodInfo getPodInfo(LabelSelector labelSelector, String namespace, Integer currentPods, Integer desiredPods, String ownerUid) {
        FilterQuery filterQuery = FilterQuery.build().namespace(namespace).labelSelector(labelSelector);
        List<Pod> pods = super.find(filterQuery);
        List<Pod> matchedPods = filterByOwnerUid(ownerUid, pods);
        PodInfo result = PodHelper.getPodInfo(currentPods, desiredPods, matchedPods);
        // 设置警告消息
        List<Event> eventList = new ArrayList<>();
        for (Pod pod : matchedPods) {
        	
        	// 判断pod状态是否为running或succeeded以外
        	if(!PodHelper.isReadyOrSucceeded(pod)){
        		eventList.addAll(eventBiz.find(namespace, ResourceKind.Pod, pod.getMetadata().getName(), pod.getMetadata().getUid(), EventType.WARNING.getCode()));
        	}
		}
        List<String> warningMessages = new ArrayList<>();
        eventList = EventHelper.removeDuplicatesByReason(eventList); // 消息去重
        eventList.forEach(e -> warningMessages.add(e.getMessage()));
        result.setWarningMessages(warningMessages);
        
        return result;
    }

    private List<Pod> filterByOwnerUid(String ownerUid, List<Pod> pods) {
        if (!StringUtils.hasText(ownerUid)) {
            return pods;
        }

        List<Pod> matchedPods = new ArrayList<>();
        for (Pod pod : pods) {
            for (OwnerReference ref : pod.getMetadata().getOwnerReferences()) {
                if (ref.getController() != null && ref.getController() && ref.getUid().equals(ownerUid)) {
                    matchedPods.add(pod);
                    break;
                }
            }
        }
        return matchedPods;
    }
    

}
