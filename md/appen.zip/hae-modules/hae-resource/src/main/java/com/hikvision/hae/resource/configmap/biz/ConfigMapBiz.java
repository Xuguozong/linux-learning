package com.hikvision.hae.resource.configmap.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.Config;
import io.fabric8.kubernetes.api.model.ConfigMap;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public interface ConfigMapBiz {

	/**
	 * 查询满足条件的所有ConfigMap
	 *
	 * @param filterQuery 查询条件
	 * @return ConfigMap对象列表
	 */
	List<ConfigMap> find(FilterQuery filterQuery);

	/**
	 * 分页查询满足条件的所有ConfigMap
	 *
	 * @param filterQuery 查询条件
	 * @param pageParam   分页条件
	 * @return ConfigMap对象列表
	 */
	Pagination<ConfigMap> findAndPage(FilterQuery filterQuery, PageParam pageParam);

	/**
	 * 查询指定namespace和name的ConfigMap
	 *
	 * @param namespace ConfigMap所在的namespace
	 * @param name      ConfigMap的名称
	 * @return null或者ConfigMap对象
	 */
	ConfigMap getByName(String namespace, String name);

	/**
	 * 删除指定namespace和name的ConfigMap
	 *
	 * @param namespace ConfigMap所在的namespace
	 * @param name      ConfigMap的名称
	 */
	void delete(String namespace, String name);

	/**
	 * 创建ConfigMap
	 *
	 * @param configMap
	 */
	ConfigMap create(ConfigMap configMap);
}
