package com.hikvision.hae.resource.common.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;

/**
 * @author jianghaiyang5 on 2017/11/14.
 */
public enum ServiceType {

    // ServiceTypeClusterIP means a service will only be accessible inside the
    // cluster, via the cluster IP.
    CLUSTER_IP("ClusterIP"),

    // ServiceTypeNodePort means a service will be exposed on one port of
    // every node, in addition to 'ClusterIP' type.
    NODE_PORT("NodePort"),

    // ServiceTypeLoadBalancer means a service will be exposed via an
    // external load balancer (if the cloud provider supports it), in addition
    // to 'NodePort' type.
    LOAD_BALANCER("LoadBalancer"),

    // ServiceTypeExternalName means a service consists of only a reference to
    // an external name that kubedns or equivalent will return as a CNAME
    // record, with no exposing or proxying of any pods involved.
    EXTERNAL_NAME("ExternalName");

    private String code;

    private ServiceType(String code) {
        this.code = code;
    }

    private static final Logger logger = LoggerFactory.getLogger(ServiceType.class);

    public static ServiceType parse(String name) {
        ServiceType serviceType = Stream.of(ServiceType.values()).filter(c -> c.getCode().equalsIgnoreCase(name)).findFirst().orElse(null);
        if (serviceType == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型ServiceType失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return serviceType;
    }

    public String getCode() {
        return code;
    }
}
