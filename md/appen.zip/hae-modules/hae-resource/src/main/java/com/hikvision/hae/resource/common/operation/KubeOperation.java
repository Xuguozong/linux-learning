package com.hikvision.hae.resource.common.operation;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.HasMetadata;

import java.util.List;

/**
 * 定义K8S资源的常用操作.
 * T表示要操作的资源的类型
 *
 * @author jianghaiyang5 on 2017/11/9.
 */
public interface KubeOperation<T extends HasMetadata> {

    /**
     * 批量查询满足指定条件的所有资源
     *
     * @param filterQuery 查询条件
     * @return 资源的集合
     */
    List<T> find(FilterQuery filterQuery);

    /**
     * 分页查询满足指定条件的所有资源
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页参数
     * @return 资源的分页查询结果
     */
    Pagination<T> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 按命名空间和名称查询指定的资源
     *
     * @param namespace 命名空间，对无命名空间的资源可以为null
     * @param name      资源名称
     * @return 若指定的资源存在则返回资源对象实例，否则返回null
     */
    T getByName(String namespace, String name);

    /**
     * 新建资源对象
     *
     * @param t 待创建的资源对象
     * @return 创建后的资源对象
     */
    T create(T t);

    /**
     * 删除指定命名空间和名称的资源
     *
     * @param namespace 命名空间，对无命名空间的资源可以为null
     * @param name      资源名称
     */
    void delete(String namespace, String name);
}
