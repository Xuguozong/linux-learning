package com.hikvision.hae.resource.node.repo;

import com.github.geequery.springdata.annotation.IgnoreIf;
import com.github.geequery.springdata.annotation.ParamIs;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.resource.node.model.Node;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/2.
 */
public interface NodeRepo extends GqRepository<Node, Integer> {

	Node findByNameAndIdNot(String name, @IgnoreIf(ParamIs.ZeroOrNagative) int id);

	Node findByK8sName(String k8sName);

	Node findByIp(String ip);

	/**
	 * 分页查询（名字和IP一起做模糊查询）
	 *
	 * @param name
	 * @param ip
	 * @param pageable
	 * @return
	 * @comment name和ip都为空时，存在问题
	 */
	Page<Node> findByNameContainsOrIpContains(@IgnoreIf(ParamIs.Empty) String name, @IgnoreIf(ParamIs.Empty) String ip, Pageable pageable);

}
