package com.hikvision.hae.resource.replicaset.biz.assist;

import com.hikvision.hae.resource.common.constant.ResourceConstants;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
public class ReplicaSetHelper {

    public static ReplicaSet findNewReplicaSet(List<ReplicaSet> rsList) {
        ReplicaSet newReplicaSet = null;
        int revision = 0;
        for (ReplicaSet rs : rsList) {
            int _tmpRevision = Integer.parseInt(rs.getMetadata().getAnnotations().get(ResourceConstants.DEPLOYMENT_REVISION));
            if (_tmpRevision > revision) {
                revision = _tmpRevision;
                newReplicaSet = rs;
            }
        }
        return newReplicaSet;
    }

    public static List<ReplicaSet> findOldReplicaSets(List<ReplicaSet> rsList) {
        ReplicaSet newRS = findNewReplicaSet(rsList);
        if (newRS == null) {
            return null;
        }
        return rsList.stream().filter(rs -> !Objects.equals(rs.getMetadata().getUid(), newRS.getMetadata().getUid()))
                .collect(Collectors.toList());
    }
}
