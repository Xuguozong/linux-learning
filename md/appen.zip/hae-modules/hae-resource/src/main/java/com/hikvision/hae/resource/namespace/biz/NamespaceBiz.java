package com.hikvision.hae.resource.namespace.biz;

import com.hikvision.hae.resource.namespace.dto.NamespaceReadDTO;
import com.hikvision.hae.resource.namespace.dto.NamespaceWriteDTO;

import java.util.List;

/**
 * 命名空间Biz层
 * Created by zhanjiejun on 2017/11/9.
 */
public interface NamespaceBiz {

	List<NamespaceReadDTO> getNamespaces(boolean calculateQuota);

	NamespaceReadDTO modifyNamespaceQuota(NamespaceWriteDTO namespaceDTO);

	boolean isNameExist(String name);

	NamespaceReadDTO createNamespace(NamespaceWriteDTO namespaceWriteDTO);

	void deleteNamespaceByName(String name);

	NamespaceReadDTO getNamespaceByName(String name);

}
