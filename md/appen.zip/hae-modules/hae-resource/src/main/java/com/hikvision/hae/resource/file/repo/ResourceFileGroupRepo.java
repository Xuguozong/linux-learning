package com.hikvision.hae.resource.file.repo;

import com.github.geequery.springdata.annotation.IgnoreIf;
import com.github.geequery.springdata.annotation.Modifying;
import com.github.geequery.springdata.annotation.ParamIs;
import com.github.geequery.springdata.annotation.Query;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.resource.file.model.KubeResourceFileGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * @author jianghaiyang5 on 2017/11/17.
 */
public interface ResourceFileGroupRepo extends GqRepository<KubeResourceFileGroup, Integer> {
    /**
     * 按分组名分页模糊查询
     *
     * @param groupName 分组名
     * @param pageable  分页参数
     * @return 分组列表
     */
    Page<KubeResourceFileGroup> findByGroupNameContains(@IgnoreIf(ParamIs.Empty) String groupName, Pageable pageable);

    /**
     * 根据分组名称查询
     *
     * @Param groupName分组名
     */
    @Query("select * from kube_resource_file_group where group_name=?1")
    KubeResourceFileGroup findByGroupName(String groupName);

    /**
     * 更新分组名称
     *
     * @Param groupName分组名
     */
    @Modifying
    @Query("update kube_resource_file_group set group_name=?2 where id=?1")
    void updateGroup(int groupID, String groupName);
}
