/**
 * 
 */
package com.hikvision.hae.resource.serviceaccount.biz.impl;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Service;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.serviceaccount.biz.ServiceAccountBiz;

import io.fabric8.kubernetes.api.model.DoneableServiceAccount;
import io.fabric8.kubernetes.api.model.ServiceAccount;
import io.fabric8.kubernetes.api.model.ServiceAccountList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;

/**
 * @author qihongfei
 *
 */
@Service
public class ServiceAccountBizImpl extends KubeMixedOperation<ServiceAccount, ServiceAccountList, DoneableServiceAccount, Resource<ServiceAccount, DoneableServiceAccount>>implements ServiceAccountBiz {

	@Override
	@PostConstruct
	public void init() {
		KubeOperationFactory.register(ResourceKind.ServiceAccount, this);
	}

	@Override
	public MixedOperation<ServiceAccount, ServiceAccountList, DoneableServiceAccount, Resource<ServiceAccount, DoneableServiceAccount>> getKubeOperation() {
		return kubeClient.serviceAccounts();
	}

}
