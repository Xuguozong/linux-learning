package com.hikvision.hae.resource.common.rawresource;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.HasMetadata;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
public interface ResourceVerber {

    /**
     * 查询指定命名空间下的指定类型的所有资源
     *
     * @param kind      资源类型
     * @param namespace 命名空间
     * @return 资源列表
     */
    String getAllAsJsonString(ResourceKind kind, String namespace);

    /**
     * 查询指定的k8s资源，并以JSON字符串形式返回
     *
     * @param kind      资源类型
     * @param namespace 命名空间，可为null
     * @param name      名称
     * @return 资源对象的JSON格式字符串
     */
    String getOneAsJsonString(ResourceKind kind, String namespace, String name);

    /**
     * 用新的资源定义JSON更新资源
     *
     * @param kind         资源类型
     * @param namespace    命名空间，可为null
     * @param name         名称
     * @param resourceJson 资源的新JSON定义
     * @return 原生的http响应
     */
    String update(ResourceKind kind, String namespace, String name, String resourceJson);

    /**
     * @param kind      资源类型
     * @param namespace 命名空间，可为null
     * @param resourceJson  资源的JSON定义
     * @return 创建的资源
     */
    HasMetadata create(ResourceKind kind, String namespace, String resourceJson);

    /**
     * 删除指定的k8s资源
     *
     * @param kind      资源类型
     * @param namespace 命名空间，可为null
     * @param name      名称
     * @return 原生的http响应
     */
    String delete(ResourceKind kind, String namespace, String name);
}
