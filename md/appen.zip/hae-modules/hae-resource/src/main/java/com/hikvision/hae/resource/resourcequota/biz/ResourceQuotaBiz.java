package com.hikvision.hae.resource.resourcequota.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.ResourceQuota;
import java.util.List;

/**
 * @author by zhouzhigang6 on 2018/1/16.
 */
public interface ResourceQuotaBiz {
    /**
     * 查询满足条件的所有ResourceQuota
     *
     * @param filterQuery 查询条件
     * @return ResourceQuota对象列表
     */
    List<ResourceQuota> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有ResourceQuota
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return ResourceQuota对象列表
     */
    Pagination<ResourceQuota> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的ResourceQuota
     *
     * @param namespace ResourceQuota所在的namespace
     * @param name      ResourceQuota的名称
     * @return null或者ResourceQuota对象
     */
    ResourceQuota getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的ResourceQuota
     *
     * @param namespace ResourceQuota所在的namespace
     * @param name      ResourceQuota的名称
     */
    void delete(String namespace, String name);
}
