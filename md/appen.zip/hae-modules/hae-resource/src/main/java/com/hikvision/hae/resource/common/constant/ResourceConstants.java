package com.hikvision.hae.resource.common.constant;

/**
 * K8S资源相关的常量
 *
 * Created by zhanjiejun on 2017/11/7.
 */
public class ResourceConstants {
	/**
	 * 默认SSH用户名
	 */
	public static final String DEFAULT_SSH_USER = "root";

	/**
	 * 默认SSH密码
	 */
	public static final String DEFAULT_SSH_PWD = "123456";

    /**
     * Deployment的版本信息，位于metadata/annotations中
     */
    public static final String DEPLOYMENT_REVISION = "deployment.kubernetes.io/revision";

    /**
     * 定义事件关联的资源：关联kind字段
     */
    public static final String EVENT_INVOLVED_KIND_FIELD = "involvedObject.kind";
    /**
     * 定义事件关联的资源：关联name字段
     */
    public static final String EVENT_INVOLVED_NAME_FIELD = "involvedObject.name";
    
    /**
     * 定义事件关联的资源：关联uid字段
     */
    public static final String EVENT_INVOLVED_UID_FIELD = "involvedObject.uid";
    
    /**
     * 定义事件的类型：关联type字段
     */
    public static final String EVENT_TYPE_FIELD = "type";
    
    /**
     * 默认的命名空间
     */
    public static final String DEFAULT_NAMESPACE = "default";
    /**
     * Pod创建者信息
     */
    public static final String CREATED_BY_ANNOTATION = "kubernetes.io/created-by";

    //================K8S 默认命名空间===============
    public static final String DEFAULT_NAMESPACE_KUBE_SYSTEM = "kube-system";

	public static final String DEFAULT_NAMESPACE_KUBE_PUBLIC = "kube-public";

	public static final String DEFAULT_NAMESPACE_DEFAULT = "default";

	/**
	 * 节点名称前缀，添加时HAE会拼接4位随机字符串，Ansible会追加拼接".hikcloud"
	 */
	public static final String K8S_NODE_NAME_PREFIX = "node.";

	public static final String K8S_NODE_NAME_SUFFIX = ".hikcloud";

	/**
	 * 添加节点shell脚本文件名
	 */
	public static final String DEFAULT_ADD_NODE_SHELL_FILENAME = "add-node.sh";

	/**
	 * 删除节点shell脚本文件名
	 */
	public static final String DEFAULT_DELETE_NODE_SHELL_FILENAME = "delete-node.sh";

}
