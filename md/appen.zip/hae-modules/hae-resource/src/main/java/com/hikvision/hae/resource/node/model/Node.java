package com.hikvision.hae.resource.node.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;
import jef.database.annotation.Type;
import jef.database.dialect.extension.ObjectJsonMapping;

import javax.persistence.*;
import java.util.Date;
import java.util.Map;

@Entity
@Table(name = "node")
@Comment("节点")
public class Node extends DataObject {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private int id;

	@Column(unique = true)
	private String name;

	@Column(name = "k8s_name", unique = true)
	private String k8sName;

	@Column(unique = true)
	private String ip;

	@Enumerated(EnumType.STRING)
	private NodeStatus status;

	@Column(name = "ssh_user")
	private String sshUser;

	@Column(name = "ssh_pwd")
	private String sshPwd;

	@Column(name = "create_time")
	private Date createTime;

	@Lob
	@Column(name = "extend_data", columnDefinition = "text")
	@Type(ObjectJsonMapping.class)
	private Map<String, Object> extendData;

	public enum Field implements jef.database.Field {
		id, name, k8sName, ip, status, sshUser, sshPwd, createTime, extendData
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getK8sName() {
		return k8sName;
	}

	public void setK8sName(String k8sName) {
		this.k8sName = k8sName;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public NodeStatus getStatus() {
		return status;
	}

	public void setStatus(NodeStatus status) {
		this.status = status;
	}

	public String getSshUser() {
		return sshUser;
	}

	public void setSshUser(String sshUser) {
		this.sshUser = sshUser;
	}

	public String getSshPwd() {
		return sshPwd;
	}

	public void setSshPwd(String sshPwd) {
		this.sshPwd = sshPwd;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Map<String, Object> getExtendData() {
		return extendData;
	}

	public void setExtendData(Map<String, Object> extendData) {
		this.extendData = extendData;
	}
}
