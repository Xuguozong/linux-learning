package com.hikvision.hae.resource.job.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.job.JobBiz;
import io.fabric8.kubernetes.api.model.DoneableJob;
import io.fabric8.kubernetes.api.model.Job;
import io.fabric8.kubernetes.api.model.JobList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.ScalableResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
@Service
public class JobBizImpl
        extends KubeMixedOperation<Job, JobList, DoneableJob, ScalableResource<Job, DoneableJob>>
        implements JobBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.Job, this);
    }

    @Override
    public MixedOperation<Job, JobList, DoneableJob, ScalableResource<Job, DoneableJob>> getKubeOperation() {
        return kubeClient.extensions().jobs();
    }
}
