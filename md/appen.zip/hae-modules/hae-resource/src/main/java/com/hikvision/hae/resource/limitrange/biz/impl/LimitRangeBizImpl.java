package com.hikvision.hae.resource.limitrange.biz.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.limitrange.biz.LimitRangeBiz;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author by zhouzhigang6 on 2018/1/22.
 */
@Service
public class LimitRangeBizImpl
        extends KubeMixedOperation<LimitRange, LimitRangeList, DoneableLimitRange, Resource<LimitRange, DoneableLimitRange>>
        implements LimitRangeBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.LimitRange, this);
    }

    @Override
    public MixedOperation<LimitRange, LimitRangeList, DoneableLimitRange, Resource<LimitRange, DoneableLimitRange>> getKubeOperation() {
        return kubeClient.limitRanges();
    }
}
