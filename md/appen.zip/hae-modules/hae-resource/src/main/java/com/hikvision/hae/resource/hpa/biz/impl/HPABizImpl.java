package com.hikvision.hae.resource.hpa.biz.impl;

import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.hpa.biz.HPABiz;
import io.fabric8.kubernetes.api.model.DoneableHorizontalPodAutoscaler;
import io.fabric8.kubernetes.api.model.HorizontalPodAutoscaler;
import io.fabric8.kubernetes.api.model.HorizontalPodAutoscalerList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/6.
 */
@Service
public class HPABizImpl
        extends KubeMixedOperation<HorizontalPodAutoscaler, HorizontalPodAutoscalerList, DoneableHorizontalPodAutoscaler, Resource<HorizontalPodAutoscaler,
                        DoneableHorizontalPodAutoscaler>>
        implements HPABiz {

    @Override
    @PostConstruct
    public void init(){
        KubeOperationFactory.register(ResourceKind.HorizontalPodAutoscaler, this);
    }

    @Override
    public MixedOperation<HorizontalPodAutoscaler, HorizontalPodAutoscalerList, DoneableHorizontalPodAutoscaler,
            Resource<HorizontalPodAutoscaler, DoneableHorizontalPodAutoscaler>> getKubeOperation() {
        return kubeClient.autoscaling().horizontalPodAutoscalers();
    }

    @Override
    public List<HorizontalPodAutoscaler> find(String namespace, ResourceKind targetKind, String targetName) {
        FilterQuery filterQuery = FilterQuery.build().namespace(namespace);
        return super.find(filterQuery).stream()
                .filter(hpa -> Objects.equals(hpa.getSpec().getScaleTargetRef().getKind(), targetKind.name())
                        && Objects.equals(hpa.getSpec().getScaleTargetRef().getName(), targetName))
                .collect(Collectors.toList());
    }
}
