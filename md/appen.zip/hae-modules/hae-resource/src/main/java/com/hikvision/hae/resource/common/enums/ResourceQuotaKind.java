package com.hikvision.hae.resource.common.enums;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
public enum ResourceQuotaKind {

	CPU("cpu", ""),

	MEMORY("memory", "Gi"),

	GPU("alpha.kubernetes.io/nvidia-gpu", ""),

	STORAGE("storage", "Gi");

	private String key;

	private String unit;

	ResourceQuotaKind(String key, String unit) {
		this.key = key;
		this.unit = unit;
	}

	public String getKey() {
		return key;
	}

	public String getUnit() {
		return unit;
	}
}
