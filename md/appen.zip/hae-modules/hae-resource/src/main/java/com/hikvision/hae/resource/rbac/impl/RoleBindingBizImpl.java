package com.hikvision.hae.resource.rbac.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.operation.KubeRawHttpOperation;
import com.hikvision.hae.resource.rbac.RoleBindingBiz;
import io.fabric8.openshift.api.model.RoleBinding;
import io.fabric8.openshift.api.model.RoleBindingList;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/12/21.
 */
@Service
public class RoleBindingBizImpl extends KubeRawHttpOperation<RoleBinding, RoleBindingList> implements RoleBindingBiz {

    @PostConstruct
    @Override
    public void init() {
        KubeOperationFactory.register(ResourceKind.RoleBinding, this);
    }

    @Override
    protected ResourceKind getResourceKindType() {
        return ResourceKind.RoleBinding;
    }

    @Override
    protected Class<RoleBinding> getResourceType() {
        return RoleBinding.class;
    }

    @Override
    protected Class<RoleBindingList> getResourceListType() {
        return RoleBindingList.class;
    }

}
