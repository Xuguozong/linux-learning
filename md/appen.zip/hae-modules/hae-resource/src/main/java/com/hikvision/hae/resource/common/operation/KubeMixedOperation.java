package com.hikvision.hae.resource.common.operation;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.common.util.DataSelector;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.api.model.KubernetesResourceList;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.NonNamespaceOperation;
import io.fabric8.kubernetes.client.dsl.Resource;
import org.springframework.util.StringUtils;

import java.util.Comparator;
import java.util.List;


/**
 * 基于fabirc8 MixedOperation的公共操作抽象
 *
 * @param <T> The Kubernetes resource type.
 * @param <L> The list variant of the Kubernetes resource type.
 * @param <D> The doneable variant of the Kubernetes resource type.
 * @param <R> The resource operations.
 * @author jianghaiyang5 on 2017/11/3.
 */
public abstract class KubeMixedOperation<T extends HasMetadata,
        L extends KubernetesResourceList, D, R extends Resource<T, D>> implements KubeOperation<T> {

    @javax.annotation.Resource
    protected KubernetesClient kubeClient;

    /**
     * 强制子类实现此方法，用于定义如向{@code KubeOperationFactory}注册实例等初始化操作
     */
    public abstract void init();

    /**
     * 查询满足条件的所有k8s资源
     *
     * @param filterQuery 查询条件
     * @return k8s资源列表对象
     */
    @SuppressWarnings("unchecked")
    public List<T> find(FilterQuery filterQuery) {
        NonNamespaceOperation<T, L, D, R> operation = getKubeOperation().inNamespace(filterQuery.getNamespace());
        if (!filterQuery.getLabelKeys().isEmpty()) {
            filterQuery.getLabelKeys().forEach(operation::withLabel);
        }
        if (!filterQuery.getLabels().isEmpty()) {
            filterQuery.getLabels().forEach(operation::withLabel);
        }
        if (filterQuery.getLabelSelector() != null) {
            operation.withLabelSelector(filterQuery.getLabelSelector());
        }
        if (!filterQuery.getFields().isEmpty()) {
            operation.withFields(filterQuery.getFields());
        }
        L resourceList = operation.list();
        //按名称过滤
        String resourceName = filterQuery.getName();
        if (StringUtils.hasText(resourceName)) {
            List<T> items = resourceList.getItems();
            for (int i = items.size() - 1; i >= 0; i--) {
                if (!items.get(i).getMetadata().getName().contains(resourceName)) {
                    items.remove(i);
                }
            }
        }
        return resourceList.getItems();
    }

    /**
     * 分页查询满足条件的所有k8s资源
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return k8s资源列表对象
     */
    public Pagination<T> findAndPage(FilterQuery filterQuery, PageParam pageParam) {
        List<T> items = this.find(filterQuery);
        if (items.isEmpty()) {
            return Pagination.build(pageParam);
        }
        Comparator<T> comparator = Comparator.comparing((T t) -> t.getMetadata().getName());
        return DataSelector.paginate(items, comparator, pageParam);
    }

    /**
     * 根据命名空间下的指定名称<T>类型的k8s资源
     *
     * @param namespace 命名空间
     * @param name      资源名称
     * @return k8s资源对象
     */
    public T getByName(String namespace, String name) {
        NonNamespaceOperation<T, L, D, R> operation = getKubeOperation().inNamespace(namespace);
        return operation.withName(name).get();
    }

    /**
     * 创建资源
     *
     * @param t 待建的资源对象
     * @return 创建后的资源对象
     */
    @SuppressWarnings("unchecked")
    public T create(T t) {
        NonNamespaceOperation<T, L, D, R> operation = getKubeOperation().inNamespace(t.getMetadata().getNamespace());
        return operation.create(t);
    }

    /**
     * 删除k8s资源
     *
     * @param namespace 命名空间
     * @param name      资源名称
     */
    public void delete(String namespace, String name) {
        NonNamespaceOperation<T, L, D, R> operation = getKubeOperation().inNamespace(namespace);
        operation.withName(name).cascading(true).delete();
    }

    public abstract MixedOperation<T, L, D, R> getKubeOperation();

}
