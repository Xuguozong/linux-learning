package com.hikvision.hae.resource.deployment.biz;


import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.Deployment;

import java.util.List;


/**
 * Deployment领域层操作接口
 *
 * @author jianghaiyang5 on 2017/11/2.
 */
public interface DeploymentBiz{
    /**
     * 查询满足条件的所有Deployment
     *
     * @param filterQuery 查询条件
     * @return Deployment对象列表
     */
    List<Deployment> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有Deployment
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return Deployment对象列表
     */
    Pagination<Deployment> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的Deployment
     *
     * @param namespace Deployment所在的namespace
     * @param name      Deployment的名称
     * @return null或者Deployment对象
     */
    Deployment getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的Deployment
     *
     * @param namespace Deployment所在的namespace
     * @param name      Deployment的名称
     */
    void delete(String namespace, String name);

    /**
     * 伸缩Pod数量
     *
     * @param namespace Deployment所在的namespace
     * @param name      Deployment的名称
     * @param newNum    新数量
     * @return 新Deployment对象
     */
    Deployment scale(String namespace, String name, int newNum);


}
