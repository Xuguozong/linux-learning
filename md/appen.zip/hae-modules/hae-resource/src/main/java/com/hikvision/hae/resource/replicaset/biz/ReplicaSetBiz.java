package com.hikvision.hae.resource.replicaset.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;

import java.util.List;

/**
 * ReplicaSet领域层操作接口
 *
 * @author jianghaiyang5 on 2017/11/3.
 */
public interface ReplicaSetBiz {

    /**
     * 查询满足条件的所有ReplicaSet
     *
     * @param filterQuery 查询条件
     * @return ReplicaSet对象列表
     */
    List<ReplicaSet> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有ReplicaSet
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return ReplicaSet对象列表
     */
    Pagination<ReplicaSet> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 分页查询指定Deployment的old ReplicaSet
     *
     * @param deployment Deployment实例
     * @param pageParam  分页条件
     * @return ReplicaSet对象列表
     */
    Pagination<ReplicaSet> findAndPageOldReplicaSet(Deployment deployment, PageParam pageParam);

    /**
     * 查询最新的ReplicaSet
     *
     * @param deployment Deployment实例
     * @return ReplicaSet对象
     */
    ReplicaSet getNewReplicaSet(Deployment deployment);

    /**
     * 查询指定namespace和name的ReplicaSet
     *
     * @param namespace ReplicaSet所在的namespace
     * @param name      ReplicaSet的名称
     * @return null或者ReplicaSet对象
     */
    ReplicaSet getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的ReplicaSet
     *
     * @param namespace ReplicaSet所在的namespace
     * @param name      ReplicaSet的名称
     */
    void delete(String namespace, String name);

}
