package com.hikvision.hae.resource.common.rawresource;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.*;
import io.fabric8.kubernetes.api.model.extensions.*;
import io.fabric8.kubernetes.client.utils.HttpClientUtils;
import io.fabric8.openshift.api.model.ClusterRole;
import io.fabric8.openshift.api.model.ClusterRoleBinding;
import io.fabric8.openshift.api.model.Role;
import io.fabric8.openshift.api.model.RoleBinding;
import okhttp3.OkHttpClient;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 *
 *
 * @author jianghaiyang5 on 2017/11/9.
 */
@org.springframework.stereotype.Service
public class SimpleResourceVerber implements ResourceVerber {
    private Map<ResourceKind, ResourceHttpClient> clientRegistry;

    @Resource
    private io.fabric8.kubernetes.client.Config config;

    private OkHttpClient client;

    @PostConstruct
    public void init() {
        String k8sMasterUrl = config.getMasterUrl();
        this.client = HttpClientUtils.createHttpClient(config);

        clientRegistry = new HashMap<>();
        clientRegistry.put(ResourceKind.ConfigMap,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "configmaps", ConfigMap.class));
        clientRegistry.put(ResourceKind.DaemonSet,
                new ResourceHttpClient<>(k8sMasterUrl, client, "extensions", "v1beta1", "daemonsets", DaemonSet.class));
        clientRegistry.put(ResourceKind.Deployment,
                new ResourceHttpClient<>(k8sMasterUrl, client, "extensions", "v1beta1", "deployments", Deployment.class));
        clientRegistry.put(ResourceKind.Event,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "events", Event.class));
        clientRegistry.put(ResourceKind.HorizontalPodAutoscaler,
                new ResourceHttpClient<>(k8sMasterUrl, client, "autoscaling", "v1", "horizontalpodautoscalers", HorizontalPodAutoscaler.class));
        clientRegistry.put(ResourceKind.Ingress,
                new ResourceHttpClient<>(k8sMasterUrl, client, "extensions", "v1beta1", "ingresses", Ingress.class));
        clientRegistry.put(ResourceKind.Job,
                new ResourceHttpClient<>(k8sMasterUrl, client, "batch", "v1", "jobs", Job.class));
        clientRegistry.put(ResourceKind.LimitRange,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "limitranges", LimitRange.class));
        clientRegistry.put(ResourceKind.Namespace,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "namespaces", Namespace.class));
        clientRegistry.put(ResourceKind.Node,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "nodes", Node.class));
        clientRegistry.put(ResourceKind.PersistentVolumeClaim,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "persistentvolumeclaims", PersistentVolumeClaim.class));
        clientRegistry.put(ResourceKind.PersistentVolume,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "persistentvolumes", PersistentVolume.class));
        clientRegistry.put(ResourceKind.Pod,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "pods", Pod.class));
        clientRegistry.put(ResourceKind.ReplicaSet,
                new ResourceHttpClient<>(k8sMasterUrl, client, "extensions", "v1beta1", "replicasets", ReplicaSet.class));
        clientRegistry.put(ResourceKind.ReplicationController,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "replicationcontrollers", ReplicationController.class));
        clientRegistry.put(ResourceKind.ResourceQuota,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "resourcequotas", ResourceQuota.class));
        clientRegistry.put(ResourceKind.Secret,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "secrets", Secret.class));
        clientRegistry.put(ResourceKind.ServiceAccount,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "serviceaccounts", ServiceAccount.class));
        clientRegistry.put(ResourceKind.Service,
                new ResourceHttpClient<>(k8sMasterUrl, client, null, "v1", "services", Service.class));
        clientRegistry.put(ResourceKind.StatefulSet,
                new ResourceHttpClient<>(k8sMasterUrl, client, "apps", "v1beta1", "statefulsets", StatefulSet.class));
        clientRegistry.put(ResourceKind.StorageClass,
                new ResourceHttpClient<>(k8sMasterUrl, client, "storage.k8s.io", "v1beta1", "storageclasses", StorageClass.class));
        clientRegistry.put(ResourceKind.ThirdPartyResource,
                new ResourceHttpClient<>(k8sMasterUrl, client, "extensions", "v1beta1", "thirdpartyresources", ThirdPartyResource.class));

        clientRegistry.put(ResourceKind.Role,
                new ResourceHttpClient<>(k8sMasterUrl, client, "rbac.authorization.k8s.io", "v1beta1", "roles", Role.class));
        clientRegistry.put(ResourceKind.RoleBinding,
                new ResourceHttpClient<>(k8sMasterUrl, client, "rbac.authorization.k8s.io", "v1beta1", "rolebindings",
                        RoleBinding.class));
        clientRegistry.put(ResourceKind.ClusterRole,
                new ResourceHttpClient<>(k8sMasterUrl, client, "rbac.authorization.k8s.io", "v1beta1", "clusterroles",
                        ClusterRole.class));
        clientRegistry.put(ResourceKind.ClusterRoleBinding,
                new ResourceHttpClient<>(k8sMasterUrl, client, "rbac.authorization.k8s.io", "v1beta1", "clusterrolebindings",
                        ClusterRoleBinding.class));
    }

    @Override
    public String getAllAsJsonString(ResourceKind kind, String namespace) {
        return clientRegistry.get(kind).handleGetRequest(namespace, null);
    }

    @Override
    public String getOneAsJsonString(ResourceKind kind, String namespace, String name) {
        return clientRegistry.get(kind).handleGetRequest(namespace, name);
    }

    @Override
    public String update(ResourceKind kind, String namespace, String name, String resourceJson) {
        return clientRegistry.get(kind).handlePutRequest(namespace, name, resourceJson);
    }

    @Override
    public HasMetadata create(ResourceKind kind, String namespace, String resourceJson) {
        return (HasMetadata) clientRegistry.get(kind).handleCreateRequest(namespace, resourceJson);
    }

    @Override
    public String delete(ResourceKind kind, String namespace, String name) {
        return clientRegistry.get(kind).handleDeleteRequest(namespace, name);
    }
}
