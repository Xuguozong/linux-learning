package com.hikvision.hae.resource.common.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public class PodInfo implements Serializable {

    private static final long serialVersionUID = -703414403662889512L;

    // Number of pods that are created.
    Integer current;

    // Number of pods that are desired.
    Integer desired;

    // Number of pods that are currently running.
    Integer running;

    // Number of pods that are currently waiting.
    Integer pending;

    // Number of pods that are failed.
    Integer failed;

    // Number of pods that are succeeded.
    Integer succeeded;
    
    // 警告消息
    List<String> warningMessages;

    public PodInfo() {
    }

    public PodInfo(Integer current, Integer desired) {
        this.current = current;
        this.desired = desired;
    }

    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public Integer getDesired() {
        return desired;
    }

    public void setDesired(Integer desired) {
        this.desired = desired;
    }

    public Integer getRunning() {
        return running;
    }

    public void setRunning(Integer running) {
        this.running = running;
    }

    public Integer getPending() {
        return pending;
    }

    public void setPending(Integer pending) {
        this.pending = pending;
    }

    public Integer getFailed() {
        return failed;
    }

    public void setFailed(Integer failed) {
        this.failed = failed;
    }

    public Integer getSucceeded() {
        return succeeded;
    }

    public void setSucceeded(Integer succeeded) {
        this.succeeded = succeeded;
    }

	public List<String> getWarningMessages() {
		return warningMessages;
	}

	public void setWarningMessages(List<String> warningMessages) {
		this.warningMessages = warningMessages;
	}
    
}
