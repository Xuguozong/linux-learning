/**
 * 
 */
package com.hikvision.hae.resource.serviceaccount.biz;

import java.util.List;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;

import io.fabric8.kubernetes.api.model.ServiceAccount;

/**
 * @author qihongfei
 *
 */
public interface ServiceAccountBiz {

	
	/**
     * 查询满足条件的所有ServiceAccount
     *
     * @param filterQuery 查询条件
     * @return ServiceAccount对象列表
     */
    List<ServiceAccount> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有ServiceAccount
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return ServiceAccount对象列表
     */
    Pagination<ServiceAccount> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的ServiceAccount
     *
     * @param namespace ServiceAccount所在的namespace
     * @param name      ServiceAccount的名称
     * @return null或者ServiceAccount对象
     */
    ServiceAccount getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的ServiceAccount
     *
     * @param namespace ServiceAccount所在的namespace
     * @param name      ServiceAccount的名称
     */
    void delete(String namespace, String name);
}
