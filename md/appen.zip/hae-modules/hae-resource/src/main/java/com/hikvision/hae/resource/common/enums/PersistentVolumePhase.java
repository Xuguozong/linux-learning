package com.hikvision.hae.resource.common.enums;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.common.util.DelayedLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;

/**
 * @author jianghaiyang5 on 2017/11/22.
 */
public enum PersistentVolumePhase {
    Pending, Available, Bound, Released, Failed;

    private static final Logger logger = LoggerFactory.getLogger(PersistentVolumePhase.class);

    public static PersistentVolumePhase parse(String name) {
        PersistentVolumePhase persistentVolumePhase =
                Stream.of(PersistentVolumePhase.values()).filter(c -> c.name().equals(name)).findFirst().orElse(null);
        if (persistentVolumePhase == null) {
            DelayedLogger.error(logger, () -> "将字符串" + name + "转换成枚举类型PersistentVolumePhase失败");
            throw new HAERuntimeException(CommonResultCode.INVALID_ENUM_STRING);
        }
        return persistentVolumePhase;
    }
}
