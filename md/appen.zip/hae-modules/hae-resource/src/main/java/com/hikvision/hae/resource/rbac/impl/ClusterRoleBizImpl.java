package com.hikvision.hae.resource.rbac.impl;

import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.common.operation.KubeRawHttpOperation;
import com.hikvision.hae.resource.rbac.ClusterRoleBiz;
import io.fabric8.openshift.api.model.ClusterRole;
import io.fabric8.openshift.api.model.ClusterRoleList;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/12/21.
 */
@Service
public class ClusterRoleBizImpl extends KubeRawHttpOperation<ClusterRole, ClusterRoleList> implements ClusterRoleBiz {

    @PostConstruct
    @Override
    public void init() {
        KubeOperationFactory.register(ResourceKind.ClusterRole, this);
    }

    @Override
    protected ResourceKind getResourceKindType() {
        return ResourceKind.ClusterRole;
    }

    @Override
    protected Class<ClusterRole> getResourceType() {
        return ClusterRole.class;
    }

    @Override
    protected Class<ClusterRoleList> getResourceListType() {
        return ClusterRoleList.class;
    }

    @Override
    public ClusterRole getByName(String name) {
        return super.getByName(null, name);
    }

    @Override
    public void delete(String name) {
        super.delete(null, name);
    }
}
