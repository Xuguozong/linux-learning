package com.hikvision.hae.resource.secret.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.Secret;

import java.util.List;

/**
 * @author jianghaiyang5 on 2017/11/15.
 */
public interface SecretBiz {

    /**
     * 查询满足条件的所有Secret
     *
     * @param filterQuery 查询条件
     * @return Secret对象列表
     */
    List<Secret> find(FilterQuery filterQuery);

    /**
     * 分页查询满足条件的所有Secret
     *
     * @param filterQuery 查询条件
     * @param pageParam   分页条件
     * @return Secret对象列表
     */
    Pagination<Secret> findAndPage(FilterQuery filterQuery, PageParam pageParam);

    /**
     * 查询指定namespace和name的Secret
     *
     * @param namespace Secret所在的namespace
     * @param name      Secret的名称
     * @return null或者Secret对象
     */
    Secret getByName(String namespace, String name);

    /**
     * 删除指定namespace和name的Secret
     *
     * @param namespace Secret所在的namespace
     * @param name      Secret的名称
     */
    void delete(String namespace, String name);
}
