package com.hikvision.hae.resource.statefulset.biz.impl;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.resource.common.constant.ResourceResultCode;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import com.hikvision.hae.resource.common.operation.KubeMixedOperation;
import com.hikvision.hae.resource.common.operation.KubeOperationFactory;
import com.hikvision.hae.resource.statefulset.biz.StatefulSetBiz;
import io.fabric8.kubernetes.api.model.extensions.DoneableStatefulSet;
import io.fabric8.kubernetes.api.model.extensions.StatefulSet;
import io.fabric8.kubernetes.api.model.extensions.StatefulSetList;
import io.fabric8.kubernetes.client.dsl.MixedOperation;
import io.fabric8.kubernetes.client.dsl.RollableScalableResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * @author jianghaiyang5 on 2017/11/21.
 */
@Service
public class StatefulSetBizImpl
        extends KubeMixedOperation<StatefulSet, StatefulSetList, DoneableStatefulSet, RollableScalableResource<StatefulSet, DoneableStatefulSet>>
        implements StatefulSetBiz {

    @Override
    @PostConstruct
    public void init() {
        KubeOperationFactory.register(ResourceKind.StatefulSet, this);
    }

    @Override
    public MixedOperation<StatefulSet, StatefulSetList, DoneableStatefulSet,
            RollableScalableResource<StatefulSet, DoneableStatefulSet>> getKubeOperation() {
        return kubeClient.apps().statefulSets();
    }

    @Override
    public StatefulSet scale(String namespace, String name, int newNum) {
        StatefulSet statefulSet = super.getByName(namespace, name);
        if (statefulSet == null) {
            throw new HAERuntimeException(ResourceResultCode.STATEFULSET_NOT_EXIST);
        }
        if (statefulSet.getSpec().getReplicas() == newNum) {
            return statefulSet;
        }
        return getKubeOperation().inNamespace(namespace).withName(name).scale(newNum);
    }
}
