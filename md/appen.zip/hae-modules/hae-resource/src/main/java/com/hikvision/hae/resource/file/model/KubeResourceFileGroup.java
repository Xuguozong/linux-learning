package com.hikvision.hae.resource.file.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;

import javax.persistence.*;
import java.util.Date;

/**
 * @author jianghaiyang5 on 2017/11/9.
 */
@Entity
@Table(name = "kube_resource_file_group")
@Comment("K8S资源文件分组表")
public class KubeResourceFileGroup extends DataObject {

    @Id
    @GeneratedValue
    private int id;

    @Column(name = "group_name", nullable = false, length = 64)
    private String groupName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    public enum Field implements jef.database.Field {
        id, groupName, createTime
    }

    public KubeResourceFileGroup() {
    }

    public KubeResourceFileGroup(String groupName) {
        this.groupName = groupName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }


}
