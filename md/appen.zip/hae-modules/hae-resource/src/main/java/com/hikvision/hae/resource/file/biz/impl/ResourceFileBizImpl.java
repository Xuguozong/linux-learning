package com.hikvision.hae.resource.file.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.file.biz.ResourceFileBiz;
import com.hikvision.hae.resource.file.dto.ResourceFileDTO;
import com.hikvision.hae.resource.file.dto.ResourceFileGroupDTO;
import com.hikvision.hae.resource.file.model.KubeResourceFile;
import com.hikvision.hae.resource.file.model.KubeResourceFileGroup;
import com.hikvision.hae.resource.file.repo.ResourceFileGroupRepo;
import com.hikvision.hae.resource.file.repo.ResourceFileRepo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author jianghaiyang5 on 2017/11/17.
 */
@Service
public class ResourceFileBizImpl implements ResourceFileBiz {
    @Resource
    private ResourceFileGroupRepo resourceFileGroupRepo;

    @Resource
    private ResourceFileRepo resourceFileRepo;

    @Transactional
    @Override
    public ResourceFileGroupDTO createGroup(ResourceFileGroupDTO group) {
        group.setCreateTime(new Date());
        KubeResourceFileGroup model = resourceFileGroupRepo.save(group.convertToModel());
        return ResourceFileGroupDTO.readFromModel(model);
    }

    @Transactional
    @Override
    public List<ResourceFileDTO> createFiles(List<ResourceFileDTO> files) {
        Date now = new Date();
        List<ResourceFileDTO> result = new ArrayList<>(files.size());
        for (ResourceFileDTO fileDTO : files) {
            fileDTO.setCreateTime(now);
            KubeResourceFile tmpFile = resourceFileRepo.save(fileDTO.convertToModel());
            result.add(ResourceFileDTO.readFromModel(tmpFile));
        }
        return result;
    }

    @Override
    public Pagination<ResourceFileGroupDTO> findAndPageGroup(String groupName, PageParam pageParam) {
        Page<KubeResourceFileGroup> modelPage = resourceFileGroupRepo.findByGroupNameContains(
                groupName, new PageRequest(pageParam.getPageNo() - 1, pageParam.getPageSize()));
        List<KubeResourceFileGroup> modelItems = modelPage.getContent();

        Pagination<ResourceFileGroupDTO> groupPage = Pagination.build(pageParam.getPageNo(), pageParam.getPageSize());
        groupPage.setTotal(modelPage.getTotalElements());
        groupPage.setLastPage(modelPage.getTotalPages());
        List<ResourceFileGroupDTO> groupDTOList;
        if (CollectionUtils.isEmpty(modelItems)) {
            groupDTOList = new ArrayList<>();
        } else {
            groupDTOList = modelItems.parallelStream().map(ResourceFileGroupDTO::readFromModel).collect(Collectors.toList());
        }
        groupPage.setRows(groupDTOList);
        return groupPage;
    }

    @Override
    public List<ResourceFileDTO> findFilesByGroup(int groupId) {
        List<KubeResourceFile> modelList = resourceFileRepo.findByField("groupId", groupId);
        if (CollectionUtils.isEmpty(modelList)) {
            return new ArrayList<>();
        }
        return modelList.parallelStream().map(ResourceFileDTO::readFromModel).collect(Collectors.toList());
    }

    @Override
    public ResourceFileDTO loadFile(int fileId) {
        KubeResourceFile resourceFile = resourceFileRepo.findOne(fileId);
        return resourceFile == null ? null : ResourceFileDTO.readFromModel(resourceFile);
    }

    @Override
    public ResourceFileGroupDTO loadGroup(int groupId) {
        KubeResourceFileGroup group = resourceFileGroupRepo.findOne(groupId);
        return group == null ? null : ResourceFileGroupDTO.readFromModel(group);
    }

    @Override
    public void deleteFile(int fileId) {
        resourceFileRepo.delete(fileId);
    }

    @Override
    public void deleteGroup(int groupId) {
        resourceFileGroupRepo.delete(groupId);
    }
    
    @Override
    public void editFile(ResourceFileDTO fileDto) {
    	resourceFileRepo.update(fileDto.convertToModel());
    }

    @Override
    public ResourceFileGroupDTO findGroupByName(String groupName) {
        KubeResourceFileGroup kubeResourceFileGroup=resourceFileGroupRepo.findByGroupName(groupName);
        return null == kubeResourceFileGroup ? null : ResourceFileGroupDTO.readFromModel(kubeResourceFileGroup);
    }

    @Transactional
    @Override
    public void updateGroup(int groupID, String groupName) {
        resourceFileGroupRepo.updateGroup(groupID, groupName);
    }
}
