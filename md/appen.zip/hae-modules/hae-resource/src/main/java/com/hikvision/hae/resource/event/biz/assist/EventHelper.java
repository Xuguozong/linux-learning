package com.hikvision.hae.resource.event.biz.assist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.fabric8.kubernetes.api.model.Event;

/**
 * @author jianghaiyang5 on 2017/11/7.
 */
public class EventHelper {

    /**
     * 根据事件原因去重
     * @param eventList 事件列表
     * @return 去重后的事件列表
     */
    public static List<Event> removeDuplicatesByReason(List<Event> eventList){
    	
    	List<Event> result = new ArrayList<>();
    	
    	if(eventList == null || eventList.size() == 0){
    		return result;
    	}
    	
    	Map<String, String> visited = new HashMap<>();
    	
    	for (Event event : eventList) {
    		if(!visited.containsKey(event.getReason())){
    			visited.put(event.getReason(), event.getReason());
    			result.add(event);
    		}
		}
    	
    	return result;
    }
    
    /**
     * 根据所属资源ID事件筛选事件
     * @param eventList 事件列表
     * @param involvedObjectUid 资源ID
     * @return 筛选后的事件列表
     */
    public static List<Event> filterByInvolvedObjectUid(List<Event> eventList, String involvedObjectUid){
    	
    	List<Event> result = new ArrayList<>();
    	
    	if(eventList == null || eventList.size() == 0){
    		return result;
    	}
    	
    	for (Event event : eventList) {
    		if(involvedObjectUid.equals(event.getInvolvedObject().getUid())){
    			result.add(event);
    		}
		}
    	
    	return result;
    }
}
