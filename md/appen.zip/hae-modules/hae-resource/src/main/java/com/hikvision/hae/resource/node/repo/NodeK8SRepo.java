package com.hikvision.hae.resource.node.repo;

import io.fabric8.kubernetes.api.model.Node;
import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.kubernetes.client.KubernetesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * Created by zhanjiejun on 2017/11/2.
 */
@Component
public class NodeK8SRepo {

	@Autowired
	private KubernetesClient k8sClient;

	public List<Node> listNodes() {
		return k8sClient.nodes().list().getItems();
	}

	public List<Node> listNodes(Map<String, String> labels) {
		return k8sClient.nodes().withLabels(labels).list().getItems();
	}

	public Node getNodeByName(String name) {
		return k8sClient.nodes().withName(name).get();
	}

	public Boolean deleteNodeByName(String name) {
		return k8sClient.nodes().withName(name).delete();
	}

	/**
	 * 更新节点
	 *
	 * @param node
	 * @return
	 */
	public Node updateNode(Node node) {
		return k8sClient.nodes().withName(node.getMetadata().getName()).patch(node);
	}

	/**
	 * 根据节点名称获取节点上的POD
	 *
	 * @param nodeName
	 * @return
	 */
	public List<Pod> getPodsByNodeName(String nodeName) {
		return k8sClient.pods().inAnyNamespace().withField("spec.nodeName", nodeName).list().getItems();
	}

	/**
	 * 根据节点名称驱逐节点上的所有POD
	 * @param nodeName
	 */
	public void evictPodsByNodeName(String nodeName) {
		k8sClient.pods().inAnyNamespace().withField("spec.nodeName", nodeName).withGracePeriod(30).delete();
	}

}
