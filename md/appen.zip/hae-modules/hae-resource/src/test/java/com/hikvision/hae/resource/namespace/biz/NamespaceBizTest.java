package com.hikvision.hae.resource.namespace.biz;

import com.alibaba.fastjson.JSONObject;
import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.resource.namespace.dto.NamespaceWriteDTO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by zhanjiejun on 2017/11/9.
 */
public class NamespaceBizTest extends HaeResourceBaseTest {

	@Autowired
	private NamespaceBiz namespaceBiz;

	@Test
	public void testCreateNamespace() {
		NamespaceWriteDTO writeDTO = new NamespaceWriteDTO();
		writeDTO.setName("unit-test");
		writeDTO.setCpuQuota(2.1f);
		writeDTO.setMemoryQuota(1024);
		System.out.println(JSONObject.toJSONString(namespaceBiz.createNamespace(writeDTO)));

		writeDTO.setCpuQuota(3);
		System.out.println(JSONObject.toJSONString(namespaceBiz.modifyNamespaceQuota(writeDTO)));
	}

	@Test
	public void testGetNamespaces() {
		System.out.println(JSONObject.toJSONString(namespaceBiz.getNamespaceByName("unit-test")));
		namespaceBiz.deleteNamespaceByName("unit-test");
		System.out.println(JSONObject.toJSONString(namespaceBiz.getNamespaces(true)));
	}

}
