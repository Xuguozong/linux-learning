package com.hikvision.hae.resource.job;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.Job;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:50 2018/1/4
 * @Description :  job资源对象测试类
 */
public class JobBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private JobBiz jobBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<Job> jobs=  jobBiz.find(filterQuery);
        printJobMessage(jobs);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        Pagination<Job> jobPagination = jobBiz.findAndPage(filterQuery, new PageParam(1, 10));
        printJobMessage(jobPagination.getRows());
    }

    @Test
    public void getByName() {
        Job job = jobBiz.getByName("default", "mysql");
        System.out.println(null == job ? "no job" : job.toString() );
    }

    @Test
    public void delete() {
        jobBiz.delete("default", "mysql");
    }

    /**
     * 打印任务对象信息
     * @param jobs
     */
    private void printJobMessage(Collection<Job> jobs){
        jobs.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
