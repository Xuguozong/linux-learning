package com.hikvision.hae.resource.persistentVolumeclaim;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.persistentvolumeclaim.PersistentVolumeClaimBiz;
import io.fabric8.kubernetes.api.model.PersistentVolumeClaim;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:59 2018/1/4
 * @Description :  持久卷申请测试类
 */
public class PersistentVolumeClaimBizImplTest extends HaeResourceBaseTest {
    
    @Autowired
    private PersistentVolumeClaimBiz persistentVolumeClaimBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<PersistentVolumeClaim> persistentVolumeClaims = persistentVolumeClaimBiz.find(filterQuery);
        printVolumeMessage(persistentVolumeClaims);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        Pagination<PersistentVolumeClaim> pagination = persistentVolumeClaimBiz.findAndPage(filterQuery,
                new PageParam(1,10));
        printVolumeMessage(pagination.getRows());
    }

    @Test
    public void getByName() {
        PersistentVolumeClaim persistentVolumeClaim = persistentVolumeClaimBiz.getByName("default", "mysql");
        System.out.println(null == persistentVolumeClaim ? "no pepersistentVolumeClaim" : persistentVolumeClaim.toString());
    }

    @Test
    public void delete() {
        persistentVolumeClaimBiz.delete("default", "mysql");
    }

    /**
     * 打印持久卷申请信息
     * @param persistentVolumeClaims
     */
    private void printVolumeMessage(Collection<PersistentVolumeClaim> persistentVolumeClaims){
        persistentVolumeClaims.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
