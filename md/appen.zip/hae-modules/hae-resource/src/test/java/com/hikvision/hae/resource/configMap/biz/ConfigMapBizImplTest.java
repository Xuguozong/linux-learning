package com.hikvision.hae.resource.configMap.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.configmap.biz.ConfigMapBiz;
import io.fabric8.kubernetes.api.model.ConfigMap;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 15:04 2018/1/4
 * @Description :  k8s配置Map测试类
 */
public class ConfigMapBizImplTest extends HaeResourceBaseTest{

    @Autowired
    private ConfigMapBiz configMapBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = new FilterQuery();
        //根据情况适当添加 查询条件属性
        List<ConfigMap> configMapList = configMapBiz.find(filterQuery);
        printListInfo(configMapList);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = new FilterQuery();
        PageParam pageParam = new PageParam(1,10);
        Pagination<ConfigMap> configMapPagination = configMapBiz.findAndPage(filterQuery,pageParam);
        printListInfo(configMapPagination.getRows());
    }

    @Test
    public void getByName() {
        ConfigMap configMap=configMapBiz.getByName("default","mysql");
        printMap(configMap);
    }

    @Test
    public void delete() {
        //删除操作慎重测试
        configMapBiz.delete("default","mysql");
    }

    /**
     * 控制台打印测试信息
     * @param configMaps 集合list配置map
     */
    private void printListInfo(Collection<ConfigMap> configMaps){
        configMaps.forEach((e)->{
            printMap(e);
        });
    }

    /**
     * 打印单个配置map信息
     * @param configMap
     */
    private void printMap(ConfigMap configMap){
        Map dataMap = configMap.getData();
        Iterator it = dataMap.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry entry = (Map.Entry)it.next();
            System.out.println(entry.getKey()+" : "+entry.getValue());
        }
    }
}
