package com.hikvision.hae.resource.deployment;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.deployment.biz.DeploymentBiz;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author jianghaiyang5 on 2017/11/3.
 */
public class DeploymentTest extends HaeResourceBaseTest {

    @Autowired
    private DeploymentBiz deploymentBiz;

    @Test
    public void testFindAndPage() {
        FilterQuery filterQuery = FilterQuery.build().namespace("default").lableKey("app");
        PageParam pageParam = new PageParam(1, 2);

        Pagination<Deployment> pageResult = deploymentBiz.findAndPage(filterQuery, pageParam);
        System.out.println(pageResult.getTotal() + ", " + pageResult.getLastPage());
        for (Deployment d : pageResult.getRows()) {
            System.out.println(d.getMetadata().getName());
        }
    }

    @Test
    public void testDetail() {
        Deployment deployment = deploymentBiz.getByName("default", "weave-scope-app");
        System.out.println(deployment.getMetadata().getName());
    }
}
