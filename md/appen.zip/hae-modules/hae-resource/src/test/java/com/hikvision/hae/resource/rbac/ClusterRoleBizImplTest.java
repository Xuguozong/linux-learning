package com.hikvision.hae.resource.rbac;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.openshift.api.model.ClusterRole;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 9:56 2018/1/5
 * @Description :  集群角色测试类
 */
public class ClusterRoleBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private ClusterRoleBiz clusterRoleBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<ClusterRole> clusterRoles = clusterRoleBiz.find(filterQuery);
        printClusterRoleMsg(clusterRoles);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<ClusterRole> clusterRolePagination = clusterRoleBiz.findAndPage(filterQuery, pageParam);
        printClusterRoleMsg(clusterRolePagination.getRows());
    }

    @Test
    public void getByName() {
        ClusterRole clusterRole = clusterRoleBiz.getByName("role123");
        System.out.println(null == clusterRole? "no clusterRole" : clusterRole.toString());
    }

    @Test
    public void delete() {
        clusterRoleBiz.delete("role123");
    }

    /**
     * 控制台打印集群角色信息
     * @param clusterRoles
     */
    private void printClusterRoleMsg(Collection<ClusterRole> clusterRoles){
        clusterRoles.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
