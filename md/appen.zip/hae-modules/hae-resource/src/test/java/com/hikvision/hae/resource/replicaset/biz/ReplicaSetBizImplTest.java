package com.hikvision.hae.resource.replicaset.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.Deployment;
import io.fabric8.kubernetes.api.model.extensions.ReplicaSet;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 10:42 2018/1/5
 * @Description :  k8s副本集测试类
 */
public class ReplicaSetBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private ReplicaSetBiz replicaSetBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<ReplicaSet> replicaSets = replicaSetBiz.find(filterQuery);
        printReplicaSetMsg(replicaSets);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        PageParam pageParam = new PageParam(1,10);
        Pagination<ReplicaSet> pagination = replicaSetBiz.findAndPage(filterQuery, pageParam);
        printReplicaSetMsg(pagination.getRows());
    }

    @Test
    public void findAndPageOldReplicaSet() {
        Deployment deployment = new Deployment();
        PageParam pageParam = new PageParam(1, 10);
        Pagination<ReplicaSet> pagination = replicaSetBiz.findAndPageOldReplicaSet(deployment, pageParam);
        printReplicaSetMsg(pagination.getRows());
    }

    @Test
    public void getNewReplicaSet() {
        Deployment deployment = new Deployment();
        ReplicaSet replicaSet = replicaSetBiz.getNewReplicaSet(deployment);
        System.out.println(null == replicaSet? "no replicaSet" : replicaSet.toString());
    }

    @Test
    public void getByName() {
        ReplicaSet replicaSet = replicaSetBiz.getByName("default", "deployment123");
        System.out.println(null == replicaSet? "no replicaSet" : replicaSet.toString());
    }

    @Test
    public void delete() {
        replicaSetBiz.delete("default", "deployment123");
    }

    /**
     * 控制台打印副本集
     * @param replicaSets
     */
    private void printReplicaSetMsg(Collection<ReplicaSet> replicaSets){
        replicaSets.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
