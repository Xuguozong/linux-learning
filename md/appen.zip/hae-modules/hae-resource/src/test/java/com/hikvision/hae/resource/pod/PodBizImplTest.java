package com.hikvision.hae.resource.pod;

import com.google.common.collect.Maps;
import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import com.hikvision.hae.resource.common.dto.PodInfo;
import com.hikvision.hae.resource.pod.biz.PodBiz;
import io.fabric8.kubernetes.api.model.LabelSelector;
import io.fabric8.kubernetes.api.model.Pod;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 17:12 2018/1/4
 * @Description :  pod资源对象测试类
 */
public class PodBizImplTest extends HaeResourceBaseTest {
    
    @Autowired
    private PodBiz podBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = FilterQuery.build();
        List<Pod> pods = podBiz.find(filterQuery);
        printPodMessage(pods);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = FilterQuery.build();
        Pagination<Pod> pagination = podBiz.findAndPage(filterQuery, new PageParam(1,10));
        printPodMessage(pagination.getRows());
    }

    @Test
    public void getByName() {
        Pod pod = podBiz.getByName("default","mysql");
        System.out.println(null == pod? "no pod": pod.toString());
    }

    @Test
    public void getPodInfo() {
        LabelSelector labelSelector = new LabelSelector();
        String namespace ="default";
        Integer currentPods = 2;
        Integer desiredPods = 2;
        String ownerUid = "1";
        PodInfo podInfo = podBiz.getPodInfo(labelSelector, namespace, currentPods, desiredPods, ownerUid);
        System.out.println(null == podInfo? "no podInfo": podInfo.toString());
    }

    @Test
    public void getPodInfoTwo() {
        Map<String, String> mapSelector = Maps.newHashMap();
        String namespace ="default";
        Integer currentPods = 2;
        Integer desiredPods = 2;
        String ownerUid = "1";
        PodInfo podInfo = podBiz.getPodInfo(mapSelector, namespace, currentPods, desiredPods, ownerUid);
        System.out.println(null == podInfo? "no podInfo": podInfo.toString());
    }

    @Test
    public void delete() {
        podBiz.delete("default", "mysql");
    }

    private void printPodMessage(Collection<Pod> pods){
        pods.forEach((e)->{
            System.out.println(e.toString());
        });
    }
}
