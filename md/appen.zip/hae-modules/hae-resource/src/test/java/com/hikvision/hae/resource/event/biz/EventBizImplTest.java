package com.hikvision.hae.resource.event.biz;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.enums.ResourceKind;
import io.fabric8.kubernetes.api.model.Event;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 16:16 2018/1/4
 * @Description :  事件业务测试类
 */
public class EventBizImplTest extends HaeResourceBaseTest {

    @Autowired
    private EventBiz eventBiz;

    @Test
    public void findAndPage() {
        Pagination<Event> eventPagination = eventBiz.findAndPage("default", ResourceKind.Event,
                "mysql", new PageParam(1, 10));
        printMessage(eventPagination.getRows());
    }

    @Test
    public void find() {
        List<Event> events = eventBiz.find("default", ResourceKind.Event,
                "mysql", "1", null);
        printMessage(events);
    }

    /**
     * 控制台打印信息
     * @param events
     */
    private void printMessage(Collection<Event> events){
        events.forEach((event)->{
            System.out.println(event.getMessage());
        });
    }
}
