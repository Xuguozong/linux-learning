package com.hikvision.hae.resource.daemonset;

import com.hikvision.hae.HaeResourceBaseTest;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.common.vo.Pagination;
import com.hikvision.hae.resource.common.dataselect.FilterQuery;
import io.fabric8.kubernetes.api.model.extensions.DaemonSet;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

/**
 * @Author      :  lijiazheng
 * @Date        :  Created in 15:33 2018/1/4
 * @Description :  daemonset测试类
 */
public class DaemonSetBizImplTest extends HaeResourceBaseTest{

    @Autowired
    private DaemonSetBiz daemonSetBiz;

    @Test
    public void find() {
        FilterQuery filterQuery = new FilterQuery();
        List<DaemonSet> daemonSets = daemonSetBiz.find(filterQuery);
        printDaemonSetInfo(daemonSets);
    }

    @Test
    public void findAndPage() {
        FilterQuery filterQuery = new FilterQuery();
        PageParam pageParam = new PageParam(1,10);
        Pagination<DaemonSet> daemonSetPagination = daemonSetBiz.findAndPage(filterQuery, pageParam);
        printDaemonSetInfo(daemonSetPagination.getRows());
    }

    @Test
    public void getByName() {
        DaemonSet daemonSet = daemonSetBiz.getByName("default","mysql");
        System.out.println(null == daemonSet ? "no query result" : daemonSet.getKind());
    }

    @Test
    public void delete() {
        daemonSetBiz.delete("default", "mysql");
    }

    /**
     * 打印后台守护信息
     * @param daemonSets
     */
    private void printDaemonSetInfo(Collection<DaemonSet> daemonSets){
        daemonSets.forEach((e)->{
            System.out.println(e.getKind());
        });
    }
}
