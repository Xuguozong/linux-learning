package com.hikvision.hae.metrics.biz.impl;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.metrics.biz.MetricsBiz;
import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import com.hikvision.hae.metrics.repo.MetricsRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
@Service
public class MetricsBizImpl implements MetricsBiz {

	private static final Logger logger = LoggerFactory.getLogger(MetricsBizImpl.class);

	@Autowired
	private MetricsRepo metricsRepo;

	@Override
	public MetricsDTO metricsNode(String nodeName, MetricsType metricsType) {
		MetricsDTO metricsDTO = null;
		try {
			metricsDTO = metricsRepo.metricNode(nodeName, metricsType);
		} catch (Exception e) {
			logger.error("Metrics node [" + nodeName + "] failed.", e);
		}
		return metricsDTO;
	}

	@Override
	public MetricsDTO metricsNodeGpu(String nodeName, String gpuIndex, Date start, Date end, MetricsType metricsType) {
		MetricsDTO metricsDTO = null;
		try {
			metricsDTO = metricsRepo.metricNodeGPU(nodeName, gpuIndex, start, end, metricsType);
		} catch (Exception e) {
			logger.error("Metrics node [" + nodeName + "] gpu [" + gpuIndex + "] failed.", e);
		}
		return metricsDTO;
	}

	@Override
	public GpuBaseInfo getNodeGpuBaseInfo(String nodeName, String gpuIndex) {
		GpuBaseInfo gpuBaseInfo = null;
		try {
			gpuBaseInfo = metricsRepo.getNodeGpuBaseInfo(nodeName, gpuIndex);
		} catch (Exception e) {
			logger.error("Get node [" + nodeName + "] gpu [" + gpuIndex + "] base info failed.", e);
		}
		return gpuBaseInfo;
	}

	@Override
	public List<MetricsDTO> metricsCluster(MetricsType metricsType) {
		List<MetricsDTO> metricsDTOs = new ArrayList<>();
		List<String> nodeList = null;
		try {
			nodeList = metricsRepo.getNodeItems();
			if (!CollectionUtils.isEmpty(nodeList)) {
				nodeList.parallelStream().forEach(node -> {
					MetricsDTO metricsDTO = metricsNode(node, metricsType);
					if (metricsDTO != null) {
						metricsDTOs.add(metricsDTO);
					}
				});
			}
		} catch (Exception e) {
			logger.error("Get node list from metrics failed.", e);
		}
		return metricsDTOs;
	}

}
