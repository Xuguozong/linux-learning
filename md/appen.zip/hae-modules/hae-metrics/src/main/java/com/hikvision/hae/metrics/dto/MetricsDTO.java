package com.hikvision.hae.metrics.dto;

import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public class MetricsDTO {

	private List<MetricsData> metrics;

	private String latestTimestamp;

	public static class MetricsData {
		private String timestamp;

		private long value;

		public String getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}

		public long getValue() {
			return value;
		}

		public void setValue(long value) {
			this.value = value;
		}
	}

	public List<MetricsData> getMetrics() {
		return metrics;
	}

	public void setMetrics(List<MetricsData> metrics) {
		this.metrics = metrics;
	}

	public String getLatestTimestamp() {
		return latestTimestamp;
	}

	public void setLatestTimestamp(String latestTimestamp) {
		this.latestTimestamp = latestTimestamp;
	}
}
