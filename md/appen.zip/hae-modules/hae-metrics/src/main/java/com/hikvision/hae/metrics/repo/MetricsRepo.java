package com.hikvision.hae.metrics.repo;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.util.StringUtils;
import com.hikvision.hae.common.util.UTCDateUtil;
import com.hikvision.hae.metrics.common.constant.MetricsConstants;
import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.metrics.dto.MetricsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
@Component
public class MetricsRepo {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${metrics.server.endpoint:http://monitor-core:8090}")
	private String metricsEndpoint;

	public MetricsDTO metricNode(String nodeName, MetricsType metricsType) {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<>(httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(metricsEndpoint, MetricsConstants.NODE_METRICS_API_PATTERN);
		// 构建请求参数
		Map<String, Object> uriVariables = new HashMap<>();
		uriVariables.put("nodeName", nodeName);
		uriVariables.put("metricsType", metricsType.getType());
		// 调用接口
		ResponseEntity<MetricsDTO> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, MetricsDTO.class, uriVariables);
		return response.getBody();
	}

	public MetricsDTO metricNodeGPU(String nodeName, String gpuIndex, Date start, Date end, MetricsType metricsType) {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<>(httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(metricsEndpoint, MetricsConstants.NODE_GPU_METRICS_API_PATTERN);
		// 构建请求参数
		Map<String, Object> uriVariables = new HashMap<>();
		uriVariables.put("nodeName", nodeName);
		uriVariables.put("gpuIndex", gpuIndex);
		uriVariables.put("metricsType", metricsType.getType());
		uriVariables.put("start", UTCDateUtil.formatDateToUTCTime(start));
		uriVariables.put("end", UTCDateUtil.formatDateToUTCTime(end));
		// 调用接口
		ResponseEntity<MetricsDTO> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, MetricsDTO.class, uriVariables);
		return response.getBody();
	}

	public GpuBaseInfo getNodeGpuBaseInfo(String nodeName, String gpuIndex) {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<>(httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(metricsEndpoint, MetricsConstants.NODE_GPU_BASE_INFO_API_PATTERN);
		// 构建请求参数
		Map<String, Object> uriVariables = new HashMap<>();
		uriVariables.put("nodeName", nodeName);
		uriVariables.put("gpuIndex", gpuIndex);
		// 调用接口
		ResponseEntity<GpuBaseInfo> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, GpuBaseInfo.class, uriVariables);
		return response.getBody();
	}

	public List<String> getNodeItems() {
		// 构建认证头
		HttpHeaders httpHeaders = buildHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<>(httpHeaders);
		// 构建请求URL
		String url = StringUtils.joinURL(metricsEndpoint, MetricsConstants.NODE_ITEMS_API);
		// 调用接口
		ParameterizedTypeReference<List<String>> responseType = new ParameterizedTypeReference<List<String>>() {};
		ResponseEntity<List<String>> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, responseType);
		return response.getBody();
	}

	private HttpHeaders buildHeaders() {
		HttpHeaders headers = new HttpHeaders();
		List<MediaType> accepts = new ArrayList<>();
		accepts.add(MediaType.APPLICATION_JSON);
		headers.setAccept(accepts);
		return headers;
	}

}
