package com.hikvision.hae.metrics.common.constant;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public class MetricsConstants {

	public static final String NODE_METRICS_API_PATTERN = "/api/v1/model/nodes/{nodeName}/metrics/{metricsType}";

	public static final String NODE_GPU_METRICS_API_PATTERN = "/api/v1/model/nodes/{nodeName}/gpus/{gpuIndex}/metrics/{metricsType}?start={start}&end={end}";

	public static final String NODE_GPU_BASE_INFO_API_PATTERN = "/api/v1/model/nodes/{nodeName}/gpus/{gpuIndex}/special-export";

	public static final String NODE_ITEMS_API = "/api/v1/model/nodes";

}
