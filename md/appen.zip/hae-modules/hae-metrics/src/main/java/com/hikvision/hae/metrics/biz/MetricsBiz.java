package com.hikvision.hae.metrics.biz;

import com.hikvision.hae.common.enums.MetricsType;
import com.hikvision.hae.common.domain.GpuBaseInfo;
import com.hikvision.hae.metrics.dto.MetricsDTO;

import java.util.Date;
import java.util.List;

/**
 * Created by zhanjiejun on 2017/11/20.
 */
public interface MetricsBiz {

	/**
	 * 获取节点监控信息
	 *
	 * @param nodeName    节点K8S名称
	 * @param metricsType
	 * @return
	 */
	MetricsDTO metricsNode(String nodeName, MetricsType metricsType);

	/**
	 * 获取节点GPU监控信息
	 *
	 * @param nodeName    节点K8S名称
	 * @param gpuIndex    GPU卡序号
	 * @param start       开始时间
	 * @param end         结束时间
	 * @param metricsType
	 * @return
	 */
	MetricsDTO metricsNodeGpu(String nodeName, String gpuIndex, Date start, Date end, MetricsType metricsType);

	/**
	 * 获取节点GPU基本信息
	 *
	 * @param nodeName 节点K8S名称
	 * @param gpuIndex GPU卡序号
	 * @return
	 */
	GpuBaseInfo getNodeGpuBaseInfo(String nodeName, String gpuIndex);

	/**
	 * 获取集群监控信息
	 *
	 * @param metricsType
	 * @return
	 */
	List<MetricsDTO> metricsCluster(MetricsType metricsType);

}
