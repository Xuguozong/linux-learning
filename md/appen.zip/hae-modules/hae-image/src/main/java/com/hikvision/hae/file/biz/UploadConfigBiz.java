package com.hikvision.hae.file.biz;

public interface UploadConfigBiz {

	String uploadLocation();
}
