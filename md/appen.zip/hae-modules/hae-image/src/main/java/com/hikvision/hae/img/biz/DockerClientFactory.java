package com.hikvision.hae.img.biz;

import com.spotify.docker.client.DockerClient;

public interface DockerClientFactory {

	DockerClient createDockerClient(String repositoryHostOrIP, String dockerServerURL, String user, String password);
}
