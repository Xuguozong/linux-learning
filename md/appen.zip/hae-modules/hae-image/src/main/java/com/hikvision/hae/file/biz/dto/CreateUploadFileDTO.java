package com.hikvision.hae.file.biz.dto;

public class CreateUploadFileDTO {

	private String fileId;

	private String nativePath;

	private String fileName;

	private int totalChunks;

	private int currentTrunk;
	
	private String tmpSavePath;
	
	private long totalSize;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getNativePath() {
		return nativePath;
	}

	public void setNativePath(String nativePath) {
		this.nativePath = nativePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getTotalChunks() {
		return totalChunks;
	}

	public void setTotalChunks(int totalChunks) {
		this.totalChunks = totalChunks;
	}

	public int getCurrentTrunk() {
		return currentTrunk;
	}

	public void setCurrentTrunk(int currentTrunk) {
		this.currentTrunk = currentTrunk;
	}

	public String getTmpSavePath() {
		return tmpSavePath;
	}

	public void setTmpSavePath(String tmpSavePath) {
		this.tmpSavePath = tmpSavePath;
	}

	public long getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}
}
