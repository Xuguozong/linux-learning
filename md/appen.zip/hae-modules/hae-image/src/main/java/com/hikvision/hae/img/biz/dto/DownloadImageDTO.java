package com.hikvision.hae.img.biz.dto;

public class DownloadImageDTO {

	private String imageName;
	
	private ImageRepositoryAccessInfo accessInfo;
	
	public DownloadImageDTO(ImageRepositoryAccessInfo accessInfo, String imageFullName) {
		this.accessInfo = accessInfo;
		this.imageName = imageFullName;
	}

	public String getImageName() {
		return imageName;
	}

	public ImageRepositoryAccessInfo getAccessInfo() {
		return accessInfo;
	}
}
