package com.hikvision.hae.img.biz.impl;

import javax.annotation.Resource;

import com.hikvision.hae.img.biz.DockerClientFactory;
import com.hikvision.hae.img.biz.dto.ImageRepositoryAccessInfo;
import com.spotify.docker.client.DockerClient;

public class AbstractImageBiz {

	@Resource
	private DockerClientFactory clientFactory;
	
	
	protected DockerClient createDockerClient(ImageRepositoryAccessInfo accessInfo) {
		return clientFactory.createDockerClient(accessInfo.getHarborAccessInfo(), accessInfo.getDockerServerURL(), accessInfo.getHarborUser(), accessInfo.getHarborPassword());
	}
	
}
