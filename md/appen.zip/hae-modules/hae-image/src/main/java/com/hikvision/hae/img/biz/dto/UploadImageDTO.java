package com.hikvision.hae.img.biz.dto;

import java.io.InputStream;

public class UploadImageDTO {

	private InputStream imageStream;

	private String fileId;
	
	private ImageRepositoryAccessInfo accessInfo;
	
	public UploadImageDTO(ImageRepositoryAccessInfo accessInfo) {
		this.accessInfo = accessInfo;
	}
	
	public InputStream getImageStream() {
		return imageStream;
	}

	public void setImageStream(InputStream imageStream) {
		this.imageStream = imageStream;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public ImageRepositoryAccessInfo getAccessInfo() {
		return accessInfo;
	}
}
