package com.hikvision.hae.img.repo.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.repo.ServiceProvider;

import io.swagger.client.ApiClient;
import io.swagger.client.api.ProductsApi;
import io.swagger.client.auth.HttpBasicAuth;

@Component
public class HarborServiceProvider implements ServiceProvider {
	
	@Resource
	private ImageRepositoryConfigBiz config;
	
	
	private String getBasePath() {
		String path = config.accessInfo().getHarborURL() + "/api";
		if(!path.startsWith("http")) {
			throw new HAERuntimeException(CommonResultCode.MALFORMED_URL_ERROR);
		}
		return path;
	}

	@Override
	public ProductsApi createProductsApi() {
		ApiClient client = new ApiClient();
		client.setBasePath(getBasePath());
		client.setVerifyingSsl(false);
		client.setConnectTimeout(30 * 1000);
		HttpBasicAuth basic = new HttpBasicAuth();
		basic.setUsername(config.accessInfo().getHarborUser());
		basic.setPassword(config.accessInfo().getHarborPassword());
		client.getAuthentications().put("basic", basic);
		return new ProductsApi(client);
	}

}
