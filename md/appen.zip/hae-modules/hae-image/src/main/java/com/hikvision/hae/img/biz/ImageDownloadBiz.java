package com.hikvision.hae.img.biz;

import java.io.IOException;
import java.io.InputStream;

import com.hikvision.hae.img.biz.dto.DownloadImageDTO;
import com.spotify.docker.client.exceptions.DockerException;

public interface ImageDownloadBiz {

	InputStream downloadImage(DownloadImageDTO downloadDTO) throws DockerException, InterruptedException, IOException;
}
