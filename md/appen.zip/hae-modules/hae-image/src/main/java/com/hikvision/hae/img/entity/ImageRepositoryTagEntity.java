package com.hikvision.hae.img.entity;

import io.swagger.client.model.DetailedTag;

public class ImageRepositoryTagEntity {

	private String name;
	
	private String architecture;

	private String os;
	
	private String repoName;
	
	public ImageRepositoryTagEntity(DetailedTag tag) {
		this.name = tag.getName();
		this.architecture = tag.getArchitecture();
		this.os = tag.getOs();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getArchitecture() {
		return architecture;
	}

	public void setArchitecture(String architecture) {
		this.architecture = architecture;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getRepoName() {
		return repoName;
	}

	public void setRepoName(String repoName) {
		this.repoName = repoName;
	}
	
}
