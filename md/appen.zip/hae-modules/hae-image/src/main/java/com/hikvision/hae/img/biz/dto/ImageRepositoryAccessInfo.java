package com.hikvision.hae.img.biz.dto;

public class ImageRepositoryAccessInfo {

	private String dockerServerURL;
	
	private String harborURL;
	/**
	 * docker client需要镜像仓库的主机名，不需要镜像仓库完整URL地址
	 */
	private String harborAccessAddress;
	
	private String harborUser;
	
	private String harborPassword;

	public String getDockerServerURL() {
		return dockerServerURL;
	}

	public void setDockerServerURL(String dockerServerURL) {
		this.dockerServerURL = dockerServerURL;
	}

	public String getHarborURL() {
		return harborURL;
	}

	public void setHarborURL(String harborURL) {
		this.harborURL = harborURL;
	}

	public String getHarborAccessInfo() {
		return harborAccessAddress;
	}

	public void setHarborAccessInfo(String harborAccessAddress) {
		this.harborAccessAddress = harborAccessAddress;
	}

	public String getHarborUser() {
		return harborUser;
	}

	public void setHarborUser(String harborUser) {
		this.harborUser = harborUser.trim();
	}

	public String getHarborPassword() {
		return harborPassword;
	}

	public void setHarborPassword(String harborPassword) {
		this.harborPassword = harborPassword.trim();
	}
	
}
