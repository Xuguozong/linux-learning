package com.hikvision.hae.img.repo.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.common.constant.ImageResultCode;
import com.hikvision.hae.img.repo.ImageRepo;
import com.hikvision.hae.img.repo.ServiceProvider;

import io.swagger.client.ApiException;
import io.swagger.client.model.DetailedTag;
import io.swagger.client.model.Project;
import io.swagger.client.model.ProjectReq;
import io.swagger.client.model.Repository;


/**
 * harbor api :https://github.com/vmware/harbor/blob/master/docs/configure_swagger.md
 * @author qiuzhihao
 *
 */
@Component
public class ImageRepoImpl implements ImageRepo {

	@Resource
	private ServiceProvider clientProvider;
	
	@Override
	public List<Project> projectList() {
		try {
			return clientProvider.createProductsApi().projectsGet(null, null, null, null, null);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}
	
	/**
	 * Code	Description
	 * 409	Project name already exists.
	 * 
	 */
	@Override
	public void createProject(String projectName) {
		try {
			ProjectReq project = new ProjectReq();
			project.setProjectName(projectName);
			project.setPublic(1);
			clientProvider.createProductsApi().projectsPostWithHttpInfo(project);
		} catch (ApiException e) {
			if(e.getCode() == 409) {
				throw new HAERuntimeException(ImageResultCode.PROJECT_ALREADY_EXIST);
			} else {
				throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
			}
		}
	}

	/**
	 * Code	Description
	   200	
       Project name exists.
       401	
       User need to log in first.
       404	
       Project name does not exist.
       500	
       Unexpected internal errors.
	 */
	@Override
	public boolean isProjectExist(String projectName) {
		boolean exist = true;
		try {
			clientProvider.createProductsApi().projectsHead(projectName);
		} catch (ApiException e) {
			// 当project不存在http状态码404，框架转成ApiException异常
			if(404 == e.getCode()) {
				exist = false;
			} else {
				throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
			}
		}
		return exist;
	}

	@Override
	public void deleteProject(long projectId) {
		try {
			clientProvider.createProductsApi().projectsProjectIdDelete(projectId);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}

	@Override
	public Project getProjectById(long projectId) {
		Project project = null;
		try {
			project = clientProvider.createProductsApi().projectsProjectIdGet(projectId);
		} catch (ApiException e) {
			if(e.getCode() == 404) {
				project = null;
			} else {
				throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
			}
		}
		return project;
	}

	@Override
	public List<Repository> repositoryList(Integer projectId) {
		try {
			return clientProvider.createProductsApi().repositoriesGet(projectId, null, null, null);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}

	@Override
	public List<DetailedTag> tagList(String repoName) {
		try {
			return clientProvider.createProductsApi().repositoriesRepoNameTagsGet(repoName);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}
	
	@Override
	public void deleteRepository(String repoName) {
		try {
			clientProvider.createProductsApi().repositoriesRepoNameDelete(repoName);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}
	
	@Override
	public void deleteRepositoryTag(String repoName, String tag) {
		try {
			clientProvider.createProductsApi().repositoriesRepoNameTagsTagDelete(repoName, tag);
		} catch (ApiException e) {
			throw new HAERuntimeException(ImageResultCode.INVOKE_REST_API_ERROR, new Object[] {"harbor"}, e);
		}
	}
}
