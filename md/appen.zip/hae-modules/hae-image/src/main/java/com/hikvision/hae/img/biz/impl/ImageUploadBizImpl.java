package com.hikvision.hae.img.biz.impl;

import java.io.IOException;
import java.util.Set;

import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.img.common.constant.ImageResultCode;
import com.hikvision.hae.img.repo.ImageRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.hae.img.biz.ImageUploadBiz;
import com.hikvision.hae.img.biz.dto.UploadImageDTO;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.exceptions.DockerException;


@Service
public class ImageUploadBizImpl extends AbstractImageBiz implements ImageUploadBiz {

	private static final Logger logger = LoggerFactory.getLogger(ImageUploadBizImpl.class);

	@Autowired
	private ImageRepo imageRepo;

	@Override
	public void uploadImage(UploadImageDTO uploadDTO) throws DockerException, InterruptedException {
		DockerClient docker = createDockerClient(uploadDTO.getAccessInfo());
		Set<String> images;
		try {
			images = docker.load(uploadDTO.getImageStream());
		} catch (Exception e){
			logger.error("docker加载镜像文件id: {} 失败", uploadDTO.getFileId());
			throw new HAERuntimeException(ImageResultCode.LOAD_IMAGE_FAILED, "docker加载镜像文件失败");
		}

		if (images == null || images.size() == 0) {
			logger.error("推送镜像文件id: {} 没有返回任何镜像名称，可能原因是在保存镜像时没有指定名称", uploadDTO.getFileId());
			throw new IllegalArgumentException("保存镜像时没有指定名称");
		}
		String[] dest = new String[3];
		dest[0] = uploadDTO.getAccessInfo().getHarborAccessInfo();
		for (String image : images) {
			logger.info("upload image {} success.", image);
			String[] parts = image.split("/");
			// 私仓进行名称 docker.hikvision.com.cn/library/redis:3.0
			// 推送到harbor仓库的镜像必须要有项目名称，从官网下载的镜像需要通过tag分配一个项目名称
			if (parts.length < 2) {
				logger.error("invalid image name {}, skip push image", image);
				throw new IllegalArgumentException("镜像没有项目名称");
			}
			// 拷贝原镜像后两项信息
			System.arraycopy(parts, parts.length - 2, dest, 1, 2);
			String tag = String.join("/", dest);
			docker.tag(image, tag);
			logger.info("tag image from {} to {}", image, tag);
			//校验harbor 里是否有相应的工程名称 没有就创建
			invalidOrCreateProject(dest[1]);
			//向harbor 推送镜像
			docker.push(tag);
			logger.info("push image {} success.", image);
		}
	}

	/**
	 * 校验harbor是否有 上传的项目名
	 *
	 * @param projectName
	 */
	private void invalidOrCreateProject(String projectName) {
		if (!imageRepo.isProjectExist(projectName)) {
			try {
				imageRepo.createProject(projectName);
				logger.info("create harbor project {} success.", projectName);
			} catch (HAERuntimeException e) {
				if (ImageResultCode.PROJECT_ALREADY_EXIST == e.getResultCode()) {
					logger.warn("harbor project {} exist.", projectName);
				} else {
					throw e;
				}
			}
		}
	}
}
