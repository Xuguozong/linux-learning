package com.hikvision.hae.file.model;


/**
 * @author qiuzhihao
 */
public enum UploadStatus {

	/**
	 * 上传中
	 */
	UPLOADING(4, "上传中"),
	/**
	 * 上传中断
	 */
	UPLOAD_BREAK(7, "上传中断"),
	/**
	 * 上传完成
	 */
	UPLOADED(3, "等待推送"),
	/**
	 * 上传失败，最终状态
	 */
	UPLOAD_ERROR(5, "上传失败"),
	/**
	 * 推送中
	 */
	PUSHING(2, "推送中"),
	/**
	 * 推送错误
	 */
	PUSH_ERROR(6, "推送错误"),
	/**
	 * 推送完成
	 */
	PUSHED(1, "推送完成");

	/**
	 * 排序值
	 * 值越大越靠前
	 */
	private Integer order;
	/**
	 * 内容值
	 */
	private String content;

	UploadStatus(Integer order, String content) {
		this.order = order;
		this.content = content;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}