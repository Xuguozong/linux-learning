package com.hikvision.hae.img.biz.dto;

public class DeleteImageDTO {

	private String image;
	
	private ImageRepositoryAccessInfo accessInfo;

	public DeleteImageDTO(String image, ImageRepositoryAccessInfo accessInfo) {
		this.image = image;
		this.accessInfo = accessInfo;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public ImageRepositoryAccessInfo getAccessInfo() {
		return accessInfo;
	}

	public void setAccessInfo(ImageRepositoryAccessInfo accessInfo) {
		this.accessInfo = accessInfo;
	}
}
