package com.hikvision.hae.img.biz;

import com.hikvision.hae.img.biz.dto.ImageRepositoryAccessInfo;

public interface ImageRepositoryConfigBiz {

	ImageRepositoryAccessInfo accessInfo();
}
