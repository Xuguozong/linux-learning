package com.hikvision.hae.img.biz;

import java.util.List;

import com.hikvision.hae.img.biz.dto.DeleteImageDTO;
import com.hikvision.hae.img.biz.dto.ImageRepositoryAccessInfo;
import com.spotify.docker.client.messages.Image;

public interface ImageBiz {

	List<Image> imageList(ImageRepositoryAccessInfo accessInfo);
	
	void removeImage(DeleteImageDTO deleteDTO);
}
