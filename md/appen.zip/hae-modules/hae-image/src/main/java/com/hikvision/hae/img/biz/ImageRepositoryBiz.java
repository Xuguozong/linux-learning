package com.hikvision.hae.img.biz;

import java.util.List;

import com.hikvision.hae.img.entity.ImageProjectEntity;
import com.hikvision.hae.img.entity.ImageRepositoryEntity;
import com.hikvision.hae.img.entity.ImageRepositoryTagEntity;

/**
 * 镜像仓库
 * @author qiuzhihao
 *
 */
public interface ImageRepositoryBiz {

	List<ImageProjectEntity> projectList();
	
	List<ImageRepositoryEntity> repositoryList(Integer projectId);
	
	List<ImageRepositoryTagEntity> repositoryTagList(String repoName);
	
	void createProject(String projectName);
	
	/**
	 * 查询项目名称是否存在
	 * @param projectName
	 * @return
	 */
	boolean isProjectExist(String projectName);
	
	void deleteProject(long projectId);
	
	ImageProjectEntity getProject(long projectId);
	
	/**
	 * 删除仓库
	 * @param repoName
	 */
	void deleteRepository(String repoName);
	
	/**
	 * 删除仓库下某个tag
	 * @param repoName
	 * @param tag
	 */
	void deleteRepositoryTag(String repoName, String tag);
	
}
