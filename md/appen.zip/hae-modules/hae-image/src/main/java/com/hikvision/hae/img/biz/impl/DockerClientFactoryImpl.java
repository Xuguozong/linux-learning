package com.hikvision.hae.img.biz.impl;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Component;

import com.hikvision.hae.img.biz.DockerClientFactory;
import com.spotify.docker.client.DefaultDockerClient;
import com.spotify.docker.client.DockerClient;
import com.spotify.docker.client.auth.FixedRegistryAuthSupplier;
import com.spotify.docker.client.messages.RegistryAuth;

@Component
public class DockerClientFactoryImpl implements DockerClientFactory {
	
	private ConcurrentMap<String, DockerClient> cache = new ConcurrentHashMap<>();

	@Override
	public DockerClient createDockerClient(String repositoryHostOrIP, String dockerServerURL, String user, String password) {
		DockerClient client = cache.get(dockerServerURL);
		if(client == null) {
			synchronized (this) {
				DockerClient docker = cache.get(dockerServerURL);
				if(docker == null) {
					RegistryAuth registryAuth = RegistryAuth.create(user, password, "", repositoryHostOrIP, null, null);
					FixedRegistryAuthSupplier supplier = new FixedRegistryAuthSupplier(registryAuth, null);
					client = DefaultDockerClient.builder().uri(dockerServerURL).readTimeoutMillis(60 * 30 * 1000).registryAuthSupplier(supplier).build();
					cache.put(dockerServerURL, client);
				}
			}
		}
		
		return client;
	}

}
