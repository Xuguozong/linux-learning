package com.hikvision.hae.img.biz.impl;

import java.net.URI;
import java.net.URISyntaxException;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.hikvision.hae.common.constant.CommonResultCode;
import com.hikvision.hae.common.exception.HAERuntimeException;
import com.hikvision.hae.config.ImageRepositoryConfigProperties;
import com.hikvision.hae.img.biz.ImageRepositoryConfigBiz;
import com.hikvision.hae.img.biz.dto.ImageRepositoryAccessInfo;

@Component
public class HarborRepositoryConfigBizImpl implements ImageRepositoryConfigBiz {

	@Resource
	private ImageRepositoryConfigProperties config;
	
	private String host;
	
	public String getURL() {
		return config.getHarborUrl();
	}

	public String getHostAndPort() {
		// 缓存结果，有并发无所谓
		if(host == null) {
			try {
				URI uri = new URI(config.getHarborUrl());
				String hostInfo = uri.getHost();
				int port = uri.getPort();
				// url不配置port port值为-1
				if(port > 0) {
					hostInfo = hostInfo + ":" + port;
				}
				host = hostInfo;
			} catch (URISyntaxException e) {
				throw new HAERuntimeException(CommonResultCode.MALFORMED_URL_ERROR, e);
			}
		}
		return host;
	}

	public String getUser() {
		return config.getHarborUser();
	}

	public String getPassword() {
		return config.getHarborPassword();
	}

	public String getDockerServerURL() {
		return config.getDockerServerUrl();
	}

	@Override
	public ImageRepositoryAccessInfo accessInfo() {
		ImageRepositoryAccessInfo accessInfo = new ImageRepositoryAccessInfo();
		accessInfo.setDockerServerURL(getDockerServerURL());
		accessInfo.setHarborAccessInfo(getHostAndPort());
		accessInfo.setHarborPassword(getPassword());
		accessInfo.setHarborURL(getURL());
		accessInfo.setHarborUser(getUser());
		return accessInfo;
	}
	
}
