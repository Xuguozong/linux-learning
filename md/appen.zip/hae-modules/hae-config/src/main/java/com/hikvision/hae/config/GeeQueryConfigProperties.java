package com.hikvision.hae.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "geequery.config")
public class GeeQueryConfigProperties {

	private boolean createTable;
	private boolean allowDropColumn;
	private int globalCacheLiveTime;
	private boolean showSql;
	private String packageToScan;
	private boolean alterTable;

	public boolean isCreateTable() {
		return createTable;
	}

	public void setCreateTable(boolean createTable) {
		this.createTable = createTable;
	}

	public boolean isAllowDropColumn() {
		return allowDropColumn;
	}

	public void setAllowDropColumn(boolean allowDropColumn) {
		this.allowDropColumn = allowDropColumn;
	}

	public int getGlobalCacheLiveTime() {
		return globalCacheLiveTime;
	}

	public void setGlobalCacheLiveTime(int globalCacheLiveTime) {
		this.globalCacheLiveTime = globalCacheLiveTime;
	}

	public boolean isShowSql() {
		return showSql;
	}

	public void setShowSql(boolean showSql) {
		this.showSql = showSql;
	}

	public String getPackageToScan() {
		return packageToScan;
	}

	public void setPackageToScan(String packageToScan) {
		this.packageToScan = packageToScan;
	}

	public boolean isAlterTable() {
		return alterTable;
	}

	public void setAlterTable(boolean alterTable) {
		this.alterTable = alterTable;
	}
}
