package com.hikvision.hae.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class DockerPushPoolConfig {

    @Value("${docker.push.poolCoreSize:5}")
    private int pushCoreSize;

    @Value("${docker.push.poolMaxSize:5}")
    private int pushMaxSize;

    @Value("${docker.push.queueCapacity:20}")
    private int queueCapacity;

    @Bean
    public Executor getDockerPushPool(){
        ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        threadPoolTaskExecutor.setCorePoolSize(pushMaxSize < pushCoreSize ? pushMaxSize : pushCoreSize);
        threadPoolTaskExecutor.setMaxPoolSize(pushMaxSize);
        threadPoolTaskExecutor.setQueueCapacity(queueCapacity);
        return threadPoolTaskExecutor;
    }

}
