package com.hikvision.hae.log.biz;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.log.dto.LogQuery;
import com.hikvision.hae.log.model.Log;
import jef.common.wrapper.Page;

import java.util.List;

/**
 * Created by zhouziwei on 2017/11/9.
 */
public interface LogBiz {

    /**
     * 批量增加
     *
     * @param logs
     */
    void batchAdd(List<Log> logs);


    /**
     * 查找并分页
     *
     * @param logQuery
     * @param pageParam
     * @return
     */
    Page<Log> findAndPage(LogQuery logQuery, PageParam pageParam);

    /**
     * 下载日志
     *
     * @param logQuery
     * @return
     */
    List<Log> listLogs(LogQuery logQuery);

}
