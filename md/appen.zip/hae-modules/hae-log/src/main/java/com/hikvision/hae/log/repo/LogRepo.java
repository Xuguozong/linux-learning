package com.hikvision.hae.log.repo;

import com.github.geequery.springdata.annotation.Query;
import com.github.geequery.springdata.repository.GqRepository;
import com.hikvision.hae.log.model.Log;

import java.util.List;

/**
 * 该实体Log无主键，部分方法无法使用
 * Created by zhouziwei on 2017/11/9.
 */
public interface LogRepo extends GqRepository<Log, Long> {

    /**
     * 查询存在的表名
     *
     * @param tableName
     * @return
     */
    @Query(value = "select table_name from information_schema.tables " +
            "where table_schema='hae' and table_type='base table' and table_name like ?1<string$> ORDER BY table_name")
    List<String> findByTableName(String tableName);

    /**
     * 查询出表所占空间
     */
    @Query(value = "select sum(data_length+index_length)/1024/1024 as data_size\n" +
            "from information_schema.tables where table_schema = 'hae'and table_type='base table' and table_name like ?1<string$>")
    double findSpaceUsage(String tableName);

}
