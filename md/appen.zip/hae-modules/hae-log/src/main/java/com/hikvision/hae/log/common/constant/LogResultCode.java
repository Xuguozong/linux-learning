package com.hikvision.hae.log.common.constant;

/**
 * Log错误码 14000~14999
 * Created by zhouziwei on 2017/11/23.
 */
public class LogResultCode {
	/**
	 * 应用日志为空
	 */
	public static final int LOG_EMPTY = 14000;

	/**
	 * 应用日志批量插入失败
	 */
	public static final int LOG_INSERT_FAIL = 14001;
}
