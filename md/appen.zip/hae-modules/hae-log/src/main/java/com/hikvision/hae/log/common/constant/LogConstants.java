package com.hikvision.hae.log.common.constant;

/**
 * Created by zhouziwei on 2017/12/5.
 */
public class LogConstants {
    /**
     * 日志表名
     */
    public static final String LOG_TABLE_NAME = "container_log_";
}
