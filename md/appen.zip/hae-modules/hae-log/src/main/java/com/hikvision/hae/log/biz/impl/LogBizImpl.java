package com.hikvision.hae.log.biz.impl;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.log.biz.LogBiz;
import com.hikvision.hae.log.dto.LogQuery;
import com.hikvision.hae.log.model.Log;
import com.hikvision.hae.log.repo.LogCommonRepo;
import com.hikvision.hae.log.repo.LogRepo;
import jef.common.wrapper.Page;
import jef.database.Condition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 应用日志的接口实现
 * Created by zhouziwei on 2017/11/9.
 */
@Component
public class LogBizImpl implements LogBiz {

    private static final Logger logger = LoggerFactory.getLogger(LogBizImpl.class);

    @Resource
    private LogRepo logRepo;

    @Resource
    private LogCommonRepo logCommonRepo;

    @Value("${log.config.maxResult:15000}")
    private int maxResult;

    @Override
    public void batchAdd(List<Log> logs) {
        logRepo.save(logs);
    }

    @Override
    public Page<Log> findAndPage(LogQuery logQuery, PageParam pageParam) {
        Page<Log> logPage = logCommonRepo.findAndPage(logQuery, pageParam);
        return logPage;
    }

    @Override
    public List<Log> listLogs(LogQuery logQuery) {
        Log log = new Log();
        buildQueryCondition(log, logQuery);
        log.getQuery().addOrderBy(true, Log.Field.time);
        log.getQuery().setMaxResult(maxResult);
        List<Log> logList = logRepo.find(log);
        return logList;
    }

    private void buildQueryCondition(Log log, LogQuery logQuery) {
        log.getQuery().addCondition(Log.Field.time, Condition.Operator.GREAT_EQUALS, logQuery.getStartTime());
        log.getQuery().addCondition(Log.Field.time, Condition.Operator.LESS_EQUALS, logQuery.getEndTime());
        log.getQuery().addCondition(Log.Field.containerName, logQuery.getContainerName());
        log.getQuery().addCondition(Log.Field.podName, logQuery.getPodName());
        log.getQuery().addCondition(Log.Field.namespaceName, logQuery.getNamespaceName());
    }

}
