package com.hikvision.hae.log.repo.impl;

import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.log.dto.LogQuery;
import com.hikvision.hae.log.model.Log;
import com.hikvision.hae.log.repo.LogCommonRepo;
import jef.common.wrapper.Page;
import jef.tools.DateFormats;
import jef.tools.DateUtils;
import org.easyframe.enterprise.spring.CommonDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hikvision.hae.log.common.constant.LogConstants.LOG_TABLE_NAME;

/**
 * Created by zhouziwei on 2017/11/25.
 */
@Component
public class LogCommonRepoImpl implements LogCommonRepo {

    private static final Logger logger = LoggerFactory.getLogger(LogCommonRepoImpl.class);

    @Resource
    private CommonDao commonDao;

    @Override
    public int getLogTotalPage(Log log, int pageSize) {
        int totalCount = 0;
        try {
            totalCount = commonDao.getSession().count(log.getQuery());
        } catch (SQLException e) {
            DelayedLogger.error(logger, () -> "count all logs failed", e);
        }
        return pageSize == 0 ? 0 : (totalCount - 1) / pageSize + 1;
    }

    @Override
    public Page<Log> findAndPage(LogQuery logQuery, PageParam pageParam) {
        String sql = buildSql(logQuery, pageParam);
        List<Log> logList = commonDao.getSession().createNativeQuery(sql, Log.class).setParameterMap(buildParams(logQuery, pageParam)).getResultList();
        Page<Log> page = null;
        if (pageParam.getPageSize() > logList.size()) {
            page = new Page<>(logList.size() + (pageParam.getPageNo() - 1) * pageParam.getPageSize(), pageParam.getPageSize());
            if (logList.size() == 0 && pageParam.getPageNo() > 1) {
                pageParam.setPageNo(pageParam.getPageNo() - 1);
            }
        } else {
            page = new Page<>(50000, pageParam.getPageSize());
        }
        page.setList(logList);
        return page;
    }

    @Override
    public void deleteTable(String tableName, String seqName) {
        try {
            commonDao.getNoTransactionSession().dropTable(tableName, seqName);
        } catch (SQLException e) {
            DelayedLogger.error(logger, () -> "Drop table " + tableName + " failed", e);
        }
    }

    /**
     * 构造查询条件
     *
     * @param logQuery
     * @param pageParam
     * @return
     */
    private String buildSql(LogQuery logQuery, PageParam pageParam) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select * from :table_name<sql> ");
        stringBuilder.append("where time>=:startTime and time<=:endTime ");
        stringBuilder.append("and namespace_name=:namespace ");
        stringBuilder.append("and pod_name=:pod ");
        stringBuilder.append("and container_name=:container ");
        //无法采用绑定变量
        stringBuilder.append("limit " + pageParam.getPageSize() * (pageParam.getPageNo() - 1) + ", " + pageParam.getPageSize());
        return stringBuilder.toString();
    }

    private Map<String, Object> buildParams(LogQuery logQuery, PageParam pageParam) {
        Map<String, Object> params = new HashMap<>();
        params.put("table_name", buildTableName(logQuery.getStartTime()) + " ");
        params.put("startTime", formatDate2DateTime(logQuery.getStartTime()));
        params.put("endTime", formatDate2DateTime(logQuery.getEndTime()));
        params.put("namespace", logQuery.getNamespaceName());
        params.put("pod", logQuery.getPodName());
        params.put("container", logQuery.getContainerName());
        return params;
    }

    /**
     * 返回当天日期的前30天的序列如:20171127,如果是9月，则序列为20170927
     *
     * @return
     */
    private String buildTableName(Date date) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(LOG_TABLE_NAME);
        stringBuilder.append(DateUtils.format(date, DateFormats.DATE_SHORT));
        return stringBuilder.toString();
    }

    /**
     * 返回日期的查询时间格式
     *
     * @return
     */
    private String formatDate2DateTime(Date date) {
        return DateUtils.format(date, DateFormats.DATE_TIME_CS);
    }

}

