package com.hikvision.hae.log.repo;

import com.hikvision.hae.common.vo.PageParam;
import com.hikvision.hae.log.dto.LogQuery;
import com.hikvision.hae.log.model.Log;
import jef.common.wrapper.Page;

/**
 * 这里全部利用commonDao
 * <p>
 * Created by zhouziwei on 2017/11/25.
 */
public interface LogCommonRepo {

    /**
     * 获取日志分页后的总页数
     *
     * @param log
     * @return
     */
    int getLogTotalPage(Log log, int pageSize);

    /**
     * 根据SQL查询并分页
     *
     * @param log
     * @param pageParam
     * @return
     */
    Page<Log> findAndPage(LogQuery log, PageParam pageParam);

    /**
     * 删除日志表（分表中的表删除方法）
     *
     * @param tableName 表名
     * @param seqName
     */
    void deleteTable(String tableName, String seqName);


}
