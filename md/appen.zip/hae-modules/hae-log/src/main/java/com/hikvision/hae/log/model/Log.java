package com.hikvision.hae.log.model;

import com.github.geequery.orm.annotation.Comment;
import jef.database.DataObject;
import jef.database.annotation.Indexed;
import jef.database.annotation.PartitionKey;
import jef.database.annotation.PartitionTable;
import jef.database.routing.function.KeyFunction;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by zhouziwei on 2017/11/9.
 */
@Entity
@Table(name = "container_log")
@PartitionTable(key = {@PartitionKey(field = "time", function = KeyFunction.YEAR_MONTH_DAY)})
@Comment("日志")
public class Log extends DataObject {

    private static final long serialVersionUID = 1542075124549191356L;

    /**
     * 日志发生的时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "time")
    @Indexed(name = "idx_log_time", desc = true)
    private Date time;

    /**
     * Pod名称
     */
    @Column(name = "pod_name")
    @Indexed(name = "idx_log_podName")
    private String podName;

    /**
     * container_name
     */
    @Column(name = "container_name")
    @Indexed(name = "idx_log_containerName")
    private String containerName;

    /**
     * namespace_name
     */
    @Column(name = "namespace_name")
    @Indexed(name = "idx_log_namespaceName")
    private String namespaceName;

    /**
     * 日志内容,操作描述
     */
    @Column(name = "log", columnDefinition = "clob")
    private String log;

    public enum Field implements jef.database.Field {
        time, podName, containerName, namespaceName, log
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getPodName() {
        return podName;
    }

    public void setPodName(String podName) {
        this.podName = podName;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public String getNamespaceName() {
        return namespaceName;
    }

    public void setNamespaceName(String namespaceName) {
        this.namespaceName = namespaceName;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }
}
