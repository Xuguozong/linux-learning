package com.hikvision.hae.log.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 日志查询条件
 * <p>
 * Created by zhouziwei on 2017/11/9.
 */
public class LogQuery implements Serializable {

    private static final long serialVersionUID = -484632414849900797L;

    private String podName;

    private String containerName;

    private String namespaceName;

    private Date startTime;

    private Date endTime;

    public String getPodName() {
        return podName;
    }

    public void setPodName(String podName) {
        this.podName = podName;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public String getNamespaceName() {
        return namespaceName;
    }

    public void setNamespaceName(String namespaceName) {
        this.namespaceName = namespaceName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

}
