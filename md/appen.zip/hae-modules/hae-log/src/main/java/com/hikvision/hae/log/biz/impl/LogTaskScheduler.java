package com.hikvision.hae.log.biz.impl;

import com.hikvision.hae.common.util.DelayedLogger;
import com.hikvision.hae.log.repo.LogCommonRepo;
import com.hikvision.hae.log.repo.LogRepo;
import jef.tools.DateFormats;
import jef.tools.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.List;

import static com.hikvision.hae.log.common.constant.LogConstants.LOG_TABLE_NAME;

/**
 * 容器日志调度器：分析表的数量不会超过一定阈值，表所占空间不超过一定值：如80%，一旦超过，则需清理数据到一个阈值，如70%
 * <p>
 * Created by zhouziwei on 2017/11/13.
 */
@Component
@Profile(value = {"prod", "test", "dev"})
public class LogTaskScheduler {
    private static final Logger logger = LoggerFactory.getLogger(LogTaskScheduler.class);

    @Resource
    private LogRepo logRepo;

    @Resource
    private LogCommonRepo logCommonRepo;

    //分表保存的数量最大值，是指有效值,单位是天
    @Value("${log.config.keepDays:30}")
    private int keepDays;

    //单位是M
    @Value("${log.config.spaceAllocation:10000}")
    private double spaceAllocation;

    @Scheduled(cron = "0 10 * ? * *") //每小时的10分钟需要按磁盘查询并清理,清理策略按照按天清理哦
    public void doClean() {
        try {
            double spaceUsage = logRepo.findSpaceUsage(LOG_TABLE_NAME);
            //需要清理到0.7
            if (spaceUsage > spaceAllocation * 0.8) {
                DelayedLogger.info(logger, () -> "[磁盘清理日志开始]:");
                List<String> tableNames = logRepo.findByTableName(LOG_TABLE_NAME);
                for (String name : tableNames) {
                    String seqNames = name.split("_")[2];
                    DelayedLogger.info(logger, () -> "[磁盘清理]清理表:" + name + " 开始");
                    logCommonRepo.deleteTable(name, seqNames);
                    DelayedLogger.info(logger, () -> "[磁盘清理]清理表:" + name + " 结束");
                    spaceUsage = logRepo.findSpaceUsage(LOG_TABLE_NAME);
                    if (spaceUsage < spaceAllocation * 0.7) {
                        DelayedLogger.info(logger, () -> "[磁盘清理日志结束]");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            DelayedLogger.error(logger, () -> "按照磁盘空间清理陈旧日志数据失败", e);
        }
    }


    @Scheduled(cron = "0 0 1 ? * *") //每天的一点执行按表的清理工作
    public void execute() {
        new CleanTask().run();
    }

    /**
     * 按天清理表的工作
     */
    public class CleanTask {
        public void run() {
            try {
                //清理，清理历史最长的表，直到张数少于30天
                List<String> tableNames = logRepo.findByTableName(LOG_TABLE_NAME);
                String tableSeq = buildTableName();
                int deleteTableNums = 0;
                for (String name : tableNames) {
                    String seqNames = name.split("_")[2];
                    if (tableSeq.compareTo(name) > 0) {
                        DelayedLogger.info(logger, () -> "[按天清理任务]删除表：" + name + " 开始");
                        logCommonRepo.deleteTable(name, seqNames);
                        deleteTableNums++;
                        DelayedLogger.info(logger, () -> "[按天清理任务]删除表：" + name + " 结束");
                    }
                }
                if (deleteTableNums > 0) {
                    DelayedLogger.info(logger, () -> "按天清理表数据结束!");
                }
            } catch (Exception e) {
                DelayedLogger.error(logger, () -> "按照表数清理陈旧日志数据失败", e);
            }
        }
    }

    /**
     * 返回当天日期的前30天的序列如:20171127,如果是9月，则序列为20170927
     *
     * @return
     */
    private String buildTableName() {
        Calendar calendar = Calendar.getInstance();
        //需要去除今天的一天
        calendar.add(Calendar.DATE, -(keepDays - 1));
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(LOG_TABLE_NAME);
        stringBuilder.append(DateUtils.format(calendar.getTime(), DateFormats.DATE_SHORT));
        return stringBuilder.toString();
    }


}
