package com.hikvision.hae;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by zhouziwei on 2017/11/9.
 */
@Rollback
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = HaeLogApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
@Transactional(rollbackFor = {Exception.class})
public class HaeLogBaseTest {
}
