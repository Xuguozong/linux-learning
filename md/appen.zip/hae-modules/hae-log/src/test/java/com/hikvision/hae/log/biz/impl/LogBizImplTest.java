package com.hikvision.hae.log.biz.impl;

import com.hikvision.hae.HaeLogBaseTest;
import com.hikvision.hae.log.biz.LogBiz;
import com.hikvision.hae.log.model.Log;
import com.hikvision.hae.log.repo.LogRepo;
import jef.tools.DateUtils;
import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * Created by zhouziwei on 2017/11/9.
 */
public class LogBizImplTest extends HaeLogBaseTest {

    @MockBean
    private LogBiz logBiz;

    @MockBean
    private LogRepo logRepo;


    @Test
    public void testBatchAdd() throws Exception {
        logBiz.batchAdd(assembleData());
        System.out.println(logRepo.findByTableName("container_log"));

    }

    /**
     * 分表的实现
     * @throws Exception
     */
    @Test
    public void testAdd() throws Exception {
        Log log = new Log();
        log.setTime(DateUtils.get(2017,5,5));
        logRepo.save(log);

        Log log1 = new Log();
        log1.setTime(DateUtils.get(2017,6,1));
        logRepo.save(log1);
    }

    private List<Log> assembleData() {
        List<Log> logs = new ArrayList<>();
        logs.add(init());
        logs.add(init());
        logs.add(init());
        return logs;
    }

    private Log init() {
        Log log = new Log();
//        log.setId(id);
        log.setTime(new Date());
        log.setPodName("podName");
        log.setNamespaceName("namespaceName");
        log.setContainerName("containerName");
        log.setLog("log");
        return log;
    }
}
