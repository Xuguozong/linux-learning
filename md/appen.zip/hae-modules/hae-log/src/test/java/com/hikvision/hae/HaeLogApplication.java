package com.hikvision.hae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by zhouziwei on 2017/11/9.
 */
@SpringBootApplication
public class HaeLogApplication {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(HaeLogApplication.class, args);
    }
}
